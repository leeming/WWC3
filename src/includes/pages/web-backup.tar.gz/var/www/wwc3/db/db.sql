SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

CREATE SCHEMA IF NOT EXISTS `wwcdev` DEFAULT CHARACTER SET utf8 ;
USE `wwcdev`;

-- -----------------------------------------------------
-- Table `wwcdev`.`Countries`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Countries` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Countries` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `name` CHAR(20) NOT NULL COMMENT 'Name of the country' ,
  `default_milita` INT NOT NULL DEFAULT 100 ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Regions`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Regions` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Regions` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `name` CHAR(20) NOT NULL COMMENT 'Name of Region' ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB
COMMENT = 'Regions are collection of countries, ie Continents';


-- -----------------------------------------------------
-- Table `wwcdev`.`Unit_types`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Unit_types` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Unit_types` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Units`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Units` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Units` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `unit_type_id` INT NOT NULL ,
  `name` CHAR(20) NOT NULL COMMENT 'Name of the unit' ,
  PRIMARY KEY (`id`, `unit_type_id`) ,
  INDEX `fk_UnitTypes_Units1` (`unit_type_id` ASC) ,
  CONSTRAINT `fk_UnitTypes_Units1`
    FOREIGN KEY (`unit_type_id` )
    REFERENCES `wwcdev`.`Unit_types` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'List of all units in game'
PACK_KEYS = DEFAULT;


-- -----------------------------------------------------
-- Table `wwcdev`.`Resources`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Resources` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Resources` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `name` CHAR(20) NULL COMMENT 'Name of resource type' ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB
COMMENT = 'Table holding all resources used in game';


-- -----------------------------------------------------
-- Table `wwcdev`.`Research`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Research` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Research` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(40) NOT NULL COMMENT 'Name of the research' ,
  `desc` VARCHAR(100) NULL COMMENT 'Description of the research which is visible to users' ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB
COMMENT = 'Holds all research details';


-- -----------------------------------------------------
-- Table `wwcdev`.`Region_has_resource`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Region_has_resource` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Region_has_resource` (
  `region_id` INT NOT NULL ,
  `resource_id` INT NOT NULL ,
  `resource_qty` INT NOT NULL DEFAULT 0 COMMENT 'The number of resources to give as bonus' ,
  PRIMARY KEY (`resource_id`, `region_id`) ,
  INDEX `fk_Regions_Regions_has_Resources1` (`region_id` ASC) ,
  INDEX `fk_Resources_Regions_has_Resources1` (`resource_id` ASC) ,
  CONSTRAINT `fk_Regions_Regions_has_Resources1`
    FOREIGN KEY (`region_id` )
    REFERENCES `wwcdev`.`Regions` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Resources_Regions_has_Resources1`
    FOREIGN KEY (`resource_id` )
    REFERENCES `wwcdev`.`Resources` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'resources to be applied to a region bonus';


-- -----------------------------------------------------
-- Table `wwcdev`.`Research_requires_research`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Research_requires_research` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Research_requires_research` (
  `research_id` INT NOT NULL ,
  `required_research` INT NOT NULL COMMENT 'Research which needs to be done before research_id can be done' ,
  PRIMARY KEY (`research_id`, `required_research`) ,
  INDEX `fk_Advancements_Advancements_has_Advancements` (`research_id` ASC) ,
  INDEX `fk_Advancements_Advancements_has_Advancements1` (`required_research` ASC) ,
  CONSTRAINT `fk_Advancements_Advancements_has_Advancements`
    FOREIGN KEY (`research_id` )
    REFERENCES `wwcdev`.`Research` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Advancements_Advancements_has_Advancements1`
    FOREIGN KEY (`required_research` )
    REFERENCES `wwcdev`.`Research` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'List of all research adjacent pre requirements';


-- -----------------------------------------------------
-- Table `wwcdev`.`Unit_requires_resource`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Unit_requires_resource` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Unit_requires_resource` (
  `unit_id` INT NOT NULL ,
  `resources_id` INT NOT NULL ,
  `resource_qty` INT NOT NULL ,
  INDEX `fk_Units_Units_has_Resources1` (`unit_id` ASC) ,
  INDEX `fk_Resources_Units_has_Resources1` (`resources_id` ASC) ,
  PRIMARY KEY (`unit_id`, `resources_id`) ,
  CONSTRAINT `fk_Units_Units_has_Resources1`
    FOREIGN KEY (`unit_id` )
    REFERENCES `wwcdev`.`Units` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Resources_Units_has_Resources1`
    FOREIGN KEY (`resources_id` )
    REFERENCES `wwcdev`.`Resources` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'List of resources needed to produce unit.';


-- -----------------------------------------------------
-- Table `wwcdev`.`Research_requires_resource`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Research_requires_resource` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Research_requires_resource` (
  `research_id` INT NOT NULL ,
  `resource_id` INT NOT NULL ,
  `resource_qty` INT NOT NULL DEFAULT 0 ,
  PRIMARY KEY (`research_id`, `resource_id`) ,
  INDEX `fk_Advancements_Advancements_has_Resources1` (`research_id` ASC) ,
  INDEX `fk_Resources_Advancements_has_Resources1` (`resource_id` ASC) ,
  CONSTRAINT `fk_Advancements_Advancements_has_Resources1`
    FOREIGN KEY (`research_id` )
    REFERENCES `wwcdev`.`Research` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Resources_Advancements_has_Resources1`
    FOREIGN KEY (`resource_id` )
    REFERENCES `wwcdev`.`Resources` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Resources needed to do research eg Turns or money';


-- -----------------------------------------------------
-- Table `wwcdev`.`Unit_requires_research`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Unit_requires_research` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Unit_requires_research` (
  `unit_id` INT NOT NULL ,
  `research_id` INT NOT NULL ,
  PRIMARY KEY (`unit_id`, `research_id`) ,
  INDEX `fk_Units_Units_has_Advancements1` (`unit_id` ASC) ,
  INDEX `fk_Advancements_Units_has_Advancements1` (`research_id` ASC) ,
  CONSTRAINT `fk_Units_Units_has_Advancements1`
    FOREIGN KEY (`unit_id` )
    REFERENCES `wwcdev`.`Units` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Advancements_Units_has_Advancements1`
    FOREIGN KEY (`research_id` )
    REFERENCES `wwcdev`.`Research` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Country_has_resource`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Country_has_resource` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Country_has_resource` (
  `country_id` INT NOT NULL ,
  `resource_id` INT NOT NULL ,
  `resource_qty` INT NOT NULL ,
  PRIMARY KEY (`country_id`, `resource_id`) ,
  INDEX `fk_Countries_Countries_has_Resources1` (`country_id` ASC) ,
  INDEX `fk_Resources_Countries_has_Resources1` (`resource_id` ASC) ,
  CONSTRAINT `fk_Countries_Countries_has_Resources1`
    FOREIGN KEY (`country_id` )
    REFERENCES `wwcdev`.`Countries` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Resources_Countries_has_Resources1`
    FOREIGN KEY (`resource_id` )
    REFERENCES `wwcdev`.`Resources` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'resources to be applied to a country bonus';


-- -----------------------------------------------------
-- Table `wwcdev`.`Country_has_border`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Country_has_border` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Country_has_border` (
  `country_id` INT NOT NULL ,
  `border_country` INT NOT NULL ,
  PRIMARY KEY (`country_id`, `border_country`) ,
  INDEX `fk_Countries_Countries_has_Countries` (`country_id` ASC) ,
  INDEX `fk_Countries_Countries_has_Countries1` (`border_country` ASC) ,
  CONSTRAINT `fk_Countries_Countries_has_Countries`
    FOREIGN KEY (`country_id` )
    REFERENCES `wwcdev`.`Countries` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Countries_Countries_has_Countries1`
    FOREIGN KEY (`border_country` )
    REFERENCES `wwcdev`.`Countries` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Facilities`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Facilities` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Facilities` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `name` CHAR(30) NOT NULL COMMENT 'Name of the facility' ,
  `desc` CHAR(100) NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB
COMMENT = 'Table of all the different types of buidings';


-- -----------------------------------------------------
-- Table `wwcdev`.`Facility_requires_resource`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Facility_requires_resource` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Facility_requires_resource` (
  `facility_id` INT NOT NULL ,
  `resource_id` INT NOT NULL ,
  `resource_qty` INT NOT NULL COMMENT 'The number of resources needed to build' ,
  PRIMARY KEY (`facility_id`, `resource_id`) ,
  INDEX `fk_Facilities_Facilities_has_Resources1` (`facility_id` ASC) ,
  INDEX `fk_Resources_Facilities_has_Resources1` (`resource_id` ASC) ,
  CONSTRAINT `fk_Facilities_Facilities_has_Resources1`
    FOREIGN KEY (`facility_id` )
    REFERENCES `wwcdev`.`Facilities` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Resources_Facilities_has_Resources1`
    FOREIGN KEY (`resource_id` )
    REFERENCES `wwcdev`.`Resources` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'List the resource costs of building a facility';


-- -----------------------------------------------------
-- Table `wwcdev`.`Facility_builds_unit`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Facility_builds_unit` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Facility_builds_unit` (
  `facility_id` INT NOT NULL ,
  `unit_id` INT NOT NULL ,
  `unit_qty` INT NULL COMMENT 'Production weighting, ie number of units a single facility produces' ,
  PRIMARY KEY (`facility_id`, `unit_id`) ,
  INDEX `fk_Facilities_Facilities_has_Units1` (`facility_id` ASC) ,
  INDEX `fk_Units_Facilities_has_Units1` (`unit_id` ASC) ,
  CONSTRAINT `fk_Facilities_Facilities_has_Units1`
    FOREIGN KEY (`facility_id` )
    REFERENCES `wwcdev`.`Facilities` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Units_Facilities_has_Units1`
    FOREIGN KEY (`unit_id` )
    REFERENCES `wwcdev`.`Units` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Facilities build units also how many per turn';


-- -----------------------------------------------------
-- Table `wwcdev`.`Settings`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Settings` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Settings` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `max_players` INT NOT NULL DEFAULT 0 COMMENT 'If >0, max number of players allowed to play game' ,
  `has_generals` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0 ,
  `team_governments` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Allow teams to have governments (give bonuses depending on type of gov) ' ,
  `player_governments` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Allow players to have governments (give bonuses depending on type of gov) ' ,
  `allow_team_treaties` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Allow teams to have treaties/allies' ,
  `natural_disasters` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Turn natural disasters on/off' ,
  `milita_growth` INT NOT NULL DEFAULT 0 COMMENT 'Higher this value the more milita grows per turn, 0 is no growth' ,
  `late_entry_time` INT NOT NULL DEFAULT 86400 COMMENT 'Number of seconds after start of game players can still join the game. Default is 1 day' ,
  `cycle_time` INT NOT NULL DEFAULT 180 COMMENT 'Number of seconds for each turn' ,
  `name` CHAR(15) NULL COMMENT 'Name to identify setting' ,
  `desc` CHAR(50) NULL COMMENT 'Short description of setting' ,
  `assim_rate` INT NOT NULL DEFAULT 20 COMMENT 'Number of cycles needed for country to be 100% assim' ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Games`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Games` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Games` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `setting_id` INT NOT NULL ,
  `name` VARCHAR(30) NOT NULL ,
  `start_timestamp` INT NULL COMMENT 'Timestamp when the game started/will start' ,
  `desc` VARCHAR(45) NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `fk_Games_Settings1` (`setting_id` ASC) ,
  CONSTRAINT `fk_Games_Settings1`
    FOREIGN KEY (`setting_id` )
    REFERENCES `wwcdev`.`Settings` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Teams`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Teams` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Teams` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `name` CHAR(30) NOT NULL ,
  `colour` CHAR(15) NULL COMMENT 'Colour to paint team in RRR-GGG-BBB format' ,
  `capital` INT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Play_styles`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Play_styles` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Play_styles` (
  `id` INT NOT NULL ,
  `name` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Users`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Users` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Users` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `username` VARCHAR(45) NOT NULL ,
  `password` VARCHAR(45) NOT NULL ,
  `email` VARCHAR(45) NOT NULL ,
  `salt` VARCHAR(45) NOT NULL ,
  `handle` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Game_teams`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Game_teams` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Game_teams` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `game_id` INT NOT NULL ,
  `team_id` INT NOT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `fk_Game_teams_Games1` (`game_id` ASC) ,
  INDEX `fk_Game_teams_Teams1` (`team_id` ASC) ,
  UNIQUE INDEX `fk_Game_teams_UNIQUE` (`game_id` ASC, `team_id` ASC) ,
  CONSTRAINT `fk_Game_teams_Games1`
    FOREIGN KEY (`game_id` )
    REFERENCES `wwcdev`.`Games` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Game_teams_Teams1`
    FOREIGN KEY (`team_id` )
    REFERENCES `wwcdev`.`Teams` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Players`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Players` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Players` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `style_id` INT NOT NULL DEFAULT 1 ,
  `user_id` INT NOT NULL ,
  `game_id` INT NOT NULL ,
  `team_id` INT NOT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `fk_players_Play_styles1` (`style_id` ASC) ,
  INDEX `fk_players_Games1` (`game_id` ASC) ,
  INDEX `fk_players_users1` (`user_id` ASC) ,
  UNIQUE INDEX `fk_unique` (`user_id` ASC, `game_id` ASC) ,
  INDEX `fk_Players_Game_teams1` (`team_id` ASC) ,
  CONSTRAINT `fk_players_Play_styles1`
    FOREIGN KEY (`style_id` )
    REFERENCES `wwcdev`.`Play_styles` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_players_Games1`
    FOREIGN KEY (`game_id` )
    REFERENCES `wwcdev`.`Games` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_players_users1`
    FOREIGN KEY (`user_id` )
    REFERENCES `wwcdev`.`Users` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Players_Game_teams1`
    FOREIGN KEY (`team_id` )
    REFERENCES `wwcdev`.`Game_teams` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Setting_has_country`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Setting_has_country` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Setting_has_country` (
  `country_id` INT NOT NULL ,
  `setting_id` INT NOT NULL ,
  PRIMARY KEY (`country_id`, `setting_id`) ,
  INDEX `fk_Game_has_Country_Countries1` (`country_id` ASC) ,
  INDEX `fk_Game_has_Country_Settings1` (`setting_id` ASC) ,
  CONSTRAINT `fk_Game_has_Country_Countries1`
    FOREIGN KEY (`country_id` )
    REFERENCES `wwcdev`.`Countries` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Game_has_Country_Settings1`
    FOREIGN KEY (`setting_id` )
    REFERENCES `wwcdev`.`Settings` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Player_has_resource`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Player_has_resource` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Player_has_resource` (
  `resource_id` INT NOT NULL ,
  `player_id` INT NOT NULL ,
  `resource_qty` INT NULL ,
  PRIMARY KEY (`player_id`, `resource_id`) ,
  INDEX `fk_Resources_players_has_Resources1` (`resource_id` ASC) ,
  INDEX `fk_player_has_Resource_players1` (`player_id` ASC) ,
  CONSTRAINT `fk_Resources_players_has_Resources1`
    FOREIGN KEY (`resource_id` )
    REFERENCES `wwcdev`.`Resources` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_player_has_Resource_players1`
    FOREIGN KEY (`player_id` )
    REFERENCES `wwcdev`.`Players` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Battalion`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Battalion` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Battalion` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `player_id` INT NOT NULL ,
  `name` VARCHAR(45) NOT NULL DEFAULT 'Default Battalion' COMMENT 'Name of the battalion' ,
  `country_id` INT NOT NULL COMMENT 'Location of battalion' ,
  PRIMARY KEY (`id`, `player_id`, `country_id`) ,
  INDEX `fk_battalion_players1` (`player_id` ASC) ,
  INDEX `fk_battalion_Countries1` (`country_id` ASC) ,
  CONSTRAINT `fk_battalion_players1`
    FOREIGN KEY (`player_id` )
    REFERENCES `wwcdev`.`Players` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_battalion_Countries1`
    FOREIGN KEY (`country_id` )
    REFERENCES `wwcdev`.`Countries` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'List of battalions in game';


-- -----------------------------------------------------
-- Table `wwcdev`.`Player_has_unit`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Player_has_unit` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Player_has_unit` (
  `unit_id` INT NOT NULL ,
  `battalion_id` INT NOT NULL ,
  `unit_qty` INT NOT NULL ,
  PRIMARY KEY (`unit_id`, `battalion_id`) ,
  INDEX `fk_Units_players_has_Units1` (`unit_id` ASC) ,
  INDEX `fk_battallion_player_has_unit1` (`battalion_id` ASC) ,
  CONSTRAINT `fk_Units_players_has_Units1`
    FOREIGN KEY (`unit_id` )
    REFERENCES `wwcdev`.`Units` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_battallion_player_has_unit1`
    FOREIGN KEY (`battalion_id` )
    REFERENCES `wwcdev`.`Battalion` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Player_has_facility`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Player_has_facility` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Player_has_facility` (
  `facility_id` INT NOT NULL ,
  `player_id` INT NOT NULL ,
  `country_id` INT NOT NULL ,
  `facility_qty` INT NOT NULL ,
  PRIMARY KEY (`player_id`, `facility_id`, `country_id`) ,
  INDEX `fk_players_players_has_Facilities1` (`player_id` ASC) ,
  INDEX `fk_Facilities_players_has_Facilities1` (`facility_id` ASC) ,
  INDEX `fk_player_has_Facility_Countries1` (`country_id` ASC) ,
  CONSTRAINT `fk_players_players_has_Facilities1`
    FOREIGN KEY (`player_id` )
    REFERENCES `wwcdev`.`Players` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Facilities_players_has_Facilities1`
    FOREIGN KEY (`facility_id` )
    REFERENCES `wwcdev`.`Facilities` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_player_has_Facility_Countries1`
    FOREIGN KEY (`country_id` )
    REFERENCES `wwcdev`.`Countries` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Player_has_research`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Player_has_research` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Player_has_research` (
  `player_id` INT NOT NULL ,
  `research_id` INT NOT NULL ,
  PRIMARY KEY (`player_id`, `research_id`) ,
  INDEX `fk_players_players_has_Advancements1` (`player_id` ASC) ,
  INDEX `fk_Advancements_players_has_Advancements1` (`research_id` ASC) ,
  CONSTRAINT `fk_players_players_has_Advancements1`
    FOREIGN KEY (`player_id` )
    REFERENCES `wwcdev`.`Players` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Advancements_players_has_Advancements1`
    FOREIGN KEY (`research_id` )
    REFERENCES `wwcdev`.`Research` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Facility_requires_research`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Facility_requires_research` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Facility_requires_research` (
  `facility_id` INT NOT NULL ,
  `research_id` INT NOT NULL ,
  PRIMARY KEY (`facility_id`, `research_id`) ,
  INDEX `fk_Facilities_Facilities_has_Advancements1` (`facility_id` ASC) ,
  INDEX `fk_Advancements_Facilities_has_Advancements1` (`research_id` ASC) ,
  CONSTRAINT `fk_Facilities_Facilities_has_Advancements1`
    FOREIGN KEY (`facility_id` )
    REFERENCES `wwcdev`.`Facilities` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Advancements_Facilities_has_Advancements1`
    FOREIGN KEY (`research_id` )
    REFERENCES `wwcdev`.`Research` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'research requirements to be able to build facility';


-- -----------------------------------------------------
-- Table `wwcdev`.`Ranks`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Ranks` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Ranks` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  `available` INT NOT NULL COMMENT 'The number of players who can have this rank' ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Units_requires_Countries`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Units_requires_Countries` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Units_requires_Countries` (
  `Units_id` INT NOT NULL ,
  `Countries_id` INT NOT NULL ,
  PRIMARY KEY (`Units_id`, `Countries_id`) ,
  INDEX `fk_Units_has_Countries_Units1` (`Units_id` ASC) ,
  INDEX `fk_Units_has_Countries_Countries1` (`Countries_id` ASC) ,
  CONSTRAINT `fk_Units_has_Countries_Units1`
    FOREIGN KEY (`Units_id` )
    REFERENCES `wwcdev`.`Units` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Units_has_Countries_Countries1`
    FOREIGN KEY (`Countries_id` )
    REFERENCES `wwcdev`.`Countries` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Unit_stats`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Unit_stats` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Unit_stats` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `name` CHAR(20) NOT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB
COMMENT = 'List of all known unit stats';


-- -----------------------------------------------------
-- Table `wwcdev`.`Unit_has_stats`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Unit_has_stats` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Unit_has_stats` (
  `unit_id` INT NOT NULL ,
  `stat_id` INT NOT NULL ,
  `stat_qty` INT NOT NULL ,
  PRIMARY KEY (`unit_id`, `stat_id`) ,
  INDEX `fk_Units_has_Unit_stats_Units1` (`unit_id` ASC) ,
  INDEX `fk_Units_has_Unit_stats_Unit_stats1` (`stat_id` ASC) ,
  CONSTRAINT `fk_Units_has_Unit_stats_Units1`
    FOREIGN KEY (`unit_id` )
    REFERENCES `wwcdev`.`Units` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Units_has_Unit_stats_Unit_stats1`
    FOREIGN KEY (`stat_id` )
    REFERENCES `wwcdev`.`Unit_stats` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'List of core stats each unit has';


-- -----------------------------------------------------
-- Table `wwcdev`.`Battalion_commanders`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Battalion_commanders` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Battalion_commanders` (
  `battalion_id` INT NOT NULL ,
  `name` VARCHAR(45) NOT NULL DEFAULT 'Unnamed' COMMENT 'Name of the battalion commander' ,
  `exp` INT NULL DEFAULT 0 ,
  PRIMARY KEY (`battalion_id`) ,
  INDEX `fk_battalion_commanders_battalion1` (`battalion_id` ASC) ,
  CONSTRAINT `fk_battalion_commanders_battalion1`
    FOREIGN KEY (`battalion_id` )
    REFERENCES `wwcdev`.`Battalion` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'List of battalion commanders';


-- -----------------------------------------------------
-- Table `wwcdev`.`Player_research_queue`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Player_research_queue` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Player_research_queue` (
  `player_id` INT NOT NULL ,
  `research_id` INT NOT NULL ,
  `ticks_done` INT NOT NULL DEFAULT 0 ,
  `pos` INT NOT NULL ,
  PRIMARY KEY (`player_id`, `research_id`) ,
  INDEX `fk_player_research_queue_players1` (`player_id` ASC) ,
  INDEX `fk_player_research_queue_Research1` (`research_id` ASC) ,
  CONSTRAINT `fk_player_research_queue_players1`
    FOREIGN KEY (`player_id` )
    REFERENCES `wwcdev`.`Players` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_player_research_queue_Research1`
    FOREIGN KEY (`research_id` )
    REFERENCES `wwcdev`.`Research` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'List of queued research for players';


-- -----------------------------------------------------
-- Table `wwcdev`.`Medals`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Medals` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Medals` (
  `id` INT NOT NULL ,
  `name` VARCHAR(45) NULL ,
  `desc` TEXT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Team_has_country`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Team_has_country` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Team_has_country` (
  `country_id` INT NOT NULL ,
  `team_id` INT NOT NULL ,
  PRIMARY KEY (`country_id`, `team_id`) ,
  INDEX `fk_Teams_has_Countries_Countries1` (`country_id` ASC) ,
  INDEX `fk_Team_has_country_Game_teams1` (`team_id` ASC) ,
  CONSTRAINT `fk_Teams_has_Countries_Countries1`
    FOREIGN KEY (`country_id` )
    REFERENCES `wwcdev`.`Countries` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Team_has_country_Game_teams1`
    FOREIGN KEY (`team_id` )
    REFERENCES `wwcdev`.`Game_teams` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Team_orders`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Team_orders` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Team_orders` (
  `id` INT NOT NULL ,
  `order` TEXT NULL ,
  `author_id` INT NOT NULL ,
  `timedate` INT NOT NULL COMMENT 'timestamp when orders were posted' ,
  `team_id` INT NOT NULL ,
  PRIMARY KEY (`id`, `author_id`, `team_id`) ,
  INDEX `fk_orders_players1` (`author_id` ASC) ,
  INDEX `fk_Orders_Game_teams1` (`team_id` ASC) ,
  CONSTRAINT `fk_orders_players1`
    FOREIGN KEY (`author_id` )
    REFERENCES `wwcdev`.`Players` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Orders_Game_teams1`
    FOREIGN KEY (`team_id` )
    REFERENCES `wwcdev`.`Game_teams` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Orders given by team commanders';


-- -----------------------------------------------------
-- Table `wwcdev`.`Default_resources`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Default_resources` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Default_resources` (
  `resource_id` INT NOT NULL ,
  `game_id` INT NOT NULL ,
  `resource_qty` INT NOT NULL COMMENT 'How many of resource is default?' ,
  PRIMARY KEY (`resource_id`, `game_id`) ,
  INDEX `fk_default_resources_Resources1` (`resource_id` ASC) ,
  INDEX `fk_default_resources_Games1` (`game_id` ASC) ,
  CONSTRAINT `fk_default_resources_Resources1`
    FOREIGN KEY (`resource_id` )
    REFERENCES `wwcdev`.`Resources` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_default_resources_Games1`
    FOREIGN KEY (`game_id` )
    REFERENCES `wwcdev`.`Games` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'List of default resources a player starts a game with';


-- -----------------------------------------------------
-- Table `wwcdev`.`Default_units`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Default_units` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Default_units` (
  `unit_id` INT NOT NULL ,
  `game_id` INT NOT NULL ,
  `unit_qty` INT NOT NULL ,
  PRIMARY KEY (`unit_id`, `game_id`) ,
  INDEX `fk_table1_Units1` (`unit_id` ASC, `unit_qty` ASC) ,
  INDEX `fk_default_units_Games1` (`game_id` ASC) ,
  CONSTRAINT `fk_table1_Units1`
    FOREIGN KEY (`unit_id` , `unit_qty` )
    REFERENCES `wwcdev`.`Units` (`id` , `id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_default_units_Games1`
    FOREIGN KEY (`game_id` )
    REFERENCES `wwcdev`.`Games` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Default_facilities`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Default_facilities` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Default_facilities` (
  `facility_id` INT NOT NULL ,
  `facility_qty` VARCHAR(45) NULL ,
  `game_id` INT NOT NULL ,
  PRIMARY KEY (`facility_id`, `game_id`) ,
  INDEX `fk_table1_Facilities1` (`facility_id` ASC) ,
  INDEX `fk_default_facilities_Games1` (`game_id` ASC) ,
  CONSTRAINT `fk_table1_Facilities1`
    FOREIGN KEY (`facility_id` )
    REFERENCES `wwcdev`.`Facilities` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_default_facilities_Games1`
    FOREIGN KEY (`game_id` )
    REFERENCES `wwcdev`.`Games` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Default_researches`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Default_researches` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Default_researches` (
  `research_id` INT NOT NULL ,
  `game_id` INT NOT NULL ,
  PRIMARY KEY (`research_id`, `game_id`) ,
  INDEX `fk_default_researches_Research1` (`research_id` ASC) ,
  INDEX `fk_default_researches_Games1` (`game_id` ASC) ,
  CONSTRAINT `fk_default_researches_Research1`
    FOREIGN KEY (`research_id` )
    REFERENCES `wwcdev`.`Research` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_default_researches_Games1`
    FOREIGN KEY (`game_id` )
    REFERENCES `wwcdev`.`Games` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Private_games`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Private_games` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Private_games` (
  `owner_id` INT NOT NULL COMMENT 'Private games must have an \'admin\' or an owner, this is the user id' ,
  `game_id` INT NOT NULL ,
  PRIMARY KEY (`owner_id`, `game_id`) ,
  INDEX `fk_private_games_Games1` (`game_id` ASC) ,
  INDEX `fk_private_games_users1` (`owner_id` ASC) ,
  CONSTRAINT `fk_private_games_Games1`
    FOREIGN KEY (`game_id` )
    REFERENCES `wwcdev`.`Games` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_private_games_users1`
    FOREIGN KEY (`owner_id` )
    REFERENCES `wwcdev`.`Users` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Game_invites`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Game_invites` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Game_invites` (
  `game_id` INT NOT NULL ,
  `user_id` INT NOT NULL ,
  PRIMARY KEY (`game_id`, `user_id`) ,
  INDEX `fk_game_invites_Games1` (`game_id` ASC) ,
  INDEX `fk_game_invites_users1` (`user_id` ASC) ,
  CONSTRAINT `fk_game_invites_Games1`
    FOREIGN KEY (`game_id` )
    REFERENCES `wwcdev`.`Games` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_game_invites_users1`
    FOREIGN KEY (`user_id` )
    REFERENCES `wwcdev`.`Users` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Full list of users who are invited to private games';


-- -----------------------------------------------------
-- Table `wwcdev`.`Country_in_region`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Country_in_region` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Country_in_region` (
  `country_id` INT NOT NULL ,
  `region_id` INT NOT NULL ,
  PRIMARY KEY (`country_id`, `region_id`) ,
  INDEX `fk_Countries_has_Regions_Countries1` (`country_id` ASC) ,
  INDEX `fk_Countries_has_Regions_Regions1` (`region_id` ASC) ,
  CONSTRAINT `fk_Countries_has_Regions_Countries1`
    FOREIGN KEY (`country_id` )
    REFERENCES `wwcdev`.`Countries` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Countries_has_Regions_Regions1`
    FOREIGN KEY (`region_id` )
    REFERENCES `wwcdev`.`Regions` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Setting_has_region`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Setting_has_region` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Setting_has_region` (
  `region_id` INT NOT NULL ,
  `setting_id` INT NOT NULL ,
  PRIMARY KEY (`region_id`, `setting_id`) ,
  INDEX `fk_Games_has_Regions_Regions1` (`region_id` ASC) ,
  INDEX `fk_Game_has_region_Settings1` (`setting_id` ASC) ,
  CONSTRAINT `fk_Games_has_Regions_Regions1`
    FOREIGN KEY (`region_id` )
    REFERENCES `wwcdev`.`Regions` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Game_has_region_Settings1`
    FOREIGN KEY (`setting_id` )
    REFERENCES `wwcdev`.`Settings` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Setting_has_team`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Setting_has_team` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Setting_has_team` (
  `setting_id` INT NOT NULL ,
  `team_id` INT NOT NULL ,
  PRIMARY KEY (`setting_id`, `team_id`) ,
  INDEX `fk_Settings_has_teams_Settings1` (`setting_id` ASC) ,
  INDEX `fk_Settings_has_teams_teams1` (`team_id` ASC) ,
  CONSTRAINT `fk_Settings_has_teams_Settings1`
    FOREIGN KEY (`setting_id` )
    REFERENCES `wwcdev`.`Settings` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Settings_has_teams_teams1`
    FOREIGN KEY (`team_id` )
    REFERENCES `wwcdev`.`Teams` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Setting_has_resource`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Setting_has_resource` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Setting_has_resource` (
  `setting_id` INT NOT NULL ,
  `resource_id` INT NOT NULL ,
  PRIMARY KEY (`setting_id`, `resource_id`) ,
  INDEX `fk_Settings_has_Resources_Settings1` (`setting_id` ASC) ,
  INDEX `fk_Settings_has_Resources_Resources1` (`resource_id` ASC) ,
  CONSTRAINT `fk_Settings_has_Resources_Settings1`
    FOREIGN KEY (`setting_id` )
    REFERENCES `wwcdev`.`Settings` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Settings_has_Resources_Resources1`
    FOREIGN KEY (`resource_id` )
    REFERENCES `wwcdev`.`Resources` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Setting_has_research`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Setting_has_research` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Setting_has_research` (
  `setting_id` INT NOT NULL ,
  `research_id` INT NOT NULL ,
  PRIMARY KEY (`setting_id`, `research_id`) ,
  INDEX `fk_Settings_has_Research_Settings1` (`setting_id` ASC) ,
  INDEX `fk_Settings_has_Research_Research1` (`research_id` ASC) ,
  CONSTRAINT `fk_Settings_has_Research_Settings1`
    FOREIGN KEY (`setting_id` )
    REFERENCES `wwcdev`.`Settings` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Settings_has_Research_Research1`
    FOREIGN KEY (`research_id` )
    REFERENCES `wwcdev`.`Research` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Setting_has_facility`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Setting_has_facility` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Setting_has_facility` (
  `setting_id` INT NOT NULL ,
  `facility_id` INT NOT NULL ,
  PRIMARY KEY (`setting_id`, `facility_id`) ,
  INDEX `fk_Settings_has_Facilities_Settings1` (`setting_id` ASC) ,
  INDEX `fk_Settings_has_Facilities_Facilities1` (`facility_id` ASC) ,
  CONSTRAINT `fk_Settings_has_Facilities_Settings1`
    FOREIGN KEY (`setting_id` )
    REFERENCES `wwcdev`.`Settings` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Settings_has_Facilities_Facilities1`
    FOREIGN KEY (`facility_id` )
    REFERENCES `wwcdev`.`Facilities` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Profiles`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Profiles` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Profiles` (
  `user_id` INT NOT NULL ,
  `name` VARCHAR(50) NULL ,
  `dob` INT NULL ,
  `location` VARCHAR(45) NULL ,
  `gender` ENUM('Male', 'Female', 'Unknown') NULL ,
  PRIMARY KEY (`user_id`) ,
  INDEX `fk_profiles_users1` (`user_id` ASC) ,
  CONSTRAINT `fk_profiles_users1`
    FOREIGN KEY (`user_id` )
    REFERENCES `wwcdev`.`Users` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Mail`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Mail` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Mail` (
  `id` INT NOT NULL ,
  `owner_id` INT NOT NULL ,
  `sender_id` INT NOT NULL ,
  `sent_timestamp` INT NOT NULL ,
  `title` VARCHAR(45) NULL ,
  `body` TEXT NULL ,
  `read` TINYINT(1) NULL DEFAULT 0 ,
  `deleted` TINYINT(1) NULL DEFAULT 0 ,
  PRIMARY KEY (`id`, `owner_id`, `sender_id`) ,
  INDEX `fk_table1_users1` (`owner_id` ASC) ,
  INDEX `fk_table1_users2` (`sender_id` ASC) ,
  CONSTRAINT `fk_table1_users1`
    FOREIGN KEY (`owner_id` )
    REFERENCES `wwcdev`.`Users` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_table1_users2`
    FOREIGN KEY (`sender_id` )
    REFERENCES `wwcdev`.`Users` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Logins`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Logins` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Logins` (
  `user_id` INT NOT NULL ,
  `login_timestamp` INT NOT NULL ,
  `ip` CHAR(15) NULL ,
  `browser_name` CHAR(20) NULL ,
  `browser_ver` CHAR(20) NULL ,
  `os` CHAR(40) NULL ,
  `user_agent` CHAR(50) NULL ,
  PRIMARY KEY (`user_id`, `login_timestamp`) ,
  INDEX `fk_table1_users3` (`user_id` ASC) ,
  CONSTRAINT `fk_table1_users3`
    FOREIGN KEY (`user_id` )
    REFERENCES `wwcdev`.`Users` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`User_has_medal`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`User_has_medal` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`User_has_medal` (
  `users_id` INT NOT NULL ,
  `medals_id` INT NOT NULL ,
  PRIMARY KEY (`users_id`, `medals_id`) ,
  INDEX `fk_users_has_medals_users1` (`users_id` ASC) ,
  INDEX `fk_users_has_medals_medals1` (`medals_id` ASC) ,
  CONSTRAINT `fk_users_has_medals_users1`
    FOREIGN KEY (`users_id` )
    REFERENCES `wwcdev`.`Users` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_has_medals_medals1`
    FOREIGN KEY (`medals_id` )
    REFERENCES `wwcdev`.`Medals` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Activation_codes`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Activation_codes` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Activation_codes` (
  `user_id` INT NOT NULL ,
  `code` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`user_id`) ,
  INDEX `fk_activation_codes_users1` (`user_id` ASC) ,
  CONSTRAINT `fk_activation_codes_users1`
    FOREIGN KEY (`user_id` )
    REFERENCES `wwcdev`.`Users` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'List of users that still need to activate account';


-- -----------------------------------------------------
-- Table `wwcdev`.`News`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`News` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`News` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `author_id` INT NOT NULL ,
  `title` VARCHAR(45) NOT NULL ,
  `post_timestamp` INT NOT NULL ,
  `body` TEXT NOT NULL ,
  INDEX `fk_Announcements_users1` (`author_id` ASC) ,
  PRIMARY KEY (`id`) ,
  CONSTRAINT `fk_Announcements_users1`
    FOREIGN KEY (`author_id` )
    REFERENCES `wwcdev`.`Users` (`id` )
    ON DELETE SET NULL
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`News_comments`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`News_comments` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`News_comments` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `news_id` INT NOT NULL ,
  `author_id` INT NOT NULL ,
  `body` TEXT NULL ,
  `comment_timestamp` INT NOT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `fk_table1_Announcements1` (`news_id` ASC) ,
  INDEX `fk_Announcement_comments_users1` (`author_id` ASC) ,
  CONSTRAINT `fk_table1_Announcements1`
    FOREIGN KEY (`news_id` )
    REFERENCES `wwcdev`.`News` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Announcement_comments_users1`
    FOREIGN KEY (`author_id` )
    REFERENCES `wwcdev`.`Users` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Country_coords`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Country_coords` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Country_coords` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `country_id` INT NOT NULL ,
  `coord_set` TEXT NOT NULL COMMENT 'Set of coords in x,x,x format where x is an int.' ,
  PRIMARY KEY (`id`, `country_id`) ,
  INDEX `fk_Country_coords_Countries1` (`country_id` ASC) ,
  CONSTRAINT `fk_Country_coords_Countries1`
    FOREIGN KEY (`country_id` )
    REFERENCES `wwcdev`.`Countries` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = MyISAM
COMMENT = 'List of all country coordinates';


-- -----------------------------------------------------
-- Table `wwcdev`.`Milita`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Milita` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Milita` (
  `country_id` INT NOT NULL ,
  `game_id` INT NOT NULL ,
  `milita_qty` INT NOT NULL ,
  PRIMARY KEY (`country_id`, `game_id`) ,
  INDEX `fk_Milita_Games1` (`game_id` ASC) ,
  INDEX `fk_Milita_Countries` (`country_id` ASC) ,
  CONSTRAINT `fk_Milita_Games1`
    FOREIGN KEY (`game_id` )
    REFERENCES `wwcdev`.`Games` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Milita_Countries`
    FOREIGN KEY (`country_id` )
    REFERENCES `wwcdev`.`Countries` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = MyISAM;


-- -----------------------------------------------------
-- Table `wwcdev`.`Setting_has_unit`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Setting_has_unit` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Setting_has_unit` (
  `setting_id` INT NOT NULL ,
  `unit_id` INT NOT NULL ,
  PRIMARY KEY (`setting_id`, `unit_id`) ,
  INDEX `fk_Settings_has_Units_Settings1` (`setting_id` ASC) ,
  INDEX `fk_Settings_has_Units_Units1` (`unit_id` ASC) ,
  CONSTRAINT `fk_Settings_has_Units_Settings1`
    FOREIGN KEY (`setting_id` )
    REFERENCES `wwcdev`.`Settings` (`id` )
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Settings_has_Units_Units1`
    FOREIGN KEY (`unit_id` )
    REFERENCES `wwcdev`.`Units` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wwcdev`.`Facility_produces_resource`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wwcdev`.`Facility_produces_resource` ;

CREATE  TABLE IF NOT EXISTS `wwcdev`.`Facility_produces_resource` (
  `resource_id` INT NOT NULL ,
  `facility_id` INT NOT NULL ,
  `resource_qty` INT NOT NULL DEFAULT 0 ,
  PRIMARY KEY (`resource_id`, `facility_id`) ,
  INDEX `fk_Facility_produces_resouce_Resources1` (`resource_id` ASC) ,
  INDEX `fk_Facility_produces_resouce_Facilities1` (`facility_id` ASC) ,
  CONSTRAINT `fk_Facility_produces_resouce_Resources1`
    FOREIGN KEY (`resource_id` )
    REFERENCES `wwcdev`.`Resources` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Facility_produces_resouce_Facilities1`
    FOREIGN KEY (`facility_id` )
    REFERENCES `wwcdev`.`Facilities` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


DELIMITER //
DROP procedure IF EXISTS `wwcdev`.`makeTeam` //
CREATE PROCEDURE makeTeam (name VARCHAR(45), colour CHAR(11), capital INT) 
	BEGIN
		DECLARE teamId INT;
		
		#Insert team
		INSERT INTO `teams` (`name`, `colour`, `capital`) VALUES (name, colour, capital);
		SET teamId = LAST_INSERT_ID();
		
		#Assign capital to be listed as a team owned country
		INSERT INTO `team_has_country` (`team_id`, `country_id`) VALUES (teamId, capital);

	END//
DROP function IF EXISTS `wwcdev`.`addPlayer` //
CREATE FUNCTION `addPlayer`(userid INT, gameid INT) RETURNS int(11)
BEGIN
		DECLARE playerId INT;
		DECLARE battalionId INT;
		DECLARE facilityLoc INT;
		DECLARE teamId INT;
		DECLARE teamInfoId INT;

SELECT `Game_teams`.`id` ,`Game_teams`.`team_id` INTO teamId, teamInfoId FROM `Game_teams` LEFT JOIN `Players` ON (`Game_teams`.`id` = `Players`.`team_id`) GROUP BY `Game_teams`.`id` ORDER BY COUNT(`Players`.`id`) ASC LIMIT 1	;	


				INSERT INTO `Players` (`user_id`, `game_id`, `team_id`) VALUES (userid, gameid, teamId);
				SET playerId = LAST_INSERT_ID();
		
				SELECT `capital` INTO facilityLoc FROM `Teams` WHERE `id` = teamInfoId;

				INSERT INTO `Battalion` (`player_id`, `country_id`) VALUES (playerId, facilityLoc);
		SET battalionId = LAST_INSERT_ID();
		INSERT INTO `Battalion_commanders` (`battalion_id`) VALUES (battalionId);

				INSERT INTO `Player_has_resource` (`resource_id`, `player_id`, `resource_qty`) 
			SELECT `resource_id`, playerId, `resource_qty` FROM `Default_resources` WHERE `game_id` = gameid;
		INSERT INTO `Player_has_unit` (`unit_id`, `battalion_id`, `unit_qty`) 
			SELECT `unit_id`, battalionId, `unit_qty` FROM `Default_units` WHERE `game_id` = gameid;
		INSERT INTO `Player_has_facility` (`facility_id`, `player_id`, `country_id`, `facility_qty`) 
			SELECT `facility_id`, playerId, facilityLoc , `facility_qty` FROM `Default_facilities` WHERE `game_id` = gameid;
		INSERT INTO `Player_has_research` (`player_id`, `research_id`)
			SELECT playerId, `research_id` FROM `Default_researches` WHERE `game_id` = gameid;
            RETURN playerId;		
 END//
DROP function IF EXISTS `wwcdev`.`makeUser` //
CREATE FUNCTION `makeUser`(username VARCHAR(45), plain_password VARCHAR(45), email VARCHAR(45), handle VARCHAR(45)) RETURNS int(11)
BEGIN
	DECLARE hashedPassword VARCHAR(45);
	DECLARE salt VARCHAR(45);
	DECLARE userId INT;

	SET salt = MD5(NOW());
	SET hashedPassword = MD5(CONCAT(salt,plain_password));

	INSERT INTO `Users` (`username`, `password`, `email`, `salt`, `handle`) VALUES (username, hashedPassword, email, MD5(NOW()), handle);
	SET userId = LAST_INSERT_ID();

		INSERT INTO `Activation_codes` (`user_id`, `code`) VALUES (userId, MD5(CONCAT(NOW(), username)));
		INSERT INTO `Profiles` (`user_id`) VALUES (userId);

	RETURN userId;

END//
DROP function IF EXISTS `wwcdev`.`userLogin` //
CREATE FUNCTION `userLogin`(user VARCHAR(45), plain_password VARCHAR(45)) RETURNS int(11)
BEGIN
	DECLARE userId INT;

	SELECT id INTO userId FROM `Users` WHERE `username`=user AND `password`=MD5(CONCAT(`salt`, plain_password)) LIMIT 1;
	
		RETURN IF(FOUND_ROWS() = 1, userId, -1);
END//

DELIMITER ;


-- -----------------------------------------------------
-- Data for table `wwcdev`.`Resources`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
USE `wwcdev`;
INSERT INTO `Resources` (`id`, `name`) VALUES (1, 'MONEY');
INSERT INTO `Resources` (`id`, `name`) VALUES (2, 'TURNS');
INSERT INTO `Resources` (`id`, `name`) VALUES (3, 'SUPPLIES');
INSERT INTO `Resources` (`id`, `name`) VALUES (4, 'OIL');

COMMIT;

-- -----------------------------------------------------
-- Data for table `wwcdev`.`Unit_stats`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
USE `wwcdev`;
INSERT INTO `Unit_stats` (`id`, `name`) VALUES (1, 'ATTACK');
INSERT INTO `Unit_stats` (`id`, `name`) VALUES (2, 'DEFENCE');
INSERT INTO `Unit_stats` (`id`, `name`) VALUES (3, 'EXPLOSIVE');
INSERT INTO `Unit_stats` (`id`, `name`) VALUES (4, 'AVASION');

COMMIT;

-- -----------------------------------------------------
-- Data for table `wwcdev`.`Unit_has_stats`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
USE `wwcdev`;
INSERT INTO `Unit_has_stats` (`unit_id`, `stat_id`, `stat_qty`) VALUES (1, 1, 10);
INSERT INTO `Unit_has_stats` (`unit_id`, `stat_id`, `stat_qty`) VALUES (1, 2, 20);

COMMIT;

-- -----------------------------------------------------
-- Data for table `wwcdev`.`Milita`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
USE `wwcdev`;
INSERT INTO `Milita` (`country_id`, `game_id`, `milita_qty`) VALUES (1, 1, 100);

COMMIT;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
