-- phpMyAdmin SQL Dump
-- version 3.2.2.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 11, 2009 at 10:06 PM
-- Server version: 5.1.37
-- PHP Version: 5.2.10-2ubuntu6.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `wwcdev`
--

--
-- Dumping data for table `Countries`
--

INSERT IGNORE INTO `Countries` (`id`, `name`, `default_milita`) VALUES
(1, 'A1', 100),
(2, 'A2', 100),
(3, 'B1', 100),
(4, 'B2', 100);

--
-- Dumping data for table `Country_has_border`
--

INSERT IGNORE INTO `Country_has_border` (`country_id`, `border_country`) VALUES
(1, 2),
(1, 3),
(2, 1),
(2, 4),
(3, 1),
(3, 4),
(4, 2),
(4, 3);
--
-- Dumping data for table `Facilities`
--

INSERT IGNORE INTO `Facilities` (`id`, `name`, `desc`) VALUES
(1, 'barracks', '');

--
-- Dumping data for table `Facility_requires_resource`
--

INSERT IGNORE INTO `Facility_requires_resource` (`facility_id`, `resource_id`, `resource_qty`) VALUES
(1, 1, 100),
(1, 2, 1);

--
-- Dumping data for table `Milita`
--

INSERT IGNORE INTO `Milita` (`country_id`, `game_id`, `milita_qty`) VALUES
(1, 1, 100);

--
-- Dumping data for table `Ranks`
--


--
-- Dumping data for table `Regions`
--

INSERT IGNORE INTO `Regions` (`id`, `name`) VALUES
(1, 'A-Land'),
(2, 'B-Land');

--
-- Dumping data for table `Region_has_resource`
--


--
-- Dumping data for table `Research`
--

INSERT IGNORE INTO `Research` (`id`, `name`, `desc`) VALUES
(1, 'Basic', ''),
(2, 'Basic 2', '');

--
-- Dumping data for table `Research_requires_research`
--

INSERT IGNORE INTO `Research_requires_research` (`research_id`, `required_research`) VALUES
(2, 1);

--
-- Dumping data for table `Research_requires_resource`
--


--
-- Dumping data for table `Resources`
--

INSERT IGNORE INTO `Resources` (`id`, `name`) VALUES
(1, 'MONEY'),
(2, 'TURNS'),
(3, 'SUPPLIES'),
(4, 'OIL');

--
-- Dumping data for table `Settings`
--

INSERT IGNORE INTO `Settings` (`id`, `max_players`, `has_generals`, `team_governments`, `player_governments`, `allow_team_treaties`, `natural_disasters`, `milita_growth`, `late_entry_time`, `cycle_time`, `name`, `desc`, `assim_rate`) VALUES
(1, 0, 0, 0, 0, 0, 0, 0, 86400, 180, 'Test setting', 'desc', 20);



--
-- Dumping data for table `Games`
--

INSERT IGNORE INTO `Games` (`id`, `setting_id`, `name`, `start_timestamp`, `desc`) VALUES
(1, 1, 'Game1', 1260568912, 'blahh');



INSERT IGNORE INTO `Unit_types` (`id`, `name`) VALUES
(1, 'LAND');

--
-- Dumping data for table `Units`
--

INSERT IGNORE INTO `Units` (`id`, `unit_type_id`, `name`) VALUES
(1, 1, 'troop1'),
(2, 1, 'troop2');

--
-- Dumping data for table `Units_requires_Countries`
--


--
-- Dumping data for table `UnitTypes`
--


--
-- Dumping data for table `Unit_has_stats`
--

INSERT IGNORE INTO `Unit_has_stats` (`unit_id`, `stat_id`, `stat_qty`) VALUES
(1, 1, 10),
(1, 2, 20);

--
-- Dumping data for table `Unit_requires_research`
--

INSERT IGNORE INTO `Unit_requires_research` (`unit_id`, `research_id`) VALUES
(2, 1);

--
-- Dumping data for table `Unit_requires_resource`
--


--
-- Dumping data for table `Unit_types`
--

--
-- Dumping data for table `Unit_stats`
--

INSERT IGNORE INTO `Unit_stats` (`id`, `name`) VALUES
(1, 'ATTACK'),
(2, 'DEFENCE'),
(3, 'EXPLOSIVE'),
(4, 'AVASION');

--
-- Dumping data for table `Users`
--

INSERT IGNORE INTO `Users` (`id`, `username`, `password`, `email`, `salt`, `handle`) VALUES
(1, 'cocacola999', '60efe94db0f2eb7d4d25cdbdce2bf6cb', 'email', '50394d87d80e35f3bc7e0d0d294a1927', 'Leeming');

--
-- Dumping data for table `User_has_medal`
--


--
-- Dumping data for table `Country_in_region`
--

INSERT IGNORE INTO `Country_in_region` (`country_id`, `region_id`) VALUES
(1, 1),
(2, 1),
(3, 2),
(4, 2);

INSERT INTO `Teams` (`id`, `name`, `colour`, `capital`) VALUES
(1, 'Team1', NULL, 1),
(2, 'Team2', NULL, 3);

--
-- Dumping data for table `Facility_builds_unit`
--

INSERT IGNORE INTO `Facility_builds_unit` (`facility_id`, `unit_id`, `unit_qty`) VALUES
(1, 1, 10);


INSERT IGNORE INTO `Profiles` (`user_id`, `name`, `dob`, `location`, `gender`) VALUES
(1, NULL, NULL, NULL, NULL);


SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

INSERT IGNORE INTO `Setting_has_country` (`country_id`, `setting_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1);

INSERT IGNORE INTO `Setting_has_facility` (`setting_id`, `facility_id`) VALUES
(1, 1);

INSERT IGNORE INTO `Setting_has_region` (`region_id`, `setting_id`) VALUES
(1, 1),
(2, 1);

INSERT IGNORE INTO `Setting_has_research` (`setting_id`, `research_id`) VALUES
(1, 1);

INSERT IGNORE INTO `Setting_has_resource` (`setting_id`, `resource_id`) VALUES
(1, 1),
(1, 2);


INSERT IGNORE INTO `Setting_has_unit` (`setting_id`, `unit_id`) VALUES
(1, 1),
(1, 2);

-- Add some play styles
INSERT INTO `Play_styles` (`id`, `name`) VALUES
(1, 'None'),
(2, 'Attacker'),
(3, 'Defender'),
(4, 'Cap Sitter'),
(5, 'Jetter'),
(6, 'Spy');
