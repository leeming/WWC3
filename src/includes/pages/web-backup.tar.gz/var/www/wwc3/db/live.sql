-- phpMyAdmin SQL Dump
-- version 3.2.2.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 02, 2010 at 08:49 PM
-- Server version: 5.1.37
-- PHP Version: 5.2.10-2ubuntu6.3

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `wwcdev`
--

-- --------------------------------------------------------

--
-- Table structure for table `Activation_codes`
--

DROP TABLE IF EXISTS `Activation_codes`;
CREATE TABLE IF NOT EXISTS `Activation_codes` (
  `user_id` int(11) NOT NULL,
  `code` varchar(45) NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `fk_activation_codes_users1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='List of users that still need to activate account';

--
-- Dumping data for table `Activation_codes`
--

INSERT INTO `Activation_codes` (`user_id`, `code`) VALUES
(2, 'cae87fb3521995e68e2a6f9ed1ce4547'),
(3, 'daacb1d6e646a06d11163b63979869e6'),
(4, 'dbd044f38d2b7cf0554ac85b65e1a550'),
(5, 'ff8f91dc9a6c388c1c094bddbfea9b95');

-- --------------------------------------------------------

--
-- Table structure for table `Battalion`
--

DROP TABLE IF EXISTS `Battalion`;
CREATE TABLE IF NOT EXISTS `Battalion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `player_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL DEFAULT 'Default Battalion' COMMENT 'Name of the battalion',
  `country_id` int(11) NOT NULL COMMENT 'Location of battalion',
  PRIMARY KEY (`id`,`player_id`,`country_id`),
  KEY `fk_battalion_players1` (`player_id`),
  KEY `fk_battalion_Countries1` (`country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='List of battalions in game' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `Battalion`
--

INSERT INTO `Battalion` (`id`, `player_id`, `name`, `country_id`) VALUES
(1, 1, 'Default Battalion', 1),
(4, 4, 'Default Battalion', 1),
(6, 6, 'Default Battalion', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Battalion_commanders`
--

DROP TABLE IF EXISTS `Battalion_commanders`;
CREATE TABLE IF NOT EXISTS `Battalion_commanders` (
  `battalion_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL COMMENT 'Name of the battalion commander',
  `exp` int(11) DEFAULT '0',
  PRIMARY KEY (`battalion_id`),
  KEY `fk_battalion_commanders_battalion1` (`battalion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='List of battalion commanders';

--
-- Dumping data for table `Battalion_commanders`
--

INSERT INTO `Battalion_commanders` (`battalion_id`, `name`, `exp`) VALUES
(1, 'Unnamed', 0),
(4, '', 0),
(6, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Countries`
--

DROP TABLE IF EXISTS `Countries`;
CREATE TABLE IF NOT EXISTS `Countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(20) NOT NULL COMMENT 'Name of the country',
  `default_milita` int(11) NOT NULL DEFAULT '100',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `Countries`
--

INSERT INTO `Countries` (`id`, `name`, `default_milita`) VALUES
(1, 'A1', 100),
(2, 'A2', 100),
(3, 'B1', 100),
(4, 'B2', 100);

-- --------------------------------------------------------

--
-- Table structure for table `Country_coords`
--

DROP TABLE IF EXISTS `Country_coords`;
CREATE TABLE IF NOT EXISTS `Country_coords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) NOT NULL,
  `coord_set` text NOT NULL COMMENT 'Set of coords in x,x,x format where x is an int.',
  PRIMARY KEY (`id`,`country_id`),
  KEY `fk_Country_coords_Countries1` (`country_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='List of all country coordinates' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `Country_coords`
--


-- --------------------------------------------------------

--
-- Table structure for table `Country_has_border`
--

DROP TABLE IF EXISTS `Country_has_border`;
CREATE TABLE IF NOT EXISTS `Country_has_border` (
  `country_id` int(11) NOT NULL,
  `border_country` int(11) NOT NULL,
  PRIMARY KEY (`country_id`,`border_country`),
  KEY `fk_Countries_Countries_has_Countries` (`country_id`),
  KEY `fk_Countries_Countries_has_Countries1` (`border_country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Country_has_border`
--

INSERT INTO `Country_has_border` (`country_id`, `border_country`) VALUES
(1, 2),
(1, 3),
(2, 1),
(2, 4),
(3, 1),
(3, 4),
(4, 2),
(4, 3);

-- --------------------------------------------------------

--
-- Table structure for table `Country_has_resource`
--

DROP TABLE IF EXISTS `Country_has_resource`;
CREATE TABLE IF NOT EXISTS `Country_has_resource` (
  `country_id` int(11) NOT NULL,
  `resource_id` int(11) NOT NULL,
  `resource_qty` int(11) NOT NULL,
  PRIMARY KEY (`country_id`,`resource_id`),
  KEY `fk_Countries_Countries_has_Resources1` (`country_id`),
  KEY `fk_Resources_Countries_has_Resources1` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='resources to be applied to a country bonus';

--
-- Dumping data for table `Country_has_resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `Country_in_region`
--

DROP TABLE IF EXISTS `Country_in_region`;
CREATE TABLE IF NOT EXISTS `Country_in_region` (
  `country_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  PRIMARY KEY (`country_id`,`region_id`),
  KEY `fk_Countries_has_Regions_Countries1` (`country_id`),
  KEY `fk_Countries_has_Regions_Regions1` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Country_in_region`
--

INSERT INTO `Country_in_region` (`country_id`, `region_id`) VALUES
(1, 1),
(2, 1),
(3, 2),
(4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Default_facilities`
--

DROP TABLE IF EXISTS `Default_facilities`;
CREATE TABLE IF NOT EXISTS `Default_facilities` (
  `facility_id` int(11) NOT NULL,
  `facility_qty` varchar(45) DEFAULT NULL,
  `game_id` int(11) NOT NULL,
  PRIMARY KEY (`facility_id`,`game_id`),
  KEY `fk_table1_Facilities1` (`facility_id`),
  KEY `fk_default_facilities_Games1` (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Default_facilities`
--

INSERT INTO `Default_facilities` (`facility_id`, `facility_qty`, `game_id`) VALUES
(1, '90', 8);

-- --------------------------------------------------------

--
-- Table structure for table `Default_researches`
--

DROP TABLE IF EXISTS `Default_researches`;
CREATE TABLE IF NOT EXISTS `Default_researches` (
  `research_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  PRIMARY KEY (`research_id`,`game_id`),
  KEY `fk_default_researches_Research1` (`research_id`),
  KEY `fk_default_researches_Games1` (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Default_researches`
--

INSERT INTO `Default_researches` (`research_id`, `game_id`) VALUES
(1, 8),
(2, 8);

-- --------------------------------------------------------

--
-- Table structure for table `Default_resources`
--

DROP TABLE IF EXISTS `Default_resources`;
CREATE TABLE IF NOT EXISTS `Default_resources` (
  `resource_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `resource_qty` int(11) NOT NULL COMMENT 'How many of resource is default?',
  PRIMARY KEY (`resource_id`,`game_id`),
  KEY `fk_default_resources_Resources1` (`resource_id`),
  KEY `fk_default_resources_Games1` (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='List of default resources a player starts a game with';

--
-- Dumping data for table `Default_resources`
--

INSERT INTO `Default_resources` (`resource_id`, `game_id`, `resource_qty`) VALUES
(1, 8, 123),
(3, 8, 321);

-- --------------------------------------------------------

--
-- Table structure for table `Default_units`
--

DROP TABLE IF EXISTS `Default_units`;
CREATE TABLE IF NOT EXISTS `Default_units` (
  `unit_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `unit_qty` int(11) NOT NULL,
  PRIMARY KEY (`unit_id`,`game_id`),
  KEY `fk_table1_Units1` (`unit_id`),
  KEY `fk_default_units_Games1` (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Default_units`
--

INSERT INTO `Default_units` (`unit_id`, `game_id`, `unit_qty`) VALUES
(1, 8, 1234567);

-- --------------------------------------------------------

--
-- Table structure for table `Facilities`
--

DROP TABLE IF EXISTS `Facilities`;
CREATE TABLE IF NOT EXISTS `Facilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL COMMENT 'Name of the facility',
  `desc` char(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Table of all the different types of buidings' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `Facilities`
--

INSERT INTO `Facilities` (`id`, `name`, `desc`) VALUES
(1, 'barracks', '');

-- --------------------------------------------------------

--
-- Table structure for table `Facility_builds_unit`
--

DROP TABLE IF EXISTS `Facility_builds_unit`;
CREATE TABLE IF NOT EXISTS `Facility_builds_unit` (
  `facility_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `unit_qty` int(11) DEFAULT NULL COMMENT 'Production weighting, ie number of units a single facility produces',
  PRIMARY KEY (`facility_id`,`unit_id`),
  KEY `fk_Facilities_Facilities_has_Units1` (`facility_id`),
  KEY `fk_Units_Facilities_has_Units1` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Facilities build units also how many per turn';

--
-- Dumping data for table `Facility_builds_unit`
--

INSERT INTO `Facility_builds_unit` (`facility_id`, `unit_id`, `unit_qty`) VALUES
(1, 1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `Facility_produces_resource`
--

DROP TABLE IF EXISTS `Facility_produces_resource`;
CREATE TABLE IF NOT EXISTS `Facility_produces_resource` (
  `resource_id` int(11) NOT NULL,
  `facility_id` int(11) NOT NULL,
  `resource_qty` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`resource_id`,`facility_id`),
  KEY `fk_Facility_produces_resouce_Resources1` (`resource_id`),
  KEY `fk_Facility_produces_resouce_Facilities1` (`facility_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Facility_produces_resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `Facility_requires_research`
--

DROP TABLE IF EXISTS `Facility_requires_research`;
CREATE TABLE IF NOT EXISTS `Facility_requires_research` (
  `facility_id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  PRIMARY KEY (`facility_id`,`research_id`),
  KEY `fk_Facilities_Facilities_has_Advancements1` (`facility_id`),
  KEY `fk_Advancements_Facilities_has_Advancements1` (`research_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='research requirements to be able to build facility';

--
-- Dumping data for table `Facility_requires_research`
--


-- --------------------------------------------------------

--
-- Table structure for table `Facility_requires_resource`
--

DROP TABLE IF EXISTS `Facility_requires_resource`;
CREATE TABLE IF NOT EXISTS `Facility_requires_resource` (
  `facility_id` int(11) NOT NULL,
  `resource_id` int(11) NOT NULL,
  `resource_qty` int(11) NOT NULL COMMENT 'The number of resources needed to build',
  PRIMARY KEY (`facility_id`,`resource_id`),
  KEY `fk_Facilities_Facilities_has_Resources1` (`facility_id`),
  KEY `fk_Resources_Facilities_has_Resources1` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='List the resource costs of building a facility';

--
-- Dumping data for table `Facility_requires_resource`
--

INSERT INTO `Facility_requires_resource` (`facility_id`, `resource_id`, `resource_qty`) VALUES
(1, 1, 100),
(1, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Games`
--

DROP TABLE IF EXISTS `Games`;
CREATE TABLE IF NOT EXISTS `Games` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `start_timestamp` int(11) DEFAULT NULL COMMENT 'Timestamp when the game started/will start',
  `desc` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`,`setting_id`),
  KEY `fk_Games_Settings1` (`setting_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `Games`
--

INSERT INTO `Games` (`id`, `setting_id`, `name`, `start_timestamp`, `desc`) VALUES
(8, 1, 'test restart', 1261253657, 'heheheh'),
(9, 1, 'Game1', 1262055591, 'Description of game1'),
(10, 1, 'Game 2', 1262055999, 'Another game but this is game 2');

-- --------------------------------------------------------

--
-- Table structure for table `Game_invites`
--

DROP TABLE IF EXISTS `Game_invites`;
CREATE TABLE IF NOT EXISTS `Game_invites` (
  `game_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`game_id`,`user_id`),
  KEY `fk_game_invites_Games1` (`game_id`),
  KEY `fk_game_invites_users1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Full list of users who are invited to private games';

--
-- Dumping data for table `Game_invites`
--


-- --------------------------------------------------------

--
-- Table structure for table `Game_teams`
--

DROP TABLE IF EXISTS `Game_teams`;
CREATE TABLE IF NOT EXISTS `Game_teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fk_Game_teams_UNIQUE` (`game_id`,`team_id`),
  KEY `fk_Game_teams_Games1` (`game_id`),
  KEY `fk_Game_teams_Teams1` (`team_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `Game_teams`
--

INSERT INTO `Game_teams` (`id`, `game_id`, `team_id`) VALUES
(15, 8, 1),
(16, 8, 2),
(17, 9, 1),
(18, 9, 2),
(19, 10, 1),
(20, 10, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Logins`
--

DROP TABLE IF EXISTS `Logins`;
CREATE TABLE IF NOT EXISTS `Logins` (
  `user_id` int(11) NOT NULL,
  `login_timestamp` int(11) NOT NULL,
  `ip` char(15) DEFAULT NULL,
  `browser_name` char(20) DEFAULT NULL,
  `browser_ver` char(20) DEFAULT NULL,
  `os` char(40) DEFAULT NULL,
  `user_agent` char(50) DEFAULT NULL,
  PRIMARY KEY (`user_id`,`login_timestamp`),
  KEY `fk_table1_users3` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Logins`
--

INSERT INTO `Logins` (`user_id`, `login_timestamp`, `ip`, `browser_name`, `browser_ver`, `os`, `user_agent`) VALUES
(1, 1261165121, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1261169351, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1261250444, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1261256162, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1261405933, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1261410688, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262044752, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262045262, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262048125, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262048332, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262049923, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262050144, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262050399, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262050653, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262050709, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262050746, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262051221, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262052537, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262053129, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262054043, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262054170, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262055285, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262056338, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262056588, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262056776, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262056865, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262056927, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262122200, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262122715, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262122812, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262122899, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262122913, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262123183, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262126366, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262138995, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262138999, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262139017, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262139023, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262139557, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262139575, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262139664, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262141867, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262142126, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262142617, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262142784, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262188195, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262189634, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5'),
(1, 1262265042, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262265252, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262265371, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262265483, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262265873, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262266594, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262266704, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262288947, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262289553, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262360666, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262360694, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262361823, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262361881, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262362538, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262362673, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262362701, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262363865, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262363904, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262363943, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262403094, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262403220, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262403379, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262445637, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262453429, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262459297, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262459377, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262460130, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262460275, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262460290, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262460363, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(1, 1262461754, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.6'),
(3, 1262129960, '127.0.0.1', '', '', '', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.1.5');

-- --------------------------------------------------------

--
-- Table structure for table `Mail`
--

DROP TABLE IF EXISTS `Mail`;
CREATE TABLE IF NOT EXISTS `Mail` (
  `id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `sent_timestamp` int(11) NOT NULL,
  `title` varchar(45) DEFAULT NULL,
  `body` text,
  `read` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`,`owner_id`,`sender_id`),
  KEY `fk_table1_users1` (`owner_id`),
  KEY `fk_table1_users2` (`sender_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Mail`
--


-- --------------------------------------------------------

--
-- Table structure for table `Medals`
--

DROP TABLE IF EXISTS `Medals`;
CREATE TABLE IF NOT EXISTS `Medals` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `desc` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Medals`
--


-- --------------------------------------------------------

--
-- Table structure for table `Milita`
--

DROP TABLE IF EXISTS `Milita`;
CREATE TABLE IF NOT EXISTS `Milita` (
  `country_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `milita_qty` int(11) NOT NULL,
  PRIMARY KEY (`country_id`,`game_id`),
  KEY `fk_Milita_Games1` (`game_id`),
  KEY `fk_Milita_Countries` (`country_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Milita`
--

INSERT INTO `Milita` (`country_id`, `game_id`, `milita_qty`) VALUES
(4, 9, 100),
(3, 9, 100),
(2, 9, 100),
(1, 9, 100),
(4, 8, 100),
(3, 8, 100),
(2, 8, 100),
(1, 8, 100),
(1, 10, 100),
(2, 10, 100),
(3, 10, 100),
(4, 10, 100);

-- --------------------------------------------------------

--
-- Table structure for table `News`
--

DROP TABLE IF EXISTS `News`;
CREATE TABLE IF NOT EXISTS `News` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_id` int(11) NOT NULL,
  `title` varchar(45) NOT NULL,
  `post_timestamp` int(11) NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY (`id`,`author_id`),
  KEY `fk_Announcements_users1` (`author_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `News`
--

INSERT INTO `News` (`id`, `author_id`, `title`, `post_timestamp`, `body`) VALUES
(1, 1, 'Example News', 1262126122, '[b]Things todo:[/b]\r\n[list]\r\n[*]Improve the Game browser page <i>Partly done</i>\r\n[*]Try to add history &amp; Refresh functions to windows\r\n[*]Start to implement game functionality\r\n[*]Make News.Class and page <i>Started</i>\r\n[*]Make Mail.class and page\r\n	[/list]\r\n	\r\n	Other misc stuff\r\n	[list]\r\n		\r\n		[*]All feedback pages (later)\r\n		\r\n		[*]Help sections (later)\r\n		\r\n		[*]Forum.class and page\r\n		\r\n		[*]Chat.class and page\r\n	[/list]'),
(2, 1, 'News now working', 123456920, 'Woot!');

-- --------------------------------------------------------

--
-- Table structure for table `News_comments`
--

DROP TABLE IF EXISTS `News_comments`;
CREATE TABLE IF NOT EXISTS `News_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `body` text,
  `comment_timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_table1_Announcements1` (`news_id`),
  KEY `fk_Announcement_comments_users1` (`author_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `News_comments`
--

INSERT INTO `News_comments` (`id`, `news_id`, `author_id`, `body`, `comment_timestamp`) VALUES
(1, 1, 1, 'ok lets try again', 1262445909),
(2, 1, 1, 'another comment justntonseenif <b>it works</b>ncorretly [b]and if bbcode words[/b]!!!', 1262449557),
(3, 1, 1, 'Third time luck?', 1262449649),
(4, 1, 1, 'Whoops forgot to change some thing, forth time!', 1262449686),
(5, 1, 1, 'humm problemnwithnnewlines', 1262449868),
(6, 1, 1, 'testnagainnwith nnl', 1262450519),
(7, 1, 1, 'andnagainnplz?', 1262450618),
(8, 1, 1, 'mehnagain', 1262450679),
(9, 1, 1, 'testnthis', 1262450951),
(10, 1, 1, 'testingncleanntext', 1262450984),
(11, 1, 1, 'another<br />nbloody <br />ntest<br />n', 1262451549),
(12, 1, 1, 'does\r\nthis\r\nwork\r\nwith\r\nnew\r\nlineS?', 1262450984),
(13, 1, 1, 'nwqnlwqde', 1262451886),
(14, 1, 1, 'xcznxzfcddnggn', 1262451923),
(15, 1, 1, 'try\nafa\nk', 1262452071),
(16, 1, 1, 'yawn ', 1262452678);

-- --------------------------------------------------------

--
-- Table structure for table `Players`
--

DROP TABLE IF EXISTS `Players`;
CREATE TABLE IF NOT EXISTS `Players` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `style_id` int(11) NOT NULL DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fk_unique` (`user_id`,`game_id`),
  KEY `fk_players_Play_styles1` (`style_id`),
  KEY `fk_players_Games1` (`game_id`),
  KEY `fk_players_users1` (`user_id`),
  KEY `fk_Players_Game_teams1` (`team_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `Players`
--

INSERT INTO `Players` (`id`, `style_id`, `user_id`, `game_id`, `team_id`) VALUES
(1, 1, 1, 8, 15),
(4, 1, 1, 10, 19),
(6, 1, 1, 9, 17);

-- --------------------------------------------------------

--
-- Table structure for table `Player_has_facility`
--

DROP TABLE IF EXISTS `Player_has_facility`;
CREATE TABLE IF NOT EXISTS `Player_has_facility` (
  `facility_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `facility_qty` int(11) NOT NULL,
  PRIMARY KEY (`player_id`,`facility_id`,`country_id`),
  KEY `fk_players_players_has_Facilities1` (`player_id`),
  KEY `fk_Facilities_players_has_Facilities1` (`facility_id`),
  KEY `fk_player_has_Facility_Countries1` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Player_has_facility`
--

INSERT INTO `Player_has_facility` (`facility_id`, `player_id`, `country_id`, `facility_qty`) VALUES
(1, 1, 1, 90);

-- --------------------------------------------------------

--
-- Table structure for table `Player_has_research`
--

DROP TABLE IF EXISTS `Player_has_research`;
CREATE TABLE IF NOT EXISTS `Player_has_research` (
  `player_id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  PRIMARY KEY (`player_id`,`research_id`),
  KEY `fk_players_players_has_Advancements1` (`player_id`),
  KEY `fk_Advancements_players_has_Advancements1` (`research_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Player_has_research`
--

INSERT INTO `Player_has_research` (`player_id`, `research_id`) VALUES
(1, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Player_has_resource`
--

DROP TABLE IF EXISTS `Player_has_resource`;
CREATE TABLE IF NOT EXISTS `Player_has_resource` (
  `resource_id` int(11) NOT NULL,
  `player_id` int(11) NOT NULL,
  `resource_qty` int(11) DEFAULT NULL,
  PRIMARY KEY (`player_id`,`resource_id`),
  KEY `fk_Resources_players_has_Resources1` (`resource_id`),
  KEY `fk_player_has_Resource_players1` (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Player_has_resource`
--

INSERT INTO `Player_has_resource` (`resource_id`, `player_id`, `resource_qty`) VALUES
(1, 1, 123),
(3, 1, 321);

-- --------------------------------------------------------

--
-- Table structure for table `Player_has_unit`
--

DROP TABLE IF EXISTS `Player_has_unit`;
CREATE TABLE IF NOT EXISTS `Player_has_unit` (
  `unit_id` int(11) NOT NULL,
  `battalion_id` int(11) NOT NULL,
  `unit_qty` int(11) NOT NULL,
  PRIMARY KEY (`unit_id`,`battalion_id`),
  KEY `fk_Units_players_has_Units1` (`unit_id`),
  KEY `fk_battallion_player_has_unit1` (`battalion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Player_has_unit`
--

INSERT INTO `Player_has_unit` (`unit_id`, `battalion_id`, `unit_qty`) VALUES
(1, 1, 1234567);

-- --------------------------------------------------------

--
-- Table structure for table `Player_research_queue`
--

DROP TABLE IF EXISTS `Player_research_queue`;
CREATE TABLE IF NOT EXISTS `Player_research_queue` (
  `player_id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  PRIMARY KEY (`player_id`,`research_id`),
  KEY `fk_player_research_queue_players1` (`player_id`),
  KEY `fk_player_research_queue_Research1` (`research_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='List of queued research for players';

--
-- Dumping data for table `Player_research_queue`
--


-- --------------------------------------------------------

--
-- Table structure for table `Play_styles`
--

DROP TABLE IF EXISTS `Play_styles`;
CREATE TABLE IF NOT EXISTS `Play_styles` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Play_styles`
--

INSERT INTO `Play_styles` (`id`, `name`) VALUES
(1, 'None'),
(2, 'Attacker'),
(3, 'Defender'),
(4, 'Cap Sitter'),
(5, 'Jetter'),
(6, 'Spy');

-- --------------------------------------------------------

--
-- Table structure for table `Private_games`
--

DROP TABLE IF EXISTS `Private_games`;
CREATE TABLE IF NOT EXISTS `Private_games` (
  `owner_id` int(11) NOT NULL COMMENT 'Private games must have an ''admin'' or an owner, this is the user id',
  `game_id` int(11) NOT NULL,
  PRIMARY KEY (`owner_id`,`game_id`),
  KEY `fk_private_games_Games1` (`game_id`),
  KEY `fk_private_games_users1` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Private_games`
--


-- --------------------------------------------------------

--
-- Table structure for table `Profiles`
--

DROP TABLE IF EXISTS `Profiles`;
CREATE TABLE IF NOT EXISTS `Profiles` (
  `user_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `dob` int(11) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  `gender` enum('Male','Female','Unknown') DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `fk_profiles_users1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Profiles`
--

INSERT INTO `Profiles` (`user_id`, `name`, `dob`, `location`, `gender`) VALUES
(1, NULL, NULL, NULL, NULL),
(2, NULL, NULL, NULL, NULL),
(3, NULL, NULL, NULL, NULL),
(4, NULL, NULL, NULL, NULL),
(5, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Ranks`
--

DROP TABLE IF EXISTS `Ranks`;
CREATE TABLE IF NOT EXISTS `Ranks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `available` int(11) NOT NULL COMMENT 'The number of players who can have this rank',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `Ranks`
--


-- --------------------------------------------------------

--
-- Table structure for table `Regions`
--

DROP TABLE IF EXISTS `Regions`;
CREATE TABLE IF NOT EXISTS `Regions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(20) NOT NULL COMMENT 'Name of Region',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Regions are collection of countries, ie Continents' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `Regions`
--

INSERT INTO `Regions` (`id`, `name`) VALUES
(1, 'A-Land'),
(2, 'B-Land');

-- --------------------------------------------------------

--
-- Table structure for table `Region_has_resource`
--

DROP TABLE IF EXISTS `Region_has_resource`;
CREATE TABLE IF NOT EXISTS `Region_has_resource` (
  `region_id` int(11) NOT NULL,
  `resource_id` int(11) NOT NULL,
  `resource_qty` int(11) NOT NULL DEFAULT '0' COMMENT 'The number of resources to give as bonus',
  PRIMARY KEY (`resource_id`,`region_id`),
  KEY `fk_Regions_Regions_has_Resources1` (`region_id`),
  KEY `fk_Resources_Regions_has_Resources1` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='resources to be applied to a region bonus';

--
-- Dumping data for table `Region_has_resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `Research`
--

DROP TABLE IF EXISTS `Research`;
CREATE TABLE IF NOT EXISTS `Research` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL COMMENT 'Name of the research',
  `desc` varchar(100) DEFAULT NULL COMMENT 'Description of the research which is visible to users',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Holds all research details' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `Research`
--

INSERT INTO `Research` (`id`, `name`, `desc`) VALUES
(1, 'Basic', ''),
(2, 'Basic 2', '');

-- --------------------------------------------------------

--
-- Table structure for table `Research_requires_research`
--

DROP TABLE IF EXISTS `Research_requires_research`;
CREATE TABLE IF NOT EXISTS `Research_requires_research` (
  `research_id` int(11) NOT NULL,
  `required_research` int(11) NOT NULL COMMENT 'Research which needs to be done before research_id can be done',
  PRIMARY KEY (`research_id`,`required_research`),
  KEY `fk_Advancements_Advancements_has_Advancements` (`research_id`),
  KEY `fk_Advancements_Advancements_has_Advancements1` (`required_research`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='List of all research adjacent pre requirements';

--
-- Dumping data for table `Research_requires_research`
--

INSERT INTO `Research_requires_research` (`research_id`, `required_research`) VALUES
(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Research_requires_resource`
--

DROP TABLE IF EXISTS `Research_requires_resource`;
CREATE TABLE IF NOT EXISTS `Research_requires_resource` (
  `research_id` int(11) NOT NULL,
  `resource_id` int(11) NOT NULL,
  `resource_qty` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`research_id`,`resource_id`),
  KEY `fk_Advancements_Advancements_has_Resources1` (`research_id`),
  KEY `fk_Resources_Advancements_has_Resources1` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Resources needed to do research eg Turns or money';

--
-- Dumping data for table `Research_requires_resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `Resources`
--

DROP TABLE IF EXISTS `Resources`;
CREATE TABLE IF NOT EXISTS `Resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(20) DEFAULT NULL COMMENT 'Name of resource type',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Table holding all resources used in game' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `Resources`
--

INSERT INTO `Resources` (`id`, `name`) VALUES
(1, 'MONEY'),
(2, 'TURNS'),
(3, 'SUPPLIES'),
(4, 'OIL');

-- --------------------------------------------------------

--
-- Table structure for table `Settings`
--

DROP TABLE IF EXISTS `Settings`;
CREATE TABLE IF NOT EXISTS `Settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `max_players` int(11) NOT NULL DEFAULT '0' COMMENT 'If >0, max number of players allowed to play game',
  `has_generals` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `team_governments` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Allow teams to have governments (give bonuses depending on type of gov) ',
  `player_governments` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Allow players to have governments (give bonuses depending on type of gov) ',
  `allow_team_treaties` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Allow teams to have treaties/allies',
  `natural_disasters` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Turn natural disasters on/off',
  `milita_growth` int(11) NOT NULL DEFAULT '0' COMMENT 'Higher this value the more milita grows per turn, 0 is no growth',
  `late_entry_time` int(11) NOT NULL DEFAULT '86400' COMMENT 'Number of seconds after start of game players can still join the game. Default is 1 day',
  `cycle_time` int(11) NOT NULL DEFAULT '180' COMMENT 'Number of seconds for each turn',
  `name` char(15) DEFAULT NULL COMMENT 'Name to identify setting',
  `desc` char(50) DEFAULT NULL COMMENT 'Short description of setting',
  `assim_rate` int(11) NOT NULL DEFAULT '20' COMMENT 'Number of cycles needed for country to be 100% assim',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `Settings`
--

INSERT INTO `Settings` (`id`, `max_players`, `has_generals`, `team_governments`, `player_governments`, `allow_team_treaties`, `natural_disasters`, `milita_growth`, `late_entry_time`, `cycle_time`, `name`, `desc`, `assim_rate`) VALUES
(1, 0, 0, 0, 0, 0, 0, 0, 864000, 180, 'Test setting', 'desc', 20);

-- --------------------------------------------------------

--
-- Table structure for table `Setting_has_country`
--

DROP TABLE IF EXISTS `Setting_has_country`;
CREATE TABLE IF NOT EXISTS `Setting_has_country` (
  `country_id` int(11) NOT NULL,
  `setting_id` int(11) NOT NULL,
  PRIMARY KEY (`country_id`,`setting_id`),
  KEY `fk_Game_has_Country_Countries1` (`country_id`),
  KEY `fk_Game_has_Country_Settings1` (`setting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Setting_has_country`
--

INSERT INTO `Setting_has_country` (`country_id`, `setting_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Setting_has_facility`
--

DROP TABLE IF EXISTS `Setting_has_facility`;
CREATE TABLE IF NOT EXISTS `Setting_has_facility` (
  `setting_id` int(11) NOT NULL,
  `facility_id` int(11) NOT NULL,
  PRIMARY KEY (`setting_id`,`facility_id`),
  KEY `fk_Settings_has_Facilities_Settings1` (`setting_id`),
  KEY `fk_Settings_has_Facilities_Facilities1` (`facility_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Setting_has_facility`
--

INSERT INTO `Setting_has_facility` (`setting_id`, `facility_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Setting_has_region`
--

DROP TABLE IF EXISTS `Setting_has_region`;
CREATE TABLE IF NOT EXISTS `Setting_has_region` (
  `region_id` int(11) NOT NULL,
  `setting_id` int(11) NOT NULL,
  PRIMARY KEY (`region_id`,`setting_id`),
  KEY `fk_Games_has_Regions_Regions1` (`region_id`),
  KEY `fk_Game_has_region_Settings1` (`setting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Setting_has_region`
--

INSERT INTO `Setting_has_region` (`region_id`, `setting_id`) VALUES
(1, 1),
(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Setting_has_research`
--

DROP TABLE IF EXISTS `Setting_has_research`;
CREATE TABLE IF NOT EXISTS `Setting_has_research` (
  `setting_id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  PRIMARY KEY (`setting_id`,`research_id`),
  KEY `fk_Settings_has_Research_Settings1` (`setting_id`),
  KEY `fk_Settings_has_Research_Research1` (`research_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Setting_has_research`
--

INSERT INTO `Setting_has_research` (`setting_id`, `research_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Setting_has_resource`
--

DROP TABLE IF EXISTS `Setting_has_resource`;
CREATE TABLE IF NOT EXISTS `Setting_has_resource` (
  `setting_id` int(11) NOT NULL,
  `resource_id` int(11) NOT NULL,
  PRIMARY KEY (`setting_id`,`resource_id`),
  KEY `fk_Settings_has_Resources_Settings1` (`setting_id`),
  KEY `fk_Settings_has_Resources_Resources1` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Setting_has_resource`
--

INSERT INTO `Setting_has_resource` (`setting_id`, `resource_id`) VALUES
(1, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Setting_has_team`
--

DROP TABLE IF EXISTS `Setting_has_team`;
CREATE TABLE IF NOT EXISTS `Setting_has_team` (
  `setting_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  PRIMARY KEY (`setting_id`,`team_id`),
  KEY `fk_Settings_has_teams_Settings1` (`setting_id`),
  KEY `fk_Settings_has_teams_teams1` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Setting_has_team`
--

INSERT INTO `Setting_has_team` (`setting_id`, `team_id`) VALUES
(1, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Setting_has_unit`
--

DROP TABLE IF EXISTS `Setting_has_unit`;
CREATE TABLE IF NOT EXISTS `Setting_has_unit` (
  `setting_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  PRIMARY KEY (`setting_id`,`unit_id`),
  KEY `fk_Settings_has_Units_Settings1` (`setting_id`),
  KEY `fk_Settings_has_Units_Units1` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Setting_has_unit`
--

INSERT INTO `Setting_has_unit` (`setting_id`, `unit_id`) VALUES
(1, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Teams`
--

DROP TABLE IF EXISTS `Teams`;
CREATE TABLE IF NOT EXISTS `Teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(30) NOT NULL,
  `colour` char(15) DEFAULT NULL COMMENT 'Colour to paint team in RRR-GGG-BBB format',
  `capital` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `Teams`
--

INSERT INTO `Teams` (`id`, `name`, `colour`, `capital`) VALUES
(1, 'Team1', NULL, 1),
(2, 'Team2', NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `Team_has_country`
--

DROP TABLE IF EXISTS `Team_has_country`;
CREATE TABLE IF NOT EXISTS `Team_has_country` (
  `country_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  PRIMARY KEY (`country_id`,`team_id`),
  KEY `fk_Teams_has_Countries_Countries1` (`country_id`),
  KEY `fk_Team_has_country_Game_teams1` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Team_has_country`
--

INSERT INTO `Team_has_country` (`country_id`, `team_id`) VALUES
(1, 15),
(1, 17),
(1, 19),
(3, 16),
(3, 18),
(3, 20);

-- --------------------------------------------------------

--
-- Table structure for table `Team_orders`
--

DROP TABLE IF EXISTS `Team_orders`;
CREATE TABLE IF NOT EXISTS `Team_orders` (
  `id` int(11) NOT NULL,
  `order` text,
  `author_id` int(11) NOT NULL,
  `timedate` int(11) NOT NULL COMMENT 'timestamp when orders were posted',
  `team_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`author_id`,`team_id`),
  KEY `fk_orders_players1` (`author_id`),
  KEY `fk_Orders_Game_teams1` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Orders given by team commanders';

--
-- Dumping data for table `Team_orders`
--


-- --------------------------------------------------------

--
-- Table structure for table `Units`
--

DROP TABLE IF EXISTS `Units`;
CREATE TABLE IF NOT EXISTS `Units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_type_id` int(11) NOT NULL,
  `name` char(20) NOT NULL COMMENT 'Name of the unit',
  PRIMARY KEY (`id`,`unit_type_id`),
  KEY `fk_UnitTypes_Units1` (`unit_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='List of all units in game' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `Units`
--

INSERT INTO `Units` (`id`, `unit_type_id`, `name`) VALUES
(1, 1, 'troop1'),
(2, 1, 'troop2');

-- --------------------------------------------------------

--
-- Table structure for table `Units_requires_Countries`
--

DROP TABLE IF EXISTS `Units_requires_Countries`;
CREATE TABLE IF NOT EXISTS `Units_requires_Countries` (
  `Units_id` int(11) NOT NULL,
  `Countries_id` int(11) NOT NULL,
  PRIMARY KEY (`Units_id`,`Countries_id`),
  KEY `fk_Units_has_Countries_Units1` (`Units_id`),
  KEY `fk_Units_has_Countries_Countries1` (`Countries_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Units_requires_Countries`
--


-- --------------------------------------------------------

--
-- Table structure for table `UnitTypes`
--

DROP TABLE IF EXISTS `UnitTypes`;
CREATE TABLE IF NOT EXISTS `UnitTypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `UnitTypes`
--


-- --------------------------------------------------------

--
-- Table structure for table `Unit_has_stats`
--

DROP TABLE IF EXISTS `Unit_has_stats`;
CREATE TABLE IF NOT EXISTS `Unit_has_stats` (
  `unit_id` int(11) NOT NULL,
  `stat_id` int(11) NOT NULL,
  `stat_qty` int(11) NOT NULL,
  PRIMARY KEY (`unit_id`,`stat_id`),
  KEY `fk_Units_has_Unit_stats_Units1` (`unit_id`),
  KEY `fk_Units_has_Unit_stats_Unit_stats1` (`stat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='List of core stats each unit has';

--
-- Dumping data for table `Unit_has_stats`
--

INSERT INTO `Unit_has_stats` (`unit_id`, `stat_id`, `stat_qty`) VALUES
(1, 1, 10),
(1, 2, 20);

-- --------------------------------------------------------

--
-- Table structure for table `Unit_requires_research`
--

DROP TABLE IF EXISTS `Unit_requires_research`;
CREATE TABLE IF NOT EXISTS `Unit_requires_research` (
  `unit_id` int(11) NOT NULL,
  `research_id` int(11) NOT NULL,
  PRIMARY KEY (`unit_id`,`research_id`),
  KEY `fk_Units_Units_has_Advancements1` (`unit_id`),
  KEY `fk_Advancements_Units_has_Advancements1` (`research_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Unit_requires_research`
--

INSERT INTO `Unit_requires_research` (`unit_id`, `research_id`) VALUES
(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Unit_requires_resource`
--

DROP TABLE IF EXISTS `Unit_requires_resource`;
CREATE TABLE IF NOT EXISTS `Unit_requires_resource` (
  `unit_id` int(11) NOT NULL,
  `resources_id` int(11) NOT NULL,
  `resource_qty` int(11) NOT NULL,
  PRIMARY KEY (`unit_id`,`resources_id`),
  KEY `fk_Units_Units_has_Resources1` (`unit_id`),
  KEY `fk_Resources_Units_has_Resources1` (`resources_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='List of resources needed to produce unit.';

--
-- Dumping data for table `Unit_requires_resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `Unit_stats`
--

DROP TABLE IF EXISTS `Unit_stats`;
CREATE TABLE IF NOT EXISTS `Unit_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='List of all known unit stats' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `Unit_stats`
--

INSERT INTO `Unit_stats` (`id`, `name`) VALUES
(1, 'ATTACK'),
(2, 'DEFENCE'),
(3, 'EXPLOSIVE'),
(4, 'AVASION');

-- --------------------------------------------------------

--
-- Table structure for table `Unit_types`
--

DROP TABLE IF EXISTS `Unit_types`;
CREATE TABLE IF NOT EXISTS `Unit_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `Unit_types`
--

INSERT INTO `Unit_types` (`id`, `name`) VALUES
(1, 'LAND');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
CREATE TABLE IF NOT EXISTS `Users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `salt` varchar(45) NOT NULL,
  `handle` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`id`, `username`, `password`, `email`, `salt`, `handle`) VALUES
(1, 'cocacola999', '60efe94db0f2eb7d4d25cdbdce2bf6cb', 'email', '50394d87d80e35f3bc7e0d0d294a1927', 'Leeming'),
(2, 'blah', '9230c02259e1e9ef0777a5d5328d4c89', '', '64cf50edf60ea61376e47dda2bec04b7', 'gogggggg'),
(3, 'guest', 'feee8e1c60e3f4273a3b68566e8bb41c', '', 'e136d82d1aec9d303bcecfea6d940877', 'guest'),
(4, 'guest2', 'd783ab409877f76787ac6b5f83493911', '', 'b8c5ce4ae14d3fb7893cc3317b6dc2ed', 'guest2'),
(5, 'mod1', '15971d36e62171e36c2cc25f8be0e9c2', '', 'b210ee4f5603dee234d944b6ca3fc726', 'Mod');

-- --------------------------------------------------------

--
-- Table structure for table `User_has_medal`
--

DROP TABLE IF EXISTS `User_has_medal`;
CREATE TABLE IF NOT EXISTS `User_has_medal` (
  `users_id` int(11) NOT NULL,
  `medals_id` int(11) NOT NULL,
  PRIMARY KEY (`users_id`,`medals_id`),
  KEY `fk_users_has_medals_users1` (`users_id`),
  KEY `fk_users_has_medals_medals1` (`medals_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `User_has_medal`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `Activation_codes`
--
ALTER TABLE `Activation_codes`
  ADD CONSTRAINT `fk_activation_codes_users1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Battalion`
--
ALTER TABLE `Battalion`
  ADD CONSTRAINT `fk_battalion_Countries1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_battalion_players1` FOREIGN KEY (`player_id`) REFERENCES `Players` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Battalion_commanders`
--
ALTER TABLE `Battalion_commanders`
  ADD CONSTRAINT `fk_battalion_commanders_battalion1` FOREIGN KEY (`battalion_id`) REFERENCES `Battalion` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Country_has_border`
--
ALTER TABLE `Country_has_border`
  ADD CONSTRAINT `fk_Countries_Countries_has_Countries` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Countries_Countries_has_Countries1` FOREIGN KEY (`border_country`) REFERENCES `Countries` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Country_has_resource`
--
ALTER TABLE `Country_has_resource`
  ADD CONSTRAINT `fk_Countries_Countries_has_Resources1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Resources_Countries_has_Resources1` FOREIGN KEY (`resource_id`) REFERENCES `Resources` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Country_in_region`
--
ALTER TABLE `Country_in_region`
  ADD CONSTRAINT `fk_Countries_has_Regions_Countries1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Countries_has_Regions_Regions1` FOREIGN KEY (`region_id`) REFERENCES `Regions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Default_facilities`
--
ALTER TABLE `Default_facilities`
  ADD CONSTRAINT `fk_default_facilities_Games1` FOREIGN KEY (`game_id`) REFERENCES `Games` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_table1_Facilities1` FOREIGN KEY (`facility_id`) REFERENCES `Facilities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Default_researches`
--
ALTER TABLE `Default_researches`
  ADD CONSTRAINT `fk_default_researches_Games1` FOREIGN KEY (`game_id`) REFERENCES `Games` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_default_researches_Research1` FOREIGN KEY (`research_id`) REFERENCES `Research` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Default_resources`
--
ALTER TABLE `Default_resources`
  ADD CONSTRAINT `fk_default_resources_Games1` FOREIGN KEY (`game_id`) REFERENCES `Games` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_default_resources_Resources1` FOREIGN KEY (`resource_id`) REFERENCES `Resources` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Default_units`
--
ALTER TABLE `Default_units`
  ADD CONSTRAINT `fk_default_units_Games1` FOREIGN KEY (`game_id`) REFERENCES `Games` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_table1_Units1` FOREIGN KEY (`unit_id`) REFERENCES `Units` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Facility_builds_unit`
--
ALTER TABLE `Facility_builds_unit`
  ADD CONSTRAINT `fk_Facilities_Facilities_has_Units1` FOREIGN KEY (`facility_id`) REFERENCES `Facilities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Units_Facilities_has_Units1` FOREIGN KEY (`unit_id`) REFERENCES `Units` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Facility_produces_resource`
--
ALTER TABLE `Facility_produces_resource`
  ADD CONSTRAINT `fk_Facility_produces_resouce_Facilities1` FOREIGN KEY (`facility_id`) REFERENCES `Facilities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Facility_produces_resouce_Resources1` FOREIGN KEY (`resource_id`) REFERENCES `Resources` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Facility_requires_research`
--
ALTER TABLE `Facility_requires_research`
  ADD CONSTRAINT `fk_Advancements_Facilities_has_Advancements1` FOREIGN KEY (`research_id`) REFERENCES `Research` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Facilities_Facilities_has_Advancements1` FOREIGN KEY (`facility_id`) REFERENCES `Facilities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Facility_requires_resource`
--
ALTER TABLE `Facility_requires_resource`
  ADD CONSTRAINT `fk_Facilities_Facilities_has_Resources1` FOREIGN KEY (`facility_id`) REFERENCES `Facilities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Resources_Facilities_has_Resources1` FOREIGN KEY (`resource_id`) REFERENCES `Resources` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Games`
--
ALTER TABLE `Games`
  ADD CONSTRAINT `fk_Games_Settings1` FOREIGN KEY (`setting_id`) REFERENCES `Settings` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Game_invites`
--
ALTER TABLE `Game_invites`
  ADD CONSTRAINT `fk_game_invites_Games1` FOREIGN KEY (`game_id`) REFERENCES `Games` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_game_invites_users1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Game_teams`
--
ALTER TABLE `Game_teams`
  ADD CONSTRAINT `fk_Game_teams_Games1` FOREIGN KEY (`game_id`) REFERENCES `Games` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Game_teams_Teams1` FOREIGN KEY (`team_id`) REFERENCES `Teams` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Logins`
--
ALTER TABLE `Logins`
  ADD CONSTRAINT `fk_table1_users3` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Mail`
--
ALTER TABLE `Mail`
  ADD CONSTRAINT `fk_table1_users1` FOREIGN KEY (`owner_id`) REFERENCES `Users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_table1_users2` FOREIGN KEY (`sender_id`) REFERENCES `Users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `News`
--
ALTER TABLE `News`
  ADD CONSTRAINT `fk_Announcements_users1` FOREIGN KEY (`author_id`) REFERENCES `Users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `News_comments`
--
ALTER TABLE `News_comments`
  ADD CONSTRAINT `fk_table1_Announcements1` FOREIGN KEY (`news_id`) REFERENCES `News` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Announcement_comments_users1` FOREIGN KEY (`author_id`) REFERENCES `Users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Players`
--
ALTER TABLE `Players`
  ADD CONSTRAINT `fk_players_Games1` FOREIGN KEY (`game_id`) REFERENCES `Games` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Players_Game_teams1` FOREIGN KEY (`team_id`) REFERENCES `Game_teams` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_players_Play_styles1` FOREIGN KEY (`style_id`) REFERENCES `Play_styles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_players_users1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Player_has_facility`
--
ALTER TABLE `Player_has_facility`
  ADD CONSTRAINT `fk_Facilities_players_has_Facilities1` FOREIGN KEY (`facility_id`) REFERENCES `Facilities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_players_players_has_Facilities1` FOREIGN KEY (`player_id`) REFERENCES `Players` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_player_has_Facility_Countries1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Player_has_research`
--
ALTER TABLE `Player_has_research`
  ADD CONSTRAINT `fk_Advancements_players_has_Advancements1` FOREIGN KEY (`research_id`) REFERENCES `Research` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_players_players_has_Advancements1` FOREIGN KEY (`player_id`) REFERENCES `Players` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Player_has_resource`
--
ALTER TABLE `Player_has_resource`
  ADD CONSTRAINT `fk_player_has_Resource_players1` FOREIGN KEY (`player_id`) REFERENCES `Players` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Resources_players_has_Resources1` FOREIGN KEY (`resource_id`) REFERENCES `Resources` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Player_has_unit`
--
ALTER TABLE `Player_has_unit`
  ADD CONSTRAINT `fk_battallion_player_has_unit1` FOREIGN KEY (`battalion_id`) REFERENCES `Battalion` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Units_players_has_Units1` FOREIGN KEY (`unit_id`) REFERENCES `Units` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Player_research_queue`
--
ALTER TABLE `Player_research_queue`
  ADD CONSTRAINT `fk_player_research_queue_players1` FOREIGN KEY (`player_id`) REFERENCES `Players` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_player_research_queue_Research1` FOREIGN KEY (`research_id`) REFERENCES `Research` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Private_games`
--
ALTER TABLE `Private_games`
  ADD CONSTRAINT `fk_private_games_Games1` FOREIGN KEY (`game_id`) REFERENCES `Games` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_private_games_users1` FOREIGN KEY (`owner_id`) REFERENCES `Users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Profiles`
--
ALTER TABLE `Profiles`
  ADD CONSTRAINT `fk_profiles_users1` FOREIGN KEY (`user_id`) REFERENCES `Users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Region_has_resource`
--
ALTER TABLE `Region_has_resource`
  ADD CONSTRAINT `fk_Regions_Regions_has_Resources1` FOREIGN KEY (`region_id`) REFERENCES `Regions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Resources_Regions_has_Resources1` FOREIGN KEY (`resource_id`) REFERENCES `Resources` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Research_requires_research`
--
ALTER TABLE `Research_requires_research`
  ADD CONSTRAINT `fk_Advancements_Advancements_has_Advancements` FOREIGN KEY (`research_id`) REFERENCES `Research` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Advancements_Advancements_has_Advancements1` FOREIGN KEY (`required_research`) REFERENCES `Research` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Research_requires_resource`
--
ALTER TABLE `Research_requires_resource`
  ADD CONSTRAINT `fk_Advancements_Advancements_has_Resources1` FOREIGN KEY (`research_id`) REFERENCES `Research` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Resources_Advancements_has_Resources1` FOREIGN KEY (`resource_id`) REFERENCES `Resources` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Setting_has_country`
--
ALTER TABLE `Setting_has_country`
  ADD CONSTRAINT `fk_Game_has_Country_Countries1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Game_has_Country_Settings1` FOREIGN KEY (`setting_id`) REFERENCES `Settings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Setting_has_facility`
--
ALTER TABLE `Setting_has_facility`
  ADD CONSTRAINT `fk_Settings_has_Facilities_Facilities1` FOREIGN KEY (`facility_id`) REFERENCES `Facilities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Settings_has_Facilities_Settings1` FOREIGN KEY (`setting_id`) REFERENCES `Settings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Setting_has_region`
--
ALTER TABLE `Setting_has_region`
  ADD CONSTRAINT `fk_Games_has_Regions_Regions1` FOREIGN KEY (`region_id`) REFERENCES `Regions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Game_has_region_Settings1` FOREIGN KEY (`setting_id`) REFERENCES `Settings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Setting_has_research`
--
ALTER TABLE `Setting_has_research`
  ADD CONSTRAINT `fk_Settings_has_Research_Research1` FOREIGN KEY (`research_id`) REFERENCES `Research` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Settings_has_Research_Settings1` FOREIGN KEY (`setting_id`) REFERENCES `Settings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Setting_has_resource`
--
ALTER TABLE `Setting_has_resource`
  ADD CONSTRAINT `fk_Settings_has_Resources_Resources1` FOREIGN KEY (`resource_id`) REFERENCES `Resources` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Settings_has_Resources_Settings1` FOREIGN KEY (`setting_id`) REFERENCES `Settings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Setting_has_team`
--
ALTER TABLE `Setting_has_team`
  ADD CONSTRAINT `fk_Settings_has_teams_Settings1` FOREIGN KEY (`setting_id`) REFERENCES `Settings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Settings_has_teams_teams1` FOREIGN KEY (`team_id`) REFERENCES `Teams` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Setting_has_unit`
--
ALTER TABLE `Setting_has_unit`
  ADD CONSTRAINT `fk_Settings_has_Units_Settings1` FOREIGN KEY (`setting_id`) REFERENCES `Settings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Settings_has_Units_Units1` FOREIGN KEY (`unit_id`) REFERENCES `Units` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Team_has_country`
--
ALTER TABLE `Team_has_country`
  ADD CONSTRAINT `fk_Teams_has_Countries_Countries1` FOREIGN KEY (`country_id`) REFERENCES `Countries` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Team_has_country_Game_teams1` FOREIGN KEY (`team_id`) REFERENCES `Game_teams` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Team_orders`
--
ALTER TABLE `Team_orders`
  ADD CONSTRAINT `fk_Orders_Game_teams1` FOREIGN KEY (`team_id`) REFERENCES `Game_teams` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_orders_players1` FOREIGN KEY (`author_id`) REFERENCES `Players` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Units`
--
ALTER TABLE `Units`
  ADD CONSTRAINT `fk_UnitTypes_Units1` FOREIGN KEY (`unit_type_id`) REFERENCES `Unit_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Units_requires_Countries`
--
ALTER TABLE `Units_requires_Countries`
  ADD CONSTRAINT `fk_Units_has_Countries_Countries1` FOREIGN KEY (`Countries_id`) REFERENCES `Countries` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Units_has_Countries_Units1` FOREIGN KEY (`Units_id`) REFERENCES `Units` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Unit_has_stats`
--
ALTER TABLE `Unit_has_stats`
  ADD CONSTRAINT `fk_Units_has_Unit_stats_Units1` FOREIGN KEY (`unit_id`) REFERENCES `Units` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Units_has_Unit_stats_Unit_stats1` FOREIGN KEY (`stat_id`) REFERENCES `Unit_stats` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Unit_requires_research`
--
ALTER TABLE `Unit_requires_research`
  ADD CONSTRAINT `fk_Advancements_Units_has_Advancements1` FOREIGN KEY (`research_id`) REFERENCES `Research` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Units_Units_has_Advancements1` FOREIGN KEY (`unit_id`) REFERENCES `Units` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Unit_requires_resource`
--
ALTER TABLE `Unit_requires_resource`
  ADD CONSTRAINT `fk_Resources_Units_has_Resources1` FOREIGN KEY (`resources_id`) REFERENCES `Resources` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Units_Units_has_Resources1` FOREIGN KEY (`unit_id`) REFERENCES `Units` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `User_has_medal`
--
ALTER TABLE `User_has_medal`
  ADD CONSTRAINT `fk_users_has_medals_medals1` FOREIGN KEY (`medals_id`) REFERENCES `Medals` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_has_medals_users1` FOREIGN KEY (`users_id`) REFERENCES `Users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
SET FOREIGN_KEY_CHECKS=1;

