<?php
/**
 * List of classes used by this class
 */
require_once("Base.class.php");
require_once("Validate.class.php");
require_once("Resource.class.php");
require_once("Research.class.php");
require_once("Unit.class.php");


/**
 *
 * @author leeming
 */
class Battalion extends Base
{
	public $id, $name, $location, $commander, $exp;

	/**
	 * Constructor for the Battalion Class
	 * Loads all data from database
	 *
	 * @param int $id Id of the battalion
	 */
	function __construct($id)
	{
		parent::__construct();

		//Validate $id is int
		if(!Validate::isInt($id))
		{
			trigger_error("(int)\$id expected, (".gettype($id).") passed", E_USER_ERROR);
			return;
		}
		
		$this->db->query("SELECT b.player_id, b.name, b.country_id, c.name AS commander, c.exp "
			."FROM Battalion b INNER JOIN Battalion_commanders c ON(b.id=c.battalion_id)"
			." WHERE b.id = {$id} LIMIT 1");

		$result = $this->db->getRow();

		$this->id = $id;
		$this->name = $result['name'];
		$this->location = $result['country_id'];
		$this->commander = $result['commander'];
		$this->exp = $result['exp'];
		$this->player = $result['player_id'];
		
	}


	private $units = NULL;
	
	/**
	 * Get a list of units within a battalion
	 *
	 * @todo How to manage results where qty == 0 ?? dont fetch/delete from db?
	 * @param bool $recache
	 * @return Unit[]
	 */
	function getUnits($recache = false)
	{
		if($recache || $this->units == NULL)
		{
			$this->units = array();
			
			$sql = "SELECT unit_id, unit_qty FROM Player_has_unit"
				." WHERE battalion_id = '{$this->id}' ";
			$result = $this->db->fetch_all_array($sql);
			
			foreach($result AS $r)
			{
				$this->units[] = new Unit($r['unit_id'], $r['unit_qty']);
			}
		}
		
		return $this->units;
	}

	/**
	 * Find out battalion lvl, generated dynamically from exp
	 *
	 * @return int Level
	 */
	function getLevel()
	{
		return 1;
	}
	
	/**
	 * Calculate exp needed for next level
	 *
	 * @return int
	 */
	function nextLevelExp()
	{
		return 100;
	}

	/**
	 * Calculate the attack strength of battalion
	 * using player researches/battalion level/units
	 *
	 * @return int
	 */
	function totalStr()
	{
		$str = 0;
		
		$this->getUnits(true);
		foreach($this->units AS $unit)
		{
			$stats = $unit->getStats();
			$str += $unit->qty*$stats['ATTACK'];
		}
		
		return $str;
	}

	function attack(Country $attack)
	{
		
	}
	
	function move(Country $move)
	{
		$player= new Player($this->player);
		
		$resources = $player->getResources(true);
		if($resources[RESOURCE_TURNS] < 1)
		{
			$this->firephp->log("Move failed: no turns");
			return false;
		}
		
		//is battalion location border and moveable
		$moveable = $this->loc->getMoveBorders($this->player->team);
		if(!in_array($move->id, $moveable))
		{
			$this->firephp->log("Move failed: non moveable border");
			return false;
		}
		
		//ok to move
		$sq
	}

	/**
	 * Check to see if battalion is empty or has troops
	 * If no troops returns false, else true
	 *
	 * @return bool
	 */
	function isEmpty()
	{
		$units =$this->getUnits(true);
		
		//Simple if empty then no units
		if(empty($units))
			return true;
		
		//some units could be stored but 0 qty
		foreach($units AS $unit)
		{
			//if any unit qty > 0 then battalion not empty
			if($unit->qty > 0)
				return false;
		}
		
		//if here all units checked and all have 0 qty
		return true;
	}

	/**
	 * Makes a new battalion, returns: -1 on error, 0 on failed mysql,
	 * else id of new battalion
	 *
	 * @param array $insertArray Assoc array with fields to add
	 * @return int Facility ID
	 */
	static function add(array &$insertArray)
	{
		//check required fields
		if(array_key_exists('name', $insertArray) && !empty($insertArray['name'])
		   && array_key_exists('player_id', $insertArray)
		   && Vallidate::isInt($insertArray['player_id'])
		   && array_key_exists('country_id', $insertArray)
		   && Vallidate::isInt($insertArray['country_id']))
		
		{
			global $db;

			$bat = array('name' 	 => $insertArray['name'],
						 'player_id' => $insertArray['player_id'],
						 'country_id'=> $insertArray['country_id']);
			$battId = $db->query_insert("Battalion",$bat);
			
			$com = array('battalion_id' => $battId,
						 'name' => $insertArray['commander'],
						 'exp' => '0');
			
			
			return $db->query_insert("Battalion_commander", $com);
		}

		return -1;
	}


	function equals(Battalion &$cmp)
	{
		return ($this->id == $cmp->id);
	}

	function __toString()
	{
		return "(Battalion){$this->name}";
	}

}
?>
