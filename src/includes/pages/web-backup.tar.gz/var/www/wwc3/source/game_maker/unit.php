<?php
require("../tiggerConfig.php");
require_once("../classes/Database.class.php");
require_once("../classes/Unit.class.php");
require_once("../classes/Validate.class.php");
require_once("../classes/UnitType.class.php");

require_once("functions.php");

$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

if(!empty($_POST))
{
	print"<b>POSTED</b><br>";
	print"<pre>"; print_r($_POST); print"</pre>";

	
	//post is add req
	if($_POST['addReq'])
	{
		$unit = new Unit($_POST['id']);
		$unit->addPreReq($_POST['addReq']);

	}
	//post is add stat
	elseif($_POST['addStat'])
	{
		$stat = new Stat($_POST['addStat'], $_POST['qty']);
		
		$unit = new Unit($_POST['id']);
		$unit->addStat($stat);
		
	}
	else
	{
		//new or update?
		if($_POST['id'] == "") //new
		{
			$insert = array('name' => $_POST['name'],
							'unit_type_id' => $_POST['type']);
	
			$id = Unit::add($insert);
	
			if($id == -1)
				print"<br><br>Failed";
	
			$_GET['unit'] = $id;
		}
		else //update
		{}
	}

}

if(Validate::isInt($_GET['unit']))
{
	$unit = new Unit($_GET['unit']);
	
	$id = $unit->id;
	$name = $unit->name;
	$type = $unit->type;
}
else
{
	$id = "";
	$name = "";
}


?>
<a href="index.php">Back</a>

<p style="color:red;">
	<b>Notice:</b> This is a basic data entry form, it does <b>not</b> do anything fancy.
	Please check entries for validation rules before adding, the code only does this at
	minimal level!
</p>

<form method="post">
<table>
	<tr>
		<th>Unit Details</th>
	</tr>
	<tr>
		<td>
			
			<table>
				<tr>
					<td>ID: [leave blank]</td>
					<td><input type="text" name="id" value="<?=$id?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Name: [char:15]</td>
					<td><input type="text" name="name" value="<?=$name?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Unit Type</td>
					<td>
						<select name="type">
							<?php
							foreach(getUnitTypes() AS $unitType)
							{
								?>
								<option value="<?=$unitType->id?>" selected="<?=($unitType->id==$type)?"selected":""?>">
									<?=$unitType->name?>
								</option>
								<?php
							}
							?>
						</select>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<input type="submit" value="Add/Update" />
		</td>
	</tr>
</table>
</form>


<?php
//show only if current unit
if(Validate::isInt($id))
{
	?>
	<!--Dependancies-->
	<form method="post">
	<table>
		<tr>
			<th>Research Needed</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $unit->getPreReq('object');
					foreach($list AS $preReq)
					{
						?>
						<tr>
							<td><?=$preReq->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addReq">
								<?php
								foreach(getResearches() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	<!--Stats-->
	<form method="post">
	<table>
		<tr>
			<th>Unit Stats</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $unit->getStats(true);
					foreach($list AS $stat)
					{
						?>
						<tr>
							<td><?=$stat->qty?></td>
							<td><?=$stat->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="3"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="text" name="qty" />
						</td>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addStat">
								<?php
								foreach(getStats() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	<?php
}
?>