<?php
/**
 * List of classes used by this class
 */
require_once("Base.class.php");
require_once("Validate.class.php");
require_once("Game.class.php");
require_once("User.class.php");
require_once("TeamInstance.class.php");
require_once("Battalion.class.php");
require_once("Resource.class.php");
require_once("Research.class.php");
require_once("Facility.class.php");



/**
 * Class containing all information about players
 * within a game
 *
 * @todo Ongoing game interaction methods need to be added
 * @todo Max battalion needs doing, depends on game settings
 * 		and also if player is premium player
 */
class Player extends Base
{
	private $selectedBattalion;
	
	function __construct($id)
	{
		parent::__construct();
		
		if(!Validate::isInt($id))
		{
			trigger_error("(int)\$id expected, (".gettype($id).") passed", E_USER_ERROR);
			return;			
		}
		
		$this->db->query("SELECT game_id, user_id, team_id FROM Players WHERE id='{$id}' LIMIT 1");
		$result = $this->db->getRow();
		
		$this->id = $id;
		$this->game = new Game($result['game_id']);
		$this->user = new User($result['user_id']);
		$this->team = new TeamInstance($result['team_id']);
		
		//select primary battalion
		$this->getBattalions();//sets internal value
		$this->selectedBattalion = $this->battalions[0];
	}
	
	private $resources = NULL;
	
	/**
	 * Get a list of resources the player owned
	 *
	 * @param bool $recache
	 * @return Resource[]
	 */
	function getResources($recache = false)
	{
		if($recache || $this->resources == NULL)
		{
			$this->resources = array();
			
			$sql = "SELECT resource_id, resource_qty FROM Player_has_resource"
				." WHERE player_id = '{$this->id}' ";
			$result = $this->db->fetch_all_array($sql);
			
			foreach($result AS $r)
			{
				$this->resources[$r['resource_id']] = new Resource($r['resource_id'], $r['resource_qty']);
			}
		}
		
		return $this->resources;
	}
	
	private $facilities = NULL;
	
	/**
	 * Get a list of facilities the player owned
	 *
	 * @param bool $recache
	 * @return Facility[]
	 */
	function getFacilities($recache = false)
	{
		if($recache || $this->facilities == NULL)
		{
			$this->facilities = array();
			
			$sql = "SELECT facility_id, facility_qty FROM Player_has_facility"
				." WHERE player_id = '{$this->id}' ";
			$result = $this->db->fetch_all_array($sql);
			
			foreach($result AS $r)
			{
				$this->facilities[] = new Facility($r['facility_id'], $r['facility_qty']);
			}
		}
		
		return $this->facilities;
	}
	
	private $battalions = NULL;
	
	/**
	 * Get a list of battalions the player owned
	 *
	 * @param bool $recache
	 * @return Facility[]
	 */
	function getBattalions($recache = false)
	{
		if($recache || $this->battalions == NULL)
		{
			$this->battalions = array();
			
			$sql = "SELECT id FROM Battalion WHERE player_id = '{$this->id}' ";
			$result = $this->db->fetch_all_array($sql);
			
			foreach($result AS $r)
			{
				$this->battalions[] = new Battalion($r['id']);
			}
		}
		
		return $this->battalions;
	}
	
	
	/**
	 * Fetch the battalion which is currently active,
	 * player can only directly control 1 battalion
	 * one at a time.
	 *
	 * @return Battalion
	 */
	function getSelectedBattalion()
	{
		return $this->selectedBattalion;
	}
	
	function maxBattalions()
	{
		return 3;
	}
	
	function getNumBattalions()
	{
		return count($this->getBattalions());
	}
	
	
	private $researches = NULL;
	private $researchIds = NULL;
	
	/**
	 * Get a list of researches the player has
	 *
	 * @param bool $recache
	 * @return Research[]
	 */
	function getResearches($returnType="int", $recache = false)
	{
		if($returnType == "int")
		{
			if($recache || $this->researchIds == NULL)
			{
				$this->researchIds = array();
				
				$sql = "SELECT research_id FROM Player_has_research"
					." WHERE player_id = '{$this->id}' ";
				$result = $this->db->fetch_all_array($sql);
				
				foreach($result AS $r)
				{
					$this->researchIds[] = $r['research_id'];
				}
			}
			
			return $this->researchIds;
		}
		else
		{
			
			if($recache || $this->researches == NULL)
			{
				$this->researches = array();
				
				$sql = "SELECT research_id FROM Player_has_research"
					." WHERE player_id = '{$this->id}' ";
				$result = $this->db->fetch_all_array($sql);
				
				foreach($result AS $r)
				{
					$this->researches[] = new Research($r['research_id']);
				}
			}
			
			return $this->researches;	
		}
	}
	
	/**
	 * Allow player to build facilities
	 *
	 * @param Facility $fac Facility to build
	 * @param int $location Country id of where to build it
	 * @param int $qty How many
	 * @return bool
	 */
	function build(Facility $fac, $location, $qty)
	{
		//check location and qty are valid
		if(!Validate::isInt($location) || !Validate::isInt($qty))
		{
			$this->firephp->log('Invalid location/qty, not int');
			return "Invalid input, make sure you selected a country and set a qty";
		}
		
		//check if player can afford
		$faccost = $fac->getCost();
		$this->getResources(true);
		foreach($faccost AS $c)
		{
			$this->firephp->log("Have ".$this->resources[$c->id]->qty.
				" but needed ".$c->qty*$qty);
			
			//player doesnt have enough resources
			if($this->resources[$c->id]->qty < $c->qty*$qty)
			{
				return "You need more resources to build this";
			}
		}
		
		//check if player owns location
		if(!in_array($location, $this->team->countriesOwn()))
		{
			$this->firephp->log("Team does not own this country");
			return false;
		}
		
		//check if research is done for building
		foreach($fac->getPreReq('int') AS $chk)
		{
			if(!in_array($chk, $has))
				return "You do not have the research to build this";
		}
		
		
		###Ok to build
		$sql = "INSERT INTO Player_has_facility (`facility_id`,`player_id`,".
			" `country_id`, `facility_qty`) VALUES('{$fac->id}','{$this->id}',".
			" '{$location}','{$qty}') ON DUPLICATE KEY UPDATE ".
			"facility_qty=`facility_qty`+{$qty}";
		$this->firephp->log($sql,"Adding new facilities::SQL");
		$this->db->query($sql);
		
		
		//Take away each resource from user (cost of qty * facility)
		foreach($faccost AS $c)
		{
			//$c is type Resource
			$sql = "UPDATE Player_has_resource SET resource_qty=`resource_qty`-".
				($qty*$c->qty)." WHERE player_id='{$this->id}' AND ".
				"resource_id='{$c->id}' LIMIT 1";
			$this->firephp->log($sql,"Updating resource::SQL");
			$this->db->query($sql);	
				
			//update resources in player object (this one)
			$this->resources[$c->id]->qty - $c->qty*$qty;
		}
		
		return true;
	}
	
	/**
	 * Short hand sort method to Get id of player passed
	 *
	 * @param int/Player $find Player to find id for
	 * @return int Id of player or -1 for invalid
	 */
	static function id($find)
	{
		if(Validate::isInt($find))
			return $find;
		else if(get_class($find) == "Player")
			return $find->id;
		else
			return -1;
	}
	
	
}
?>