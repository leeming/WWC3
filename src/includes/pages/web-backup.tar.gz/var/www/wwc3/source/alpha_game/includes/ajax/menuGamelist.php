<?php
require_once("../classes/Game.class.php");

//get list of user's games
$gamelist = $user->getGames();


foreach($gamelist AS $game => $playerId)
{
	$gameObj = new Game($game);
	?>
	<a class="" onclick="pickgame(<?=$game?>)"><?=$gameObj->name?></a>
	<?php
}
if(count($gamelist) == 0)
{
	?>
	<a onclick="loadWindow('games','list=notmy')">You are in no games</a>
	<?php
}
?>