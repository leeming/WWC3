<?php
print "Username: ".$user->username."<br>";
print "Handle: ".$user->handle."<br>";
?>