<?php
require("../tiggerConfig.php");
require_once("../classes/Database.class.php");
require_once("../classes/Settings.class.php");
require_once("../classes/Validate.class.php");
require_once("includeAll.php");
require_once("functions.php");

$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

if(!empty($_POST))
{
	print"<b>POSTED</b><br>";
	print"<pre>"; print_r($_POST); print"</pre>";

	if($_POST['addResearch'])
	{
		$game = new Game($_POST['id']);
		$game->addDefault(new Research($_POST['addResearch']));
	}
	else if($_POST['addResource'])
	{
		$game = new Game($_POST['id']);
		$game->addDefault(new Resource($_POST['addResource'],$_POST['qty']));
	}
	else if($_POST['addFacility'])
	{
		$game = new Game($_POST['id']);
		$game->addDefault(new Facility($_POST['addFacility'],$_POST['qty']));
	}
	else if($_POST['addUnit'])
	{
		$game = new Game($_POST['id']);
		$game->addDefault(new Unit($_POST['addUnit'],$_POST['qty']));
	}
	else
	{
		
		//new or update?
		if($_POST['id'] == "") //new
		{
			$insert = array('name' => $_POST['name'],
					'desc' => $_POST['desc'],
					'setting_id'=>$_POST['setting'],
					'start_timestamp'=>$_POST['start']);
	
			$id = Game::add($insert);
	
			if($id == -1)
				print"<br><br>Failed";
			else
				print"<br><br>".$id;
		}
		else //update
		{}
	}
}

if(Validate::isInt($_REQUEST['id']))
{
	$game = new Game($_GET['id']);
	
	$id = $game->id;
	$name = $game->name;
	$desc = $game->desc;
	$settings = $game->settings;
	$timestamp = $game->startTimestamp;
	
}
else
{
	$id = "";
	$name = "";
	$desc = "";
	$settings = NULL;
	$timestamp = time();
}


?>
<a href="index.php">Back</a>

<p style="color:red;">
	<b>Notice:</b> This is a basic data entry form, it does <b>not</b> do anything fancy.
	Please check entries for validation rules before adding, the code only does this at
	minimal level!
</p>

<form method="post">
<table>
	<tr>
		<th>Game</th>
	</tr>
	<tr>
		<td>
			
			<table>
				<tr>
					<td>ID: [leave blank]</td>
					<td><input type="text" name="id" value="<?=$id?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Name: [char:15]</td>
					<td><input type="text" name="name" value="<?=$name?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Description: [char:50]</td>
					<td><input type="text" name="desc" value="<?=$desc?>" maxlength="50" /></td>
				</tr>
				<tr>
					<td>Setting:</td>
					<td>
						<select name="setting">
							<?php
							foreach(getSettings() AS $setting)
							{
								?>
								<option value="<?=$setting->id?>" selected="<?=($settings!=NULL&&$setting->equals($settings)?"selected":"")?>">
									<?=$setting->name?>
								</option>
								<?php
							}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>Start Timestamp: [char:15]</td>
					<td><input type="text" name="start" value="<?=$timestamp?>" maxlength="15" /></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<input type="submit" value="Add/Update" />
		</td>
	</tr>
</table>
</form>


<?php
//show only if current unit
if(Validate::isInt($id))
{
	
	?>
	<!--Researches-->
	<form method="post">
	<table>
		<tr>
			<th>Starting Research</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $game->getDefaults('research');
					foreach($list AS $re)
					{
						?>
						<tr>
							<td><?=$re->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addResearch">
								<?php
								foreach(getResearches() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
		<!--Resources-->
	<form method="post">
	<table>
		<tr>
			<th>Starting Resources</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $game->getDefaults('resource');
					foreach($list AS $re)
					{
						?>
						<tr>
							<td><?=$re->qty?> <?=$re->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							
							<input type="text" name="qty" maxlength="10" />
							<select name="addResource">
								<?php
								foreach(getResources() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
		<!--Facility-->
	<form method="post">
	<table>
		<tr>
			<th>Starting Facilities</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $game->getDefaults('facility');
					foreach($list AS $re)
					{
						?>
						<tr>
							<td><?=$re->qty?> <?=$re->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<input type="text" name="qty" maxlength="10" />
							<select name="addFacility">
								<?php
								foreach(getFacilities() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	
		<!--Units-->
	<form method="post">
	<table>
		<tr>
			<th>Starting Units</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $game->getDefaults('unit');
					foreach($list AS $re)
					{
						?>
						<tr>
							<td><?=$re->qty?> <?=$re->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<input type="text" name="qty" maxlength="10" />
							<select name="addUnit">
								<?php
								foreach(getUnits() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	<?php
}
?>