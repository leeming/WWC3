<?php
/**
 * List of classes used by this class
 */
require_once("Validate.class.php");
require_once("Base.class.php");

/**
 * Class which determines all battles between player and milita
 */
class Attack extends Base
{
	/**
	 * Constructor for Attack class
	 *
	 * @param Battalion $bat Battalion to attack with
	 * @param Country $loc Country to attack
	 */
	function __construct(Player $player, Battalion $bat, County $loc)
	{
		$this->bat = &$bat;
		$this->loc = &$loc;
		$this->player = &$player;
	}
	
	/**
	 * Finds out if battalion is able to attack location.
	 * Reasons not been able to attack may include
	 *  - Not at border
	 *  - 0 units in battalion
	 *  - no turns to attack with
	 *
	 * @return bool
	 */
	function canAttack()
	{
		//check to see if player has any turns
		$resources = $this->player->getResources(true);
		if($resources[RESOURCE_TURNS] < 1)
		{
			$this->firephp->log("Attack failed: no turns");
			return false;
		}
		
		//check to see if battalion has any units
		if($this->bat->isEmpty())
		{
			$this->firephp->log("Attack failed: no units");
			return false;
		}
		
		//is battalion location border and attackable
		$attackable = $this->loc->getAttackBorders($this->player->team);
		if(!in_array($this->loc, $attackable))
		{
			$this->firephp->log("Attack failed: non attackable border");
			return false;
		}
		
		//if here then can attack
		return true;
	}
	
	/**
	 * Find out if there are any battalions currently
	 * in this country. If so then an array of battalions
	 * is returned, else empty array
	 *
	 * @return Battalion[]
	 */
	function getEnemies()
	{
		return $this->loc->armiesPresent($this->player->game);
	}
	
	/**
	 * Lazy method to count the getEnemies array to
	 * check if any enemies are in the country or if
	 * it is just the milita
	 *
	 * @return bool
	 */
	function hasEnemies()
	{
		return !isEmpty($this->getEnemies());
	}
	
	
	/**
	 * Gets the strength of the Battalion or Country
	 * passed. If a battalion is passed then unit str
	 * are all summed together and used with the battalion
	 * level modifier. Else if a country is passed then
	 * the milita str is calculated from the milita size
	 * and resistance
	 *
	 * @param Battalion/Country $strOf
	 * @return int
	 */
	private function getStr($strOf)
	{
		if(get_class($strOf) == "Battalion")
			return $strOf->totalStr();
		else if(get_class($strOf) == "Country")
			return $strOf->getMilita();
		//else not Battalion/Country
		else
		{
			trigger_error("Battalion/Country expected but ".get_class($strOf)." passed", E_USER_ERROR);
			exit();
		}
	}
	
	/**
	 * Set only inside doAttack method
	 * Some methods only give valid output
	 * if the battle has taken place (such as unitsLost())
	 *
	 * @var bool $attDone
	 */
	private $attDone;
	
	/**
	 * The main method which does all the battle calculations
	 * All post battle vars are set inside here
	 *
	 * If there is currently enemies in this country then
	 * the Battalion object must be passed, if no battalion
	 * is passed then (null) attacking milita is assumed.
	 *
	 * @param Battalion $attBat Battalion to attack
	 * @return bool If you win
	 */
	function doAttack(Battalion $attBat)
	{}
	
	####################################
	####################################
	###  All methods below can only  ###
	###  be called AFTER doAttack()  ###
	####################################
	####################################
	
	/**
	 * Gets the default winning/lost message after
	 * a battle. This includes the number of resources
	 * used in the attack and the number of units lost
	 * WARNING: This can not be called before a battle!
	 *
	 *
	 * @todo Unsure if enemy unit count should be shown to user?
	 *
	 * @return String
	 */
	function battleMsg()
	{
		/**
		 * Should not be able to call this method
		 * before doAttack()
		 */
		if(!$this->attDone)
		{
			$this->firephp->log("Attack->battleMsg() failed: Attack not done!");
			trigger_error("Battle methods called in wrong order",E_USER_ERROR);
			return;
		}
	}
	
	/**
	 * Gets an array of the user's resources used in the battle
	 * WARNING: This can not be called before a battle!
	 *
	 * @return Resource[]
	 */
	function resorcesUsed()
	{
		/**
		 * Should not be able to call this method
		 * before doAttack()
		 */
		if(!$this->attDone)
		{
			$this->firephp->log("Attack->battleMsg() failed: Attack not done!");
			trigger_error("Battle methods called in wrong order",E_USER_ERROR);
			return;
		}
	}
	
	/**
	 * Get an array of units lost in battle
	 * WARNING: This can not be called before a battle!
	 *
	 * @return Unit[]
	 */
	function unitsLost()
	{
		/**
		 * Should not be able to call this method
		 * before doAttack()
		 */
		if(!$this->attDone)
		{
			$this->firephp->log("Attack->battleMsg() failed: Attack not done!");
			trigger_error("Battle methods called in wrong order",E_USER_ERROR);
			return;
		}
	}
}

?>