<?php
session_start();

//Check to see session data is set, if not divert to index
if(!key_exists('user', $_SESSION))
{
	header("Location: index.php");
}

//get config file & connection
require_once("../tiggerConfig.php");
require_once("../classes/Database.class.php");
require_once("../classes/Validate.class.php");
require_once("../classes/User.class.php");


$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

$user = unserialize($_SESSION['user']);

############################
### Lobby pages go below ###
############################

//List all pages allowed to view in the format 'pageName' => 'fileLocation'
$allowedPages = array('news' => "news.php",
					  'error' => "error.php",
					  'games' => "listGames.php",
					  'debug' => "debug.php");

//if no page is given, show this default
if(!isset($_GET['page']) || $_GET['page'] == "")
{
	//Default page
	$page = "news";
}
else
{
	$page = $_GET['page'];
}

//check page is allowed
if(!key_exists($page, $allowedPages))
{
	$page="error";
	$args['code'] = "PAGE_NOT_ALLOWED";
}

$absoluteDirPath = SITE_ROOT."/alpha_game/includes/";

//check to see if page exists (on the filestore)
if(!file_exists($absoluteDirPath.$allowedPages[$page]))
{
	$page="error";
	$args['code'] = "PAGE_NOT_ADDED";
}

//save all request data
foreach($_REQUEST AS $index => $value)
{
	$args[$index] = $value;
}

//load page here
require($absoluteDirPath.$allowedPages[$page]);


##########################
### End of lobby pages ###
##########################

$_SESSION['user'] = serialize($user);
$db->close();
?>