<?php
//view single building
if(Validate::isInt($args['view']))
{
	print"view building...";
	require("buildings-view.php");
}
//else show all buildings
else
{
	require("buildings-all.php");
}
?>