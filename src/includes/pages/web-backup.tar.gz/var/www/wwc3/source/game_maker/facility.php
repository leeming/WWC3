<?php
require("../tiggerConfig.php");
require_once("../classes/Database.class.php");
require_once("../classes/Facility.class.php");
require_once("../classes/Research.class.php");
require_once("../classes/Validate.class.php");
require_once("../classes/Resource.class.php");
require_once("../classes/Unit.class.php");
require_once("functions.php");


$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

if(!empty($_POST))
{
	print"<b>POSTED</b><br>";
	print"<pre>"; print_r($_POST); print"</pre>";

	//post is add req
	if($_POST['addReq'])
	{
		$facility = new Facility($_POST['id']);
		$facility->addPreReq($_POST['addReq']);

	}
	//post is add cost
	else if($_POST['addCost'])
	{
		$r = new Resource($_POST['addCost'], $_POST['qty']);

		$facility = new Facility($_POST['id']);
		$facility->addCost($r);
	}
	//post is add resource output
	else if($_POST['addOutResource'])
	{
		$resource = new Resource($_POST['addOutResource'], $_POST['qty']);
		
		$facility = new Facility($_POST['id']);
		$facility->addProduction($resource);
	}
	//post is add unit output
	else if($_POST['addOutUnit'])
	{
		$r = new Unit($_POST['addOutUnit'], $_POST['qty']);
		
		$facility = new Facility($_POST['id']);

		$facility->addProduction($r);		
	}
	//post is body info
	else
	{
		//new or update?
		if($_POST['id'] == "") //new
		{
			$insert = array('name' => $_POST['name'],
							'desc' => $_POST['desc']);

			$id = Facility::add($insert);

			if($id == -1)
				print"<br><br>Failed";

			$_GET['facility'] = $id;
		}
		else //update
		{}
	}

}

if(Validate::isInt($_GET['facility']) || Validate::isInt($_POST['id']))
{
	if($_GET['facility'] > 0)
		$facility = new Facility($_GET['facility']);
	
	$id = $facility->id;
	$name = $facility->name;
	$desc = $facility->desc;
}
else
{
	$id = "";
	$name = "";
	$desc = "";
}


?>
<a href="index.php">Back</a>

<p style="color:red;">
	<b>Notice:</b> This is a basic data entry form, it does <b>not</b> do anything fancy.
	Please check entries for validation rules before adding, the code only does this at
	minimal level!
</p>

<form method="post">
<table>
	<tr>
		<th>Facility Details</th>
	</tr>
	<tr>
		<td>
			
			<table>
				<tr>
					<td>ID: [leave blank]</td>
					<td><input type="text" name="id" value="<?=$id?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Name: [char:15]</td>
					<td><input type="text" name="name" value="<?=$name?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Description: [char:100]</td>
					<td><input type="text" name="desc" value="<?=$desc?>" maxlength="100" /></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<input type="submit" value="Add/Update" />
		</td>
	</tr>
</table>
</form>


<?php
//show only if current facility
if(Validate::isInt($id))
{
	?>
	<!--Dependancies-->
	<form method="post">
	<table>
		<tr>
			<th>Facility Dependancies</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $facility->getPreReq('object');
					foreach($list AS $preReq)
					{
						?>
						<tr>
							<td><?=$preReq->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addReq">
								<?php
								foreach(getResearches() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>

	<!--Cost-->
	<form method="post">
	<table>
		<tr>
			<th>Facility Cost</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$costs = $facility->getCost(true);
					foreach($costs AS $cost)
					{
						?>
						<tr>
							<td><?=$cost->qty?></td>
							<td><?=$cost->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($costs))
					{
						?>
						<tr>
							<td colspan="3"><i>This facility is FREEE! are you sure?</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$_GET['facility']?>" />
							<select name="addCost">
								<?php
								foreach(getResources() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="text" name="qty" maxlength="10" />
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	<!--Resource Production-->
	<form method="post">
	<table>
		<tr>
			<th>Resource Production</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$productions = $facility->producesResource(true);
					foreach($productions AS $production)
					{
						?>
						<tr>
							<td><?=$production->qty?></td>
							<td><?=$production->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($productions))
					{
						?>
						<tr>
							<td colspan="3"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$_GET['facility']?>" />
							<select name="addOutResource">
								<?php
								foreach(getResources() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="text" name="qty" maxlength="10" />
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	<!--Unit Production-->
	<form method="post">
	<table>
		<tr>
			<th>Unit Production</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$productions = $facility->producesUnit(true);
					foreach($productions AS $production)
					{
						?>
						<tr>
							<td><?=$production->qty?></td>
							<td><?=$production->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($productions))
					{
						?>
						<tr>
							<td colspan="3"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$_GET['facility']?>" />
							<select name="addOutUnit">
								<?php
								foreach(getUnits() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="text" name="qty" maxlength="10" />
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>	
	<?php
}

?>