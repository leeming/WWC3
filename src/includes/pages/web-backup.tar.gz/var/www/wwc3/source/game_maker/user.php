<?php
require("../tiggerConfig.php");
require_once("../classes/Database.class.php");
require_once("../classes/User.class.php");
require_once("../classes/Validate.class.php");


$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

if(!empty($_POST))
{
	print"<b>POSTED</b><br>";
	print"<pre>"; print_r($_POST); print"</pre>";

	//new or update?
	if($_POST['id'] == "") //new
	{
		$insert = array('username' => $_POST['username'],
						'handle' => $_POST['handle'],
						'email' => $_POST['email'],
						'password' => $_POST['password']);

		$id = User::add($insert);

		if(!Validate::isInt($id))
			print "<br><br>Error:".$id;
		else if($id == -1)
			print"<br><br>Failed";

		$_GET['id'] = $id;
	}
	else //update
	{}

}

if(Validate::isInt($_GET['id']))
{
	$user = new User($_GET['id']);
	
	$id = $user->id;
	$username = $user->username;
	$email = $user->email;
	$handle=$user->handle;
}
else
{
	$id = "";
	$name = "";
	$email = "";
	$handle = "";
}


?>
<a href="index.php">Back</a>

<p style="color:red;">
	<b>Notice:</b> This is a basic data entry form, it does <b>not</b> do anything fancy.
	Please check entries for validation rules before adding, the code only does this at
	minimal level!
</p>

<form method="post">
<table>
	<tr>
		<th>User Details</th>
	</tr>
	<tr>
		<td>
			
			<table>
				<tr>
					<td>ID: [leave blank]</td>
					<td><input type="text" name="id" value="<?=$id?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Username: [char:20]</td>
					<td><input type="text" name="username" value="<?=$username?>" maxlength="20" /></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input type="text" name="password" value="" /></td>
				</tr>
				<tr>
					<td>Email: [char:45]</td>
					<td><input type="text" name="email" value="<?=$email?>" maxlength="45" /></td>
				</tr>
				<tr>
					<td>Handle: [char:20]</td>
					<td><input type="text" name="handle" value="<?=$handle?>" maxlength="20" /></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<input type="submit" value="Add/Update" />
		</td>
	</tr>
</table>
</form>