<?php
require("../tiggerConfig.php");
require("includeAll.php");
require_once("functions.php");


$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

if(!empty($_POST))
{
	print"<b>POSTED</b><br>";
	print"<pre>"; print_r($_POST); print"</pre>";

	
	//post is add resource
	if($_POST['addResource'])
	{
		$resource = new Resource($_POST['addResource'], $_POST['qty']);
		
		$region = new Region($_POST['region']);
		$region->addBonus($resource);
		
	}
	//post is add country to region
	elseif($_POST['addCountry'])
	{
		$region = new Region($_POST['region']);
		$region->addCountry($_POST['addCountry']);
	}
	else
	{
		//new or update?
		if($_POST['id'] == "") //new
		{
			$insert = array('name' => $_POST['name']);
	
			$id = Region::add($insert);
	
			if($id == -1)
				print"<br><br>Failed";
	
			$_GET['region'] = $id;
		}
		else //update
		{}
	}
}

if(Validate::isInt($_REQUEST['region']))
{
	$region = new Region($_REQUEST['region']);
	
	$id = $region->id;
	$name = $region->name;
}
else
{
	$id = "";
	$name = "";
}


?>
<a href="index.php">Back</a>

<p style="color:red;">
	<b>Notice:</b> This is a basic data entry form, it does <b>not</b> do anything fancy.
	Please check entries for validation rules before adding, the code only does this at
	minimal level!
</p>

<form method="post">
<table>
	<tr>
		<th>Region Details</th>
	</tr>
	<tr>
		<td>
			
			<table>
				<tr>
					<td>ID: [leave blank]</td>
					<td><input type="text" name="id" value="<?=$id?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Name: [char:15]</td>
					<td><input type="text" name="name" value="<?=$name?>" maxlength="15" /></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<input type="submit" value="Add/Update" />
		</td>
	</tr>
</table>
</form>



<?php
//show only if current region
if(Validate::isInt($id))
{
	?>
	<!--Production-->
	<form method="post">
	<table>
		<tr>
			<th>Region Resources</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $region->getBonus();
					foreach($list AS $bonus)
					{
						?>
						<tr>
							<td><?=$bonus->qty?></td>
							<td><?=$bonus->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="3"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="text" name="qty" />
						</td>
						<td>
							<input type="hidden" name="region" value="<?=$id?>" />
							<select name="addResource">
								<?php
								foreach(getResources() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
		<!--Countries in region-->
	<form method="post">
	<table>
		<tr>
			<th>Region Contains</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $region->contains('object', true);
					foreach($list AS $country)
					{
						?>
						<tr>
							<td><?=$country->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="region" value="<?=$id?>" />
							<select name="addCountry">
								<?php
								foreach(getCountries() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>		
	
	<?php
}
?>