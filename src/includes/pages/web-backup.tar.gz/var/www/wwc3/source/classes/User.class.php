<?php
/**
 * List of classes used by this class
 */
require_once("Profile.class.php");
require_once("Mail.class.php");
require_once("Medal.class.php");


/**
 * Main class which holds all info on an account
 * via ref to various other classes
 * 
 * @author leeming
 * @todo Methods to be added regarding Player & Game classes as these
 * 		 classes mature.
 */
class User
{
	public $id, $username,  $handle,  $email;


   /**
	 * Account constructor, creates a member for $id
	 *
	 * @param int $id Id of the user
	 */
	function __construct($id)
	{
		global $db;
		$this->db = &$db;
		
		//Validate $id is int
		if(!Validate::isInt($id))
		{
			trigger_error("(int)\$id expected, (".gettype($id).") passed", E_USER_ERROR);
			return;
		}

		//does account exist? / get username/handle/email
		$this->db->query("SELECT SQL_CACHE username, handle, email FROM Users WHERE id ='".$id."' LIMIT 1");

		if($this->db->numRows == 0)
		{
			trigger_error("There is no account with this id (".$id.")", E_USER_WARNING);
			return;
		}

		$result = $this->db->getRow();

		$this->id = $id;
		$this->username = $result['username'];
		$this->handle = $result['handle'];
		$this->email = $result['email'];

		//etc
	}

	private $activated = NULL;

	/**
	 * Finds out if the member has activated their account yet or not
	 *
	 *	@return	bool
	 */
	 function isActivated()
	 {
		 //lookup only if not done so before
		 if($this->activated != NULL)
		{
			//check activation table, if record found user isnt activated
			$this->db->query("SELECT true FROM Activation_codes WHERE user_id ='{$this->id}' LIMIT 1");
			$this->activated = ($this->db->numRows == 1);

		}

		return $this->activated;
	 }

	/**
	 * Finds out if current user is an admin
	 *
	 * @todo Staff permissions still needs adding
	 * @return bool
	 */
	function isAdmin()
	{
		return ($this->id == 1);
	}
	
	/**
	 * Allows a user to change their password. Due to security
	 * all attempts are logged and previous password needs
	 * to be given.
	 *
	 * @param string $oldPw
	 * @param string $newPw
	 * @return bool On success
	 */
	function changePassword($oldPw, $newPw)
	{
		//Escape any naughty sql
		$oldPw = $this->db->escape($oldPw);
		$newPw = $this->db->escape($newPw);
		
		$sql = "SELECT changePassword({$this->id},'{$oldPw}','{$newPw}') AS changeSuc";
		$this->db->query($sql);
		$result = $this->db->getRow();
		return $result['changeSuc'];
		
		return false;
	}

	/**
	 * Depending on $returnType, returns an array of mail ids or array of Mail objects
	 *
	 * @param string $returnType
	 * @return int[] | Mail[]
	 */
	 function getMail($returnType = "int")
	 {
		 if($returnType == 'int')
		 {
			return Mail::getMailIds($this->id);
		 }
		else
		{
			return Mail::getMail($this->id);
		}
	 }


	 private $profile = NULL;

	 /**
	 * Fetchs the Profile class for the current user. If this has not been
	 * called yet, then a call is made to make a new Profile object and
	 * then returns the newly created reference.
	 * If this has already been called, then the reference to the prior
	 * call is returned.
	 *
	 * @returns	Profile
	 */
	function getProfile()
	{
		//check to see if already fetched
		if($this->profile == null)
		{
			//get profile data
			$this->profile = new Profile($this->id);
		}

		return $this->profile;
	}


	private $inGames = NULL;
	private $inGameIds = NULL;

	/**
	 * Gets a list of games which the user is in
	 * paired with player id, array(game_id => player_id)
	 *
	 * @param String $returnType
	 * @return	array(game_id => player_id)
	 */
	 function getGames($returnType = "int")
	 {
		 //get array of games user is in
		$query = $this->db->fetch_all_array("SELECT game_id,id FROM Players WHERE user_id = '{$this->id}' ");
		$returnArray = array();

		if($returnType == 'int')
		{
			//make array of game ids
			foreach($query AS $result)
			{
				$returnArray[$result['game_id']] = $result['id'];
			}
			
			$this->inGameIds = $returnArray;
		}
		/* 
		else
		{
			//make array of Game objects
			foreach($query AS $result)
			{
				$returnArray[] = new Game($result['game_id']);
			}

			$this->inGames = $returnArray;
		}
		*/
		return $returnArray;
	 }

	 /**
	  *  Gets a list of medals which the user has
	  * 
	  * @return int[]/Medals[]
	  */
	 function getMedals($returnType = "int")
	 {
		 //get array of games user is in
		$query = $this->db->fetch_all_array("SELECT medal_id FROM User_has_medal WHERE user_id = '{$this->id}' ");
		$returnArray = array();

		 if($returnType == 'int')
		 {
			 //make array of medal ids
			foreach($query AS $result)
			{
				$returnArray[] = $result['medal_id'];
			}
		 }
		else
		{
			//make array of Medal objects
			foreach($query AS $result)
			{
				$returnArray[] = new Medal($result['medal_id']);
			}
		}

		return $returnArray;
	 }

	/**
	 * Gets a list of logins for user
	 *
	 * @param int $num Number of records to get
	 * @return array()
	 */
	function getLogins($num = 1)
	{
		if(!Validate::isInt($num) || $num < 1)
		{
			return -1;
		}
		
		$sql = "SELECT login_timestamp, ip FROM Logins WHERE "
			."user_id='{$this->id}' ORDER BY login_timestamp DESC LIMIT ".$num;
		$result = $this->db->fetch_all_array($sql);
		
		$return = array();
		foreach($result AS $record)
		{
			$return[] = array('timestamp'=>$record['login_timestamp'],
							  'ip'=>$record['ip']);
		}
		
		return $return;
	}

	 /**
	 * Does all the various checks for login and returns id on login
	 * but on failure returns the error str
	 *
	 * @param String $username
	 * @param String $password
	 * @return int/String
	 */
	 static function login($username, $password)
	 {
		global $db;

		//check username is valid
		if(!Validate::isUsername($username))
		{
			return "INVALID_USERNAME";
		}
		//make sure password is not null
		if(empty($password))
		{
			return "EMPTY_PASS";
		}

		//check username & password correct
		$password = $db->escape($password);
		$db->query("SELECT userLogin('{$username}', '{$password}') AS userid");
		$result = $db->getRow();


		if($result['userid'] == -1)
		{
			#Account not found
			return "WRONG_UN_PW";
		}

		$_SESSION['wwclogin'] = $result['userid'];

		#Add into login records
		$ip = $_SERVER['REMOTE_ADDR'];
		//Extract browser name
		////todo
		$browser = "";
		$version = "";
		$os = "";
		$userAgent = $_SERVER['HTTP_USER_AGENT'];

		$sql = "INSERT INTO Logins (`user_id`, `login_timestamp`, `ip`, `browser_name`, `browser_ver`, `os`, `user_agent`)".
			"VALUES ('".$result['userid']."', '".time()."', '".$ip."', '".$browser."', '".$version."', '".$os."', '".$userAgent."')";
		$db->query($sql);

		return $result['userid'];
	 }


	
	
	/**
	 * Makes a new user, returns: String on error, 0 on failed mysql,
	 * else id of new game
	 *
	 * @param array $insertArray Assoc array with fields to add
	 * @return int User Id
	 */
	static function add(array $insertArray)
	{
		//check username
		if(!array_key_exists('username', $insertArray) ||
			!Validate::isUsername($insertArray['username']))
		{
			return "INVALID_USER";
		}
		//check email
		if(!array_key_exists('email', $insertArray) ||
			!Validate::isEmail($insertArray['email']))
		{
			return "INVALID_EMAIL";
		}
		//check handle
		if(!array_key_exists('handle', $insertArray) ||
			!Validate::isHandle($insertArray['handle']))
		{
			return "INVALID_HANDLE";
		}
		//check password
		if(!array_key_exists('password', $insertArray) ||
			empty($insertArray['password']))
		{
			return "INVALID_PASSWORD";
		}
		
		
		//make sure some one already has user/handle/email
		if(Validate::usernameExists($insertArray['username']))
		{
			return "USER_IN_USE";
		}
		if(Validate::handleExists($insertArray['handle']))
		{
			return "HANDLE_IN_USE";
		}
		if(Validate::emailExists($insertArray['email']))
		{
			return "EMAIL_IN_USE";
		}
		
		//insert user
		global $db;
		$db->query("SELECT makeUser('{$insertArray['username']}', "
			."'{$insertArray['password']}', '{$insertArray['email']}', "
			."'{$insertArray['handle']}') AS userid");
		$result = $db->getRow();
		
		return $result['userid'];
	}

	/**
	 * Get a user's handle from $id
	 *
	 * @param int $id User to lookup
	 * @return string User's handle
	 */
	static function getHandle($id)
	{
		//Validate $id is int
		if(!Validate::isInt($id))
		{
			trigger_error("(int)\$id expected, (".gettype($id).") passed", E_USER_ERROR);
			return;
		}
		
		global $db;
		$sql = "SELECT handle FROM Users WHERE id='{$id}' LIMIT 1";
		$db->query($sql);
		$result = $db->getRow();
		
		return $result['handle'];
	}

	function __wakeup()
	{
		//refresh db connection
		global $db;
		$this->db = $db;
	}
}
?>
