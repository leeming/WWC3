<?php
function getSettings()
{
	global $db;

	//get list of settings
	$settings = array();
	$result = $db->fetch_all_array("SELECT id FROM Settings");

	foreach($result AS $setting)
	{
		$settings[] = new Settings($setting['id']);
	}

	return $settings;
}

function getCountries()
{
	global $db;

	//get list of countries
	$countries = array();
	$results = $db->fetch_all_array("SELECT id FROM Countries");

	foreach($results AS $result)
	{
		$countries[] = new Country($result['id']);
	}
	
	return $countries;
}

function getRegions()
{
	global $db;

	$return = array();
	$results = $db->fetch_all_array("SELECT id FROM Regions");

	foreach($results AS $result)
	{
		$return[] = new Region($result['id']);
	}

	return $return;
}

function getFacilities()
{
	global $db;

	$return = array();
	$results = $db->fetch_all_array("SELECT id FROM Facilities");

	foreach($results AS $result)
	{
		$return[] = new Facility($result['id']);
	}

	return $return;
}

function getResources()
{
	global $db;

	$return = array();
	$results = $db->fetch_all_array("SELECT id FROM Resources");

	foreach($results AS $result)
	{
		$return[] = new Resource($result['id']);
	}

	return $return;
}

function getResearches()
{
	global $db;

	$return = array();
	$results = $db->fetch_all_array("SELECT id FROM Research");

	foreach($results AS $result)
	{
		$return[] = new Research($result['id']);
	}

	return $return;
}

function getTeams()
{
	global $db;

	$return = array();
	$results = $db->fetch_all_array("SELECT id FROM Teams");

	foreach($results AS $result)
	{
		$return[] = new Team($result['id']);
	}

	return $return;
}
function getUnits()
{
	global $db;

	$return = array();
	$results = $db->fetch_all_array("SELECT id FROM Units");

	foreach($results AS $result)
	{
		$return[] = new Unit($result['id']);
	}

	return $return;
}
function getUnitTypes()
{
	global $db;

	$return = array();
	$results = $db->fetch_all_array("SELECT id FROM Unit_types");

	foreach($results AS $result)
	{
		$return[] = new UnitType($result['id']);
	}

	return $return;
}

function getStats()
{
	global $db;

	$return = array();
	$results = $db->fetch_all_array("SELECT id FROM Unit_stats");

	foreach($results AS $result)
	{
		$return[] = new Stat($result['id']);
	}

	return $return;
}

function getGames()
{
	global $db;

	$return = array();
	$results = $db->fetch_all_array("SELECT id FROM Games");

	foreach($results AS $result)
	{
		$return[] = new Game($result['id']);
	}

	return $return;
}

function getUsers()
{
	global $db;
	
	$return = array();
	$results = $db->fetch_all_array("SELECT id FROM Users");

	foreach($results AS $result)
	{
		$return[] = new User($result['id']);
	}

	return $return;
}

?>
