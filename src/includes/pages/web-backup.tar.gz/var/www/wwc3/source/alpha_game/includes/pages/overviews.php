<?php
if(isset($args['view']) && $args['view'] == "general")
	require("overview-general.php");
?>