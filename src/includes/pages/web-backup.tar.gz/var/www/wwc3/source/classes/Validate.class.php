<?php
/**
 * Description of Validateclass
 *
 * @author leeming
 */
class Validate
{
	/**
	 * Check to see if value passed can be shown as an int
	 *
	 * @param any $value
	 * @return bool;
	 */
   static function isInt($value)
	{
		if(gettype($value) == "object")
			return false;
		else
			return ctype_digit((string)"$value");
	}

	/**
	 * Check to see if username is valid
	 *
	 * @param string $username Username to check
	 * @return bool
	 */
	static function isUsername($username)
	{
		return ereg("^[A-Za-z0-9_]{3,15}$",$username);
	}
	
	/**
	 * Check to see if username currently exists
	 *
	 * @param string $username Username to check
	 * @return bool
	 */
	static function usernameExists($username)
	{
		global $db;
		if(Validate::isUsername($username))
		{
			$db->query("SELECT id FROM Users WHERE username='{$username}' LIMIT 1");
			return ($db->numRows == 1);
		}
		//else invalid usernmae
		return false;
	}

	/**
	 * Check to see if handle is valid
	 *
	 * @param string $handle Handle to check
	 * @return bool
	 */
	static function isHandle($handle)
	{
		return ereg("^[A-Za-z0-9_]{3,15}$",$handle);
	}

	/**
	 * Check to see if handle currently exists
	 *
	 * @param string $handle Username to check
	 * @return bool
	 */
	static function handleExists($handle)
	{
		global $db;
		if(Validate::isHandle($handle))
		{
			$db->query("SELECT id FROM Users WHERE handle='{$handle}' LIMIT 1");
			return ($db->numRows == 1);
		}
		//else invalid handle
		return false;
	}


	/**
	 * Check to see if email is valid
	 *
	 * @param string $email Email to check
	 * @return bool
	 */
	static function isEmail($email)
	{
		return true;
	}
	
	/**
	 * Check to see if email currently exists
	 *
	 * @param string $email Username to check
	 * @return bool
	 */
	static function emailExists($email)
	{
		global $db;
		if(Validate::isUsername($email))
		{
			$db->query("SELECT id FROM Users WHERE email='{$email}' LIMIT 1");
			return ($db->numRows == 1);
		}
		//else invalid usernmae
		return false;
	}


}
?>
