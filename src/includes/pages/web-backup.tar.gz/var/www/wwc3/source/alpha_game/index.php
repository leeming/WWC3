<?php
require_once("../tiggerConfig.php");
require_once("../classes/Database.class.php");
require_once("../classes/Validate.class.php");
require_once("../classes/User.class.php");

$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();


//Include UI Template
require("ui/template.php");

unset($_SESSION['track']);
$db->close();

/*
if(!empty($_POST))
{
	session_start();
	//try to login
	$login = User::login($_POST['uname'], $_POST['pword']);
	
	
	if(Validate::isInt($login))
	{
		$_SESSION['user'] = serialize(new User($login));
		header("Location: lobby.php");
	}
	else
	{
		print"Login Error:".$login;
	}
}


?>

<div class="login">
	<form action="" method="post">
	<div class="row">
		<div class="label">Username</div>
		<div class="data">
			<input type="text" name="uname" />
		</div>
	</div>
	<div class="row">
		<div class="label">Password</div>
		<div class="data">
			<input type="password" name="pword" />
		</div>
	</div>
	<div class="row">
		<div class="submit">
			<input type="submit" value="Login" />
		</div>
	</div>
	</form>
</div>
*/
?>