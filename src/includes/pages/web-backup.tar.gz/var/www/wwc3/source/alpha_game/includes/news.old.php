<a href="?page=news">News</a> | <a href="?page=games&action=my">My Games</a> |
<a href="?page=games&action=all">List Games</a> | <a href="?page=debug">Debug</a> |
<a href="logout.php">Logout</a> | 

<p>There is no news</p>