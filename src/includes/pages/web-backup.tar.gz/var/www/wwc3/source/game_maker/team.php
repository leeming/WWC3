<?php
require("../tiggerConfig.php");
require_once("../classes/Database.class.php");
require_once("../classes/Team.class.php");
require_once("../classes/Validate.class.php");


$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

if(!empty($_POST))
{
	print"<b>POSTED</b><br>";
	print"<pre>"; print_r($_POST); print"</pre>";

	//new or update?
	if($_POST['id'] == "") //new
	{
		$insert = array('name' => $_POST['name']);

		$id = Team::add($insert);

		if($id == -1)
			print"<br><br>Failed";

		$_GET['team'] = $id;
	}
	else //update
	{}

}

if(Validate::isInt($_GET['team']))
{
	$team = new Team($_GET['team']);
	
	$id = $team->id;
	$name = $team->name;
}
else
{
	$id = "";
	$name = "";
}


?>
<a href="index.php">Back</a>

<p style="color:red;">
	<b>Notice:</b> This is a basic data entry form, it does <b>not</b> do anything fancy.
	Please check entries for validation rules before adding, the code only does this at
	minimal level!
</p>

<form method="post">
<table>
	<tr>
		<th>Team Details</th>
	</tr>
	<tr>
		<td>
			
			<table>
				<tr>
					<td>ID: [leave blank]</td>
					<td><input type="text" name="id" value="<?=$id?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Name: [char:20]</td>
					<td><input type="text" name="name" value="<?=$name?>" maxlength="20" /></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<input type="submit" value="Add/Update" />
		</td>
	</tr>
</table>
</form>