<?php

/**
 * List of classes used by this class
 */
require_once("Base.class.php");
require_once("Validate.class.php");
require_once("Research.class.php");

/**
 * Class to control a player's research queue in a game
 * 
 * @todo Premium players can have larger queue
 * @todo "Add research "with pre-requisites included
 * @todo Remove research
 * @author	Leeming
 */
class ResearchQueue extends Base
{
	public $maxQueue = 5;
	public $queue;
	
	/**
	 * Constructor for the ResearchQueue Class
	 */
	function __construct(Player $player)
	{
		parent::__construct();
		
		$sql = "SELECT * FROM Player_research_queue WHERE player_id='{$player->id}' AND active = '1' ORDER BY pos ASC";
		$result = $this->db->fetch_all_array($sql);
		
		$this->queue = array();
		foreach($result AS $r)
		{
			$this->queue[] = array('pos' => $r['pos'],
								   'research' =>$r['research_id'],
								   'ticksDone'=>$r['ticksDone']);
		}
		
		//check to make sure queue has not overflowed
		if(count($this->queue) > $this->maxQueue)
		{ print count($this->queue)." > ".$this->maxQueue;
			trigger_error("Error: Player queue is bigger than max", E_USER_WARNING);
			return;
		}
		
		$this->playerId = $player->id;
		$this->gameId = $player->game->id;
		$this->player = &$player;
	}
	
	function in_array($search)
	{
		foreach($this->queue AS $chk)
		{
			if($chk['research'] == $search)
				return true;
		}
		
		return false;
	}
	
	/**
	 * Add a research into a research queue
	 *
	 * @param int/Research $research
	 * @return bool True if added
	 */
	function add($research)
	{
		global $debug;
		
		//check if $research is valid
		if(!Validate::isInt($research) && get_class($research) == "research")
			return false;
		
		if(get_class($research) == "research")
			$research=$research->id;
		
		$debug->add("1");
		//check if current queue is maxed
		if(count($this->queue) >= $this->maxQueue)
		{
			return false;
		}
		
		$debug->add("2");
		//check if already in queue
		foreach($this->queue AS $chk)
		{
			//player already has this research in queue
			if($chk['research'] == $research)
				return false;
		}
		
		$debug->add("3");

		//check pre requisites
		$toAdd = new Research($research);
		$preReq = $toAdd->getPreReq();
		$playerResearches = $this->player->getResearches();
		
		foreach($preReq AS $a)
		{ 
			//if $a is not in player researches, then dont do research
			if(!in_array($a, $playerResearches) && !$this->in_array($a))
				return false;
		}
		
		$debug->add("4");
		
		#if here all should be ok, player has all pre req
		
		$sql = "INSERT INTO Player_research_queue (`player_id`, `research_id`,
			`ticks_done`, `pos`) VALUES ({$this->playerId}, {$research}, '0',
			'".count($this->queue)."') ON DUPLICATE KEY UPDATE `active` = 1";
		$this->db->query($sql);
		
		if($this->db->affected_rows != 1)
			return false;

		$debug->add("5");

		//Get ticks done if continued
		$sql = "SELECT ticks_done FROM Player_research_queue WHERE ".
			"player_id='{$this->playerId}' AND research_id='{$research}'".
			" LIMIT 1";
		$this->db->query($sql);
		$result = $this->db->getRow();
		
		//add onto current current queue
		$this->queue[] = array('pos' => count($this->queue),	
							   'research' =>$research,
							   'ticksDone'=>$result['ticksDone']);
		
		/*
		 $insertArray = array('player_id' => $this->playerId,
							 'research_id' => $research,
							 'ticks_done' => '0',
							 'pos' => count($this->queue));
		$this->db->query_insert("Player_research_queue", $insertArray);
		*/
		return true;
	}
	
	/**
	 * Accessor for getting the research queue
	 *
	 * @param int $index Get single entry, or null for all
	 * @return array
	 */
	function get($index = NULL)
	{
		if(Validate::isInt($index) && $index < count($this->queue))
			return $this->queue[$index];
		else
			return $this->queue;
	}
	
	
	/**
	 * Find out if a player can add more researches to their
	 * research queue. This could mean player has max queue
	 * or they do not own any research labs
	 *
	 * @return bool
	 */
	function canResearch()
	{
		if(count($this->queue) >= $this->maxQueue)
			return false;
		elseif(false /* Research labs */)
			return false;
		else
			return true;
	}
}
?>
