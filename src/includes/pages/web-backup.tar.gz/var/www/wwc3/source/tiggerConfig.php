<?php

/* Test server */
if($_SERVER['SERVER_ADDR'] == "127.0.0.1")
{
	#Site values
	define('SITE_URL',"192.168.11.2");
	define('SITE_ROOT',"/var/www/wwc3/source");
	define('SITE_TITLE',"WWC3");

	
	#Database values
	define('DB_HOST',"localhost");
	define('DB_USER',"root");
	define('DB_PASS',"n3wbu1ld");
	define('DB_NAME',"wwcdev");
}
/* Live server */
else
{
	
	#Site values
	define('SITE_URL',"216.119.128.2");
	define('SITE_ROOT',"/home/dlym/public_html/");
	define('SITE_TITLE',"WWC3");

	
	#Database values
	define('DB_HOST',"localhost");
	define('DB_USER',"dlym");
	define('DB_PASS',"oldhugo00");
	//define('DB_USER',"dlym_leeming");
	//define('DB_PASS',"silvermoon");
	define('DB_NAME',"dlym_wwcdev");	
}

/* List of consts used */
define('RESOURCE_MONEY', 1);
define('RESOURCE_TURNS', 2);

?>