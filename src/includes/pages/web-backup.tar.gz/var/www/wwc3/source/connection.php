<?php
#Connect to DB
if($con = @mysql_connect(DB_HOST, DB_USER, DB_PASS))
{ 
	if(!$db = @mysql_select_db(DB_NAME, $con))
	{
		#Failed connection to DB

		//Trigger error and return false
		//trigger_error('Database connection failed', E_USER_WARNING);
		die("ERROR_SQL_DB");
	}		
}
else
{
	//trigger_error('Server connection failed', E_USER_WARNING);
	die("ERROR_SQL_CONNECT");
}

?>
