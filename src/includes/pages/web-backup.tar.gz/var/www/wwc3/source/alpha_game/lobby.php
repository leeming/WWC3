<?php
session_start();
/*
//Check to see session data is set, if not divert to index
if(!key_exists('user', $_SESSION))
{
	$_SESSION['debug'][] = array('timestamp' => time(),
								 'text' => "Redirect:: Not logged in",
								 'request' => $_REQUEST);
	header("Location: index.php");
}*/

//get config file & connection
require_once("../tiggerConfig.php");
require_once("../classes/Database.class.php");
require_once("../classes/Validate.class.php");
require_once("../classes/User.class.php");
require_once("../classes/Player.class.php");
require_once("../classes/Debug.class.php");
require_once("../classes/FirePHPCore-0.3.1/lib/FirePHPCore/FirePHP.class.php");

$debug = new Debug();
$firephp = FirePHP::getInstance(true);
ob_start();

$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();



if(key_exists('user', $_SESSION))
	$user = unserialize($_SESSION['user']);
if(key_exists('player', $_SESSION))
	$player = unserialize($_SESSION['player']);
	
############################
### Lobby pages go below ###
############################

//List all pages allowed to view in the format 'pageName' => 'fileLocation'
$publicPages = array(//'About' pages
					  'news' => "pages/news.php",
					  'about' => "pages/about.php",
					  'contact' => "pages/contact.php",
					  'staff' => "pages/staff.php",
					  
					  //'Help' pages
					  'faq' => "pages/faq.php",
					  'guides' => "pages/guides.php",
					  'helpcentre' => "pages/help.php",
					  
					  //'Feedback' pages
					  'bugs' => "pages/bugs.php",
					  'ideas' => "pages/ideas.php",
					  'praise' => "pages/praise.php",
					  'question' => "pages/questions.php",
					  
					  //Misc pages
					  'error' => "pages/error.php",
					  'debug' => "pages/debug.php",
					  'login' => "pages/login.php",
					  'register' => "pages/signup.php"
);
$lobbyPages = array(  //Account pages
					  'profile' => "pages/profile.php",
					  'password' => "pages/changePassword.php",
					  'premium' => "pages/premium.php",
					  'invite' => "pages/inviteFriend.php",
					  'email' => "pages/manageEmail.php",
					  'alerts' => "pages/manageAlerts.php",
					  'logout' => "pages/logout.php",
						
					  //Games pages	
					  'games' => "pages/listGames.php",
					  'play'=> "pages/play.php",
					  'end'=> "pages/endGame.php",
					  'makeGame'=> "pages/makeGame.php",
					  
					  //Mail pages
					  'mail' => "pages/mail.php",
					  'list' => "pages/buddyLists.php",
					  
					  //Misc
					  'welcome' => "pages/welcome.php",
					  
					  //AJAX
					  'get'	=> "ajax/queryGetter.php"
);
$gamePages = array(  //Game Navigation pages
					  'build' => "pages/buildings.php",
					  'overview' => "pages/overviews.php",
					  'forum' => "pages/forum.php",
					  'chat' => "pages/chat.php",
					  'actions' => "pages/militaryActions.php",
					  'battalions' => "pages/battalion.php",
					  'research' => "pages/research.php",
					  'team' => "pages/team.php",
					  'market' => "pages/market.php",
					  'bank' => "pages/bank.php"
	
);

//if no page is given, show this default
if(!isset($_REQUEST['page']) || $_REQUEST['page'] == "")
{
	//Default page
	$page = "news";
}
else
{
	$page = $_REQUEST['page'];
}

#check page is allowed
//logged in pages
if(key_exists($page, $lobbyPages) || key_exists($page, $gamePages) )
{
	//Check to see session data is set, if not error
	if(!key_exists('user', $_SESSION))
	{
		$_SESSION['debug'][] = array('timestamp' => time(),
									 'text' => "Redirect:: Not logged in",
									 'request' => $_REQUEST);
		$page ="error";
		$args['code'] = "NOT_LOGGED_IN";
	}
	else
	{
		//$user = unserialize($_SESSION['user']);
		
		//if page is game, check game id is set
		if(key_exists($page, $gamePages))
		{
			if(isset($player))
			{
				//$player = unserialize($_SESSION['player']);
				$pagePath = $gamePages[$page];
			}
			else
			{
				//throw error for now because not added any game pages;
				$page = "error";
				$args['code'] = "GAME_NOT_SET";
			}
		}
		//else page should be lobby page
		else 
		{
			$pagePath = $lobbyPages[$page];
		}
	}
}
//else public page
else if(!key_exists($page, $publicPages))
{
	$page="error";
	$args['code'] = "PAGE_NOT_ALLOWED";
}
//else page is public page
else
{
	$pagePath = $publicPages[$page];
}

//catch error page and set pagePath
if($page == "error")
	$pagePath = $publicPages['error'];

$absoluteDirPath = SITE_ROOT."/alpha_game/includes/";

//check to see if page exists (on the filestore)
if(!file_exists($absoluteDirPath.$pagePath))
{
	$page="error";
	$pagePath = $publicPages['error'];
	$args['code'] = "PAGE_NOT_ADDED";
}

//save all request data
foreach(array_merge($_GET,$_POST) AS $index => $value)
{
	$args[$index] = $value;
}

//log page requests
$_SESSION['track'][] = array('timestamp' =>time(),
							 'page' => $page,
							 'pageReq' => $_REQUEST['page'],
							 'request' => $args);

//load page here
//print $absoluteDirPath.$pagePath;
require($absoluteDirPath.$pagePath);


##########################
### End of lobby pages ###
##########################

if(isset($user))
	$_SESSION['user'] = serialize($user);
if(isset($player))
	$_SESSION['player'] = serialize($player);
	
$db->close();
?>