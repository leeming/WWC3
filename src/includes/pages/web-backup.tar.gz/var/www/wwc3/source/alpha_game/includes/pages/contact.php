<p>We would like to remind users that there are designated areas for contacting us for the following<br>
	<ul>
		<li>Reporting Bugs (<a onclick="loadWindow('bugs')" href="#">here</a>)</li>
		<li>Game Ideas &amp; Suggestions (<a onclick="loadWindow('idea')" href="#">here</a>)</li>
		<li>Thanks &amp; praise (<a onclick="loadWindow('praise')" href="#">here</a>)</li>
		<li>Reporting Game Abuse (<a onclick="loadWindow('abuse')" href="#">here</a>)</li>
	</ul>
</p>

<p>
	If your query is still not satisified with the above, then feel free to continue
	to fill out the following contact form. Your email will only be used so we can
	respond to you.<br><br>
	<i>Form comming soon</i>
</p>