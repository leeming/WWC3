<?php
require("../tiggerConfig.php");
require_once("../classes/Database.class.php");
require_once("../classes/Research.class.php");
require_once("../classes/Validate.class.php");
require_once("functions.php");


$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

if(!empty($_POST))
{
	print"<b>POSTED</b><br>";
	print"<pre>"; print_r($_POST); print"</pre>";

	//post is add req
	if($_POST['addReq'])
	{
		$research = new Research($_POST['id']);
		$research->addPreReq($_POST['addReq']);
	}
	//post is body info
	else
	{
		//new or update?
		if($_POST['id'] == "") //new
		{
			$insert = array('name' => $_POST['name'],
							'desc' => $_POST['desc']);

			$id = Research::add($insert);

			if($id == -1)
				print"<br><br>Failed";

			$_GET['research'] = $id;
		}
		else //update
		{}
	}

}

if(Validate::isInt($_GET['research']))
{
	$research = new Research($_GET['research']);
	
	$id = $research->id;
	$name = $research->name;
	$desc = $research->desc;
}
else
{
	$id = "";
	$name = "";
	$desc = "";
}


?>
<a href="index.php">Back</a>

<p style="color:red;">
	<b>Notice:</b> This is a basic data entry form, it does <b>not</b> do anything fancy.
	Please check entries for validation rules before adding, the code only does this at
	minimal level!
</p>

<form method="post">
<table>
	<tr>
		<th>Research Details</th>
	</tr>
	<tr>
		<td>
			
			<table>
				<tr>
					<td>ID: [leave blank]</td>
					<td><input type="text" name="id" value="<?=$id?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Name: [char:30]</td>
					<td><input type="text" name="name" value="<?=$name?>" maxlength="30" /></td>
				</tr>
				<tr>
					<td>Description: [char:100]</td>
					<td><input type="text" name="desc" value="<?=$desc?>" maxlength="100" /></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<input type="submit" value="Add/Update" />
		</td>
	</tr>
</table>
</form>

<?php
//show only if current research
if(Validate::isInt($_GET['research']))
{
	?>
	<form method="post">
	<table>
		<tr>
			<th>Research Dependancies</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $research->getPreReq('object');
					foreach($list AS $preReq)
					{
						?>
						<tr>
							<td><?=$preReq->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$_GET['research']?>" />
							<select name="addReq">
								<?php
								foreach(getResearches() AS $re)
								{
									if(!$re->equals($research))
									{
										?>
										<option value="<?=$re->id?>"><?=$re->name?></option>
										<?php
									}
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	<?php
}

?>