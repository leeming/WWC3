<?php
require_once("../classes/Player.class.php");
require_once("../classes/FacilityCollection.class.php");
require_once("../classes/Country.class.php");
require_once("../classes/Battalion.class.php");

//look to see if valid id given
if(!Validate::isInt($args['id']))
{
	print"Invalid Game ID";
	return;
}

//check to see if user in game
$gameList = $user->getGames();
if(!array_key_exists($args['id'],$gameList))
{
	print"User not in game";
	return;
}

//output some player data
$player = new Player($gameList[$args['id']]);
?>
<p>
	############<br>
	## Player Data ##<br>
	############<br>
	User : <?=$user->username?> (<?=$user->id?>)<br>
	Handle : <?=$user->handle?> (<?=$player->id?>)<br>
</p>

<p>
	###########<br>
	## Resources ##<br>
	###########<br>
	<?php
	$playerResources = $player->getResources();
	foreach($playerResources AS $r)
	{
		print $r->qty ." ".$r->name."<br>";
	}
	if(empty($playerResources))
	{
		print "No resources";
	}
	?>
</p>

<p>
	##########<br>
	## Facilities  ##<br>
	##########<br>
	<?php
	$collection = new FacilityCollection();
	$collection->player = $player->id;
	
	$playerFac =  $collection->get();
	foreach($playerFac AS $country => $fac)
	{
		$c = new Country($country);
		print $fac." in {$c->name}<br>";
	}
	
	/*
	$playerFac = $player->getFacilities();
	foreach($playerFac AS $country => $fac)
	{
		$c = new Country($country);
		print $fac."({$c->name})<br>";
	}
	*/
	if(empty($playerFac))
	{
		print "No facilities";
	}
	?>
</p>

<p>
	##########<br>
	## Research  ##<br>
	##########<br>
	
	<?php
	$research =  $player->getResearches('obj');
	foreach($research AS $r)
	{
		print $r->name."<br>";
	}
	
	if(empty($research))
	{
		print "No researches";
	}	
	?>
</p>

<p>
	###########<br>
	## Battalions  ##<br>
	###########<br>
	
	<?php
	$batts = $player->getBattalions();
	foreach($batts AS $b)
	{
		print $b->name."->".$b->commander."(".$b->exp.")<br>";
		print "Contains: <ul>";
		
		foreach($b->getUnits() AS $unit)
		{
			print"<li>".$unit->qty." ".$unit->name."</li>";
		}
		
		print"</ul><br>";
	}
	?>
	
</p>