<?php
require("../tiggerConfig.php");
require_once("includeAll.php");


$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

require_once("functions.php");

$settings = getSettings();
$countries = getCountries(); 
$regions = getRegions();
$units = getUnits();
$teams = getTeams();
$researches = getResearches();
$facilities = getFacilities();
$resources = getResources();
$unitType = getUnitTypes();
$stats = getStats();
$gameList = getGames();
$users = getUsers();



?>
<table>
	<tr>
		<td style="border-right:2px solid black">
<table>
	<tr>
		<td>
			<!-- SETTINGS -->
			<table border="2px">
				<tr>
					<th>Game Settings</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="setting.php">
							<select name="setting">
								<?php
								foreach($settings AS $setting)
								{
									?><option value="<?=$setting->id?>"><?=$setting->name?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="setting.php">New</a>
						</form>
					</td>
				</tr>
			</table>
			
		</td>
		<td>
			<!-- COUNTRIES -->
			<table border="2px">
				<tr>
					<th>Countries</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="country.php">
							<select name="country">
								<?php
								foreach($countries AS $country)
								{
									?><option value="<?=$country->id?>"><?=$country->name?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="country.php">New</a>
						</form>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<!-- REGIONS -->
			<table border="2px">
				<tr>
					<th>Regions</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="region.php">
							<select name="region">
								<?php
								foreach($regions AS $listObj)
								{
									?><option value="<?=$listObj->id?>"><?=$listObj->name?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="region.php">New</a>
						</form>
					</td>
				</tr>
			</table>
		</td>
		<td>
			<!-- RESOURCES -->
			<table border="2px">
				<tr>
					<th>Resources</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="resource.php">
							<select name="resource">
								<?php
								foreach($resources AS $listObj)
								{
									?><option value="<?=$listObj->id?>"><?=$listObj->name?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="resource.php">New</a>
						</form>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<!-- RESEARCH -->
			<table border="2px">
				<tr>
					<th>Researches</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="research.php">
							<select name="research">
								<?php
								foreach($researches AS $listObj)
								{
									?><option value="<?=$listObj->id?>"><?=$listObj->name?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="research.php">New</a>
						</form>
					</td>
				</tr>
			</table>
		</td>
		<td>
			<!-- FACILITY -->
			<table border="2px">
				<tr>
					<th>Facilities</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="facility.php">
							<select name="facility">
								<?php
								foreach($facilities AS $listObj)
								{
									?><option value="<?=$listObj->id?>"><?=$listObj->name?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="facility.php">New</a>
						</form>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<!-- UNITS -->
			<table border="2px">
				<tr>
					<th>Units</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="unit.php">
							<select name="unit">
								<?php
								foreach($units AS $listObj)
								{
									?><option value="<?=$listObj->id?>"><?=$listObj->name?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="unit.php">New</a>
						</form>
					</td>
				</tr>
			</table>
		</td>
		<td>
			<!-- TEAM -->
			<table border="2px">
				<tr>
					<th>Teams</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="team.php">
							<select name="team">
								<?php
								foreach($teams AS $listObj)
								{
									?><option value="<?=$listObj->id?>"><?=$listObj->name?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="team.php">New</a>
						</form>
					</td>
				</tr>
			</table>
		</td>
	</tr>
		<tr>
		<td>
			<!-- UNIT TYPE -->
			<table border="2px">
				<tr>
					<th>Unit Types</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="unitType.php">
							<select name="unitType">
								<?php
								foreach($unitType AS $listObj)
								{
									?><option value="<?=$listObj->id?>"><?=$listObj->name?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="unitType.php">New</a>
						</form>
					</td>
				</tr>
			</table>
		</td>
		<td>
			<!--  -->
			<table border="2px">
				<tr>
					<th>Stats</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="stat.php">
							<select name="stat">
								<?php
								foreach($stats AS $listObj)
								{
									?><option value="<?=$listObj->id?>"><?=$listObj->name?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="stat.php">New</a>
						</form>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
		</td>
		<td>
			
<table>
		<tr>
		<td>
			<!-- Make game -->
			<table border="2px">
				<tr>
					<th>Make Game</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="game.php">
							<select name="id">
								<?php
								foreach($gameList AS $listObj)
								{
									?><option value="<?=$listObj->id?>"><?=$listObj->name?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="game.php">New</a>
						</form>
					</td>
				</tr>
			</table>
		</td>
		<td>
			<!--  -->
			<table border="2px">
				<tr>
					<th>Users</th>
				</tr>
				<tr>
					<td>
						<form method="get" action="user.php">
							<select name="id">
								<?php
								foreach($users AS $listObj)
								{
									?><option value="<?=$listObj->id?>"><?=$listObj->username?></option><?php
								}
								?>
							</select>
							<input type="submit" value="Load" />
							<a href="user.php">New</a>
						</form>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
			
		</td>
	</tr>
</table>
	