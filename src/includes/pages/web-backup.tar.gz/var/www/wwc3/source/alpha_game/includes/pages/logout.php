<?php
session_destroy();
unset($user);
?>
You have been logged out...<br><br>If you would like to relogin please <a href="index.php">click here</a> or wait a few seconds
while your browser automatically refreshes.