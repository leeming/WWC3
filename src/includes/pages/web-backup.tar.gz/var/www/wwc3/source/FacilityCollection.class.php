<?php
/**
 * List of classes used by this class
 */
require_once("Base.class.php");
require_once("Validate.class.php");
require_once("Facility.class.php");

class FacilityCollection extends Base
{
	function __construct()
	{
		parent::__construct();
	}
	
	public $id = NULL, $player = NULL, $country = NULL; 
	
	/**
	 * Gets a collection of facilities as an array, depending
	 * on what values are set to $id/$player/$country
	 *
	 * @return Facility[]
	 */
	function get()
	{
		$sql = "SELECT * FROM Player_has_facility WHERE ";
		
		$where = " ";
		if(Validate::isInt($this->id))
		{
			$where .= "facility_id = {$this->id} AND ";
		}
		if(Validate::isInt($this->player))
		{
			$where .= "player_id = {$this->player} AND ";
		}
		if(Validate::isInt($this->country))
		{
			$where .= "country_id = {$this->country} AND ";
		}
		
		$sql .= $where ."true";
		
		$return = array();
		$result = $this->db->fetch_all_array($sql);
		foreach($result AS $f)
		{
			$return[$f['country_id']] = new Facility($f['facility_id'], $f['facility_qty']);
		}
		
		return $return;
	}
	
	/**
	 *
	 * @param Player/int $player Player to look up facilities
	 * @param Facility/int $facility If set, look up facilities of only this type
	 * @return Facility[]
	 */
	static function getAllPlayerFacilities($player, $facility = NULL)
	{
		global $db;
		
		if(($playerid = Player::id($player)) == -1)
		{
			return -1;
		}
		
		if($facility != NULL && ($facilityid = Facility::id($facility)) != -1)
		{
			$facilityWhere = " AND facility_id = '{$facilityid}'";
		}
		else
		{
			$facilityWhere = "";
		}
		
		$sql = "SELECT country_id, facility_id, facility_qty FROM Player_has_facility WHERE player_id='{$playerid}'".$facilityWhere;
		$result = $db->fetch_all_array($sql);
		
		$return = array();
		foreach($result AS $f)
		{
			$return[$f['country_id']] = new Facility($f['facility_id'], $f['facility_qty']);
		}
		
		return $return;
	}
}
?>