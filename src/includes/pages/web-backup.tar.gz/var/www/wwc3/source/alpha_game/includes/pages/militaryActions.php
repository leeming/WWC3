<?php
$battalion = $player->getSelectedBattalion();
$location = new Country($battalion->location);

if($args['action'] == "move" && Validate::isInt($args['id']))
{
	$moveTo = new Country($args['id']);
	
}
else if($args['action'] == "att")
{
	print"Attack not implemented yet";
	$newLoc = new Country($args['id']);
	$present = $newLoc->armiesPresent($player->game);
	
	//check if enemies here
	if(count($present) == 0)	//no
	{
		$newLoc->attackMilita($battalion);
		print "milita";
	}
	else	//enemies here
	{
		print "enemies";
	}
}
else if($args['action'] == "raid")
{
	print"Air raid not added either";
}
else if($args['action'] == "spy")
{
	print"nope no spies yet";
}

	?>
	
<p>
You are currently in <b><?=$location->name?></b>
</p>
	
	<b>Move</b>
	<ul>
		<?php
		$moveBorders = $location->getMoveBorders($player->team);
		foreach($moveBorders AS $border)
		{
			?>
			<li><a href="#" onclick="loadWindow('actions','action=move&id=<?=$border?>')"><?=Country::name($border)?></a></li>
			<?php
		}
		if(count($moveBorders) == 0)
		{
			print"<li>None</li>";
		}
		?>
	</ul>
	
	<b>Attack</b>
	<ul>
		<?php
		$attBorders = $location->getAttackBorders($player->team);
		foreach($attBorders AS $border)
		{
			$firephp->log($border);
			?>
			<li><a href="#" onclick="loadWindow('actions','action=att&id=<?=$border?>')"><?=Country::name($border)?></a></li>
			<?php
		}
		if(count($attBorders) == 0)
		{
			print"<li>None</li>";
		}
		?>
	</ul>
	
	<p></p>
	<!--
	<ul>
		<li><a href="#" onclick="loadWindow('actions', 'action=move');">Move</a></li>
		<li><a href="#" onclick="loadWindow('actions', 'action=attack');">Attack</a></li>
		<li><a href="#" onclick="loadWindow('actions', 'action=spy');">Spy</a></li>
		<li><a href="#" onclick="loadWindow('actions', 'action=raid');">Air Raid</a></li>
	</ul> -->
