<?php
class Debug
{
	private $debugStr;
	
	public function add($str)
	{
		$this->debugStr .=$str;
	}
	public function printStr()
	{
		print "<b>".$this->debugStr."</b>";
	}
	
	public function flush()
	{	$debugStr = "";	}
	
	/**
	 * Same as print_r but exclude some elements
	 *
	 */
	static function dump($var, $arrayOfObjectsToHide=array("Database"), $fontSize=11)
	{
		$text = print_r($var, true);
	
		if (is_array($arrayOfObjectsToHide)) {
	   
			foreach ($arrayOfObjectsToHide as $objectName) {
	   
				$searchPattern = '#('.$objectName.' Object\n(\s+)\().*?\n\2\)\n#s';
				$replace = "$1<span style=\"color: #FF9900;\">--&gt; HIDDEN &lt;--</span>)";
				$text = preg_replace($searchPattern, $replace, $text);
			}
		}
	
		// color code objects
		$text = preg_replace('#(\w+)(\s+Object\s+\()#s', '<span style="color: #079700;">$1</span>$2', $text);
		// color code object properties
		$text = preg_replace('#\[(\w+)\:(public|private|protected)\]#', '[<span style="color: #000099;">$1</span>:<span style="color: #009999;">$2</span>]', $text);
	   
		echo '<pre style="font-size: '.$fontSize.'px; line-height: '.$fontSize.'px;">'.$text.'</pre>';
	}
	
}
?>