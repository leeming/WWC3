<?php
require("../tiggerConfig.php");
require_once("../classes/Database.class.php");
require_once("../classes/Settings.class.php");
require_once("../classes/Validate.class.php");
require_once("includeAll.php");
require_once("functions.php");

$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

if(!empty($_POST))
{
	print"<b>POSTED</b><br>";
	print"<pre>"; print_r($_POST); print"</pre>";

	if($_POST['addResearch'])
	{
		$setting = new Settings($_POST['id']);
		$setting->addResearch($_POST['addResearch']);
	}
	else if($_POST['addCountry'])
	{
		$setting = new Settings($_POST['id']);
		$setting->addCountry($_POST['addCountry']);
	}
	else if($_POST['addRegion'])
	{
		$setting = new Settings($_POST['id']);
		$setting->addRegion($_POST['addRegion']);
	}
	else if($_POST['addResource'])
	{
		$setting = new Settings($_POST['id']);
		$setting->addResource($_POST['addResource']);
	}
	else if($_POST['addFacility'])
	{
		$setting = new Settings($_POST['id']);
		$setting->addFacility($_POST['addFacility']);
	}
	else if($_POST['addUnit'])
	{
		$setting = new Settings($_POST['id']);
		$setting->addUnit($_POST['addUnit']);
	}
	else if($_POST['addTeam'])
	{
		$setting = new Settings($_POST['id']);
		$setting->addTeam($_POST['addTeam']);
	}
	else
	{
		
		//new or update?
		if($_POST['id'] == "") //new
		{
			$insert = array('name' => $_POST['name'],
					'desc' => $_POST['desc'],
					'max_players' => $_POST['maxPlayers'],
					'has_generals' => $_POST['generals'],
					'team_governments' => $_POST['teamGov'],
					'player_governments' => $_POST['playerGov'],
					'allow_team_treaties' => $_POST['treaties'],
					'natural_disasters' => $_POST['natural'],
					'milita_growth' => $_POST['militaGrowth'],
					'late_entry_time' => $_POST['lateEntry'],
					'cycle_time' => $_POST['cycleTime'],
					'assim_rate' => $_POST['assimRate']);
	
			$id = Settings::add($insert);
	
			if($id == -1)
				print"<br><br>Failed";
			else
				print"<br><br>".$id;
		}
		else //update
		{}
	}
}

if(Validate::isInt($_GET['setting']))
{
	$setting = new Settings($_GET['setting']);
	
	$id = $setting->id;
	$name = $setting->name;
	$desc = $setting->desc;
	$maxPlayers = $setting->maxPlayers;
	$generals = $setting->generals;
	$teamGov = $setting->teamGovernments;
	$playerGov = $setting->playerGovernments;
	$treaties = $setting->treaties;
	$disasters = $setting->naturalDisasters;
	$lateEntry = $setting->lateEntryTime;
	$cycleTime = $setting->cycleTime;
	$assimRate = $setting->assimRate;
	$milita = $setting->militaGrowth;
}
else
{
	$id = "";
	$name = "";
	$desc = "";
	$maxPlayers = "0";
	$generals = "0";
	$teamGov = "0";
	$playerGov = "0";
	$treaties = "0";
	$disasters = "0";
	$lateEntry = "86400";
	$cycleTime = "180";
	$assimRate = "20";
	$milita = "0";
}


?>
<a href="index.php">Back</a>

<p style="color:red;">
	<b>Notice:</b> This is a basic data entry form, it does <b>not</b> do anything fancy.
	Please check entries for validation rules before adding, the code only does this at
	minimal level!
</p>

<form method="post">
<table>
	<tr>
		<th>Settings -> Body</th>
	</tr>
	<tr>
		<td>
			
			<table>
				<tr>
					<td>ID: [leave blank]</td>
					<td><input type="text" name="id" value="<?=$id?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Name: [char:15]</td>
					<td><input type="text" name="name" value="<?=$name?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Description: [char:50]</td>
					<td><input type="text" name="desc" value="<?=$desc?>" maxlength="50" /></td>
				</tr>
				<tr>
					<td>Max Players: [int] 0=unlimited</td>
					<td><input type="text" name="maxPlayers" value="<?=$maxPlayers?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Milita Growth: [int]</td>
					<td><input type="text" name="militaGrowth" value="<?=$milita?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Assim Rate (# turns to assim): [int]</td>
					<td><input type="text" name="assimRate" value="<?=$assimRate?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Cycle Time (secs): [int]</td>
					<td><input type="text" name="cycleTime" value="<?=$cycleTime?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Late Entry (after start in sec): [int]</td>
					<td><input type="text" name="lateEntry" value="<?=$lateEntry?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Generals: [bool]</td>
					<td><input type="text" name="generals" value="<?=$generals?>" maxlength="1" /></td>
				</tr>
				<tr>
					<td>Team Govs: [bool]</td>
					<td><input type="text" name="teamGov" value="<?=$teamGov?>" maxlength="1" /></td>
				</tr>
				<tr>
					<td>Player Govs: [bool]</td>
					<td><input type="text" name="playerGov" value="<?=$playerGov?>" maxlength="1" /></td>
				</tr>
				<tr>
					<td>Team treaties: [bool]</td>
					<td><input type="text" name="treaties" value="<?=$treaties?>" maxlength="1" /></td>
				</tr>
				<tr>
					<td>Natural Disasters: [bool]</td>
					<td><input type="text" name="natural" value="<?=$disasters?>" maxlength="1" /></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<input type="submit" value="Add/Update" />
		</td>
	</tr>
</table>
</form>


<?php
//show only if current unit
if(Validate::isInt($id))
{
	?>
	<!--Researches-->
	<form method="post">
	<table>
		<tr>
			<th>Research In Setting</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $setting->getResearches('object');
					foreach($list AS $re)
					{
						?>
						<tr>
							<td><?=$re->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addResearch">
								<?php
								foreach(getResearches() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
		<!--Country-->
	<form method="post">
	<table>
		<tr>
			<th>Country In Setting</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $setting->getCountries('object');
					foreach($list AS $re)
					{
						?>
						<tr>
							<td><?=$re->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addCountry">
								<?php
								foreach(getCountries() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	
		<!--Regions-->
	<form method="post">
	<table>
		<tr>
			<th>Region In Setting</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $setting->getRegions('object');
					foreach($list AS $re)
					{
						?>
						<tr>
							<td><?=$re->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addRegion">
								<?php
								foreach(getRegions() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	
		<!--Resources-->
	<form method="post">
	<table>
		<tr>
			<th>Resource In Setting</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $setting->getResources('object');
					foreach($list AS $re)
					{
						?>
						<tr>
							<td><?=$re->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addResource">
								<?php
								foreach(getResources() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
		<!--Facility-->
	<form method="post">
	<table>
		<tr>
			<th>Facilities In Setting</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $setting->getFacilities('object');
					foreach($list AS $re)
					{
						?>
						<tr>
							<td><?=$re->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addFacility">
								<?php
								foreach(getFacilities() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	
		<!--Units-->
	<form method="post">
	<table>
		<tr>
			<th>Units In Setting</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $setting->getUnits('object');
					foreach($list AS $re)
					{
						?>
						<tr>
							<td><?=$re->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addUnit">
								<?php
								foreach(getUnits() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	
		<!--Teams-->
	<form method="post">
	<table>
		<tr>
			<th>Teams In Setting</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $setting->getTeams('object');
					foreach($list AS $re)
					{
						?>
						<tr>
							<td><?=$re->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addTeam">
								<?php
								foreach(getTeams() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	<?php
}
?>