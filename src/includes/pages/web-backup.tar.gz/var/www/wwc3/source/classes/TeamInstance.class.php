<?php
/**
 * List of classes used by this class
 */
require_once("Base.class.php");
require_once("Validate.class.php");
require_once("Country.class.php");
require_once("Team.class.php");

/**
 * Class containing information about a current team in a game
 *
 * @todo Still needs loads done, orders needs adding, team leader, governments
 */
class TeamInstance extends Base
{
	/**
	 * TeamInstance constructor
	 *
	 * @param int $id Id of game team
	 */
	function __construct($id)
	{
		parent::__construct();
		
		if(!Validate::isInt($id))
		{
			trigger_error("(int)\$id expected, (".gettype($id).") passed", E_USER_ERROR);
			return;
		}
		
		$this->db->query("SELECT team_id FROM Game_teams WHERE id ='{$id}' LIMIT 1");
		$result = $this->db->getRow();
		
		$this->id = $id;
		$this->team = new Team($result['team_id']);
	}
	
	private $countryList = NULL;
	private $countryIdList = NULL;
	
	/**
	 * Get a list of countries team owns
	 *
	 * @param string $returnType Type of array to return
	 * @return int[]/Country[]
	 */
	function countriesOwn($returnType = 'int')
	{
		$sql = "SELECT country_id FROM Team_has_country WHERE team_id ='{$this->id}'";
		
		if($returnType == 'int')
		{
			if($this->countryIdList == NULL)
			{
				$this->countryIdList = array();
				
				$result = $this->db->fetch_all_array($sql);
				
				foreach($result AS $country)
				{
					$this->countryIdList[] = $country['country_id'];
				}
			}
			
			return $this->countryIdList;
		}
		else
		{
			if($this->countryList == NULL)
			{
				$this->countryList = array();
				
				$result = $this->db->fetch_all_array($sql);
				
				foreach($result AS $country)
				{
					$this->countryList[] = new Country($country['country_id']);
				}
			}
			
			return $this->countryList;
		}
	}
	
	/**
	 * Accessor method to get name of team to avoid $obj->team->team->name
	 *
	 * @return string Team name
	 */
	function getName()
	{
		return $this->team->name;
	}
}
?>