<table>
	<tr>
		<th colspan="2">Leeming (<a onclick="" href="#">Profile</a>)</th>
	</tr>
	<tr>
		<td>Role(s)</td>
		<td>Game Creator, Webmaster, Game Designer, UI Designer, Server Administrator, Lead Tester</td>
	</tr>
	<tr>
		<td>Location</td>
		<td>England</td>
	</tr>
	<tr>
		<td>Day Job</td>
		<td>Student (Computer Science)</td>
	</tr>
	<tr>
		<td>Likes</td>
		<td>Programs that compile without an bugs at all</td>
	</tr>
	<tr>
		<td>DisLikes</td>
		<td>Seg Faults</td>
	</tr>
		
		
</table>