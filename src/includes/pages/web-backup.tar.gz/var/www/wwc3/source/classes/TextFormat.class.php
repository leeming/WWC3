<?php
class TextFormat
{
	/**
	 * Format some text so that only $charsLen is shown. If the text
	 * has more text then '...' is added to the end of the block.
	 *
	 * @param string $text Text to preview
	 * @param int $charsLen Max number of chars to show
	 * @return string Formated text
	 */
	static function previewText($text, $charsLen)
	{
		//Figure out if any thing needs to be done
		if(strlen($text) <= $charsLen)
			return $text;
		
		//split all words up
		$words = explode(" ", $text);
		
		//go thru all the text untill char limit reached
		$currentChars = 0;
		$previewText = "";
		foreach($words AS $word)
		{
			$previewText .= $word." ";
			//check if limit has been reached
			if(strlen($previewText) >= $charsLen)
				return $previewText."...";
			//else add next word
		}
		
		//just encase code gets here return $previewText anyway
		return $previewText."...";
	}
	
	/**
	 * Does full BBCode translations using external code
	 *
	 * @param string $textToConvert
	 * @return string Text with bbcode conversion
	 */
	static function BBCode($textToConvert)
	{
		require_once("BBCodeWrapper.class.php");
		$bbcode = new BBCodeWrapper();
		return $bbcode->parse($textToConvert);
	}
	
	/**
	 * Format the date to the site default
	 *
	 * @param int $timestamp
	 * @return string
	 */
	static function date($timestamp)
	{
		return date("d/m/y H:i:s",$timestamp);
	}
}
?>