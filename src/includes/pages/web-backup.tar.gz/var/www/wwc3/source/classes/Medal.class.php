<?php

class Medal
{
	function __construct($id)
	{}
}
?>