<?php
require("tiggerConfig.php");
require("classes/Database.class.php");
$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();


?>