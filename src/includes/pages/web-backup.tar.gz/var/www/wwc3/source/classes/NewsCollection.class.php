<?php
/**
 * List of classes used by this class
 */
require_once("Base.class.php");
require_once("Validate.class.php");
require_once("News.class.php");

class NewsCollection extends Base
{
	function __construct()
	{
		parent::__construct();
	}
	
	
	/**
	 * Get all news articles
	 *
	 * @param bool $newFirst True[default]:Newst first, False:Oldest
	 * @return News[]
	 */
	static function all($newFirst = true)
	{
		global $db;
		$sql = "SELECT id FROM News ORDER BY post_timestamp ".($newFirst?"DESC":"ASC");
		$result = $db->fetch_all_array($sql);
		
		$return = array();
		foreach($result AS $id)
		{
			$return[] = new News($id['id']);
		}
		
		return $return;
	}
}
?>