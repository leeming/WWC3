<?php
if($args['submit'])
{
	//try to register
	$register = User::add(array(
		'username' => $args['uname'],
		'email' => $args['email'],
		'handle' => $args['handle'],
		'password' => $args['pword']
	));

	
	//check that $register is an int as add returns user id
	if(Validate::isInt($register))
	{
		print "1";
	}
	else
	{
		print $register;
	}
}
else if($args['done'])
{
	?>
	<p>
		Yey an account has been created!
		Try to log in now... In the future there should be email
		verfication, but not yet.
	</p>
	<?php
}
else
{
?>

<div class="form">
	<form action="" method="post">
	<div class="row">
		<span id="regError" class="error"></span>
	</div>
	<div class="row">
		<span class="label">Username</span>
		<span class="data">
			<input type="text" id="uname" value="" />
		</span>
	</div>
	<div class="row">
		<span class="label">Password</span>
		<span class="data">
			<input type="password" id="pword" value="" />
		</span>
	</div>
	<div class="row">
		<span class="label">Repeat Password</span>
		<span class="data">
			<input type="password" id="pword2" value="" />
		</span>
	</div>
	<div class="row">
		<span class="label">Handle</span>
		<span class="data">
			<input type="text" id="handle" value="" />
		</span>
	</div>
	<div class="row">
		<span class="label">Email</span>
		<span class="data">
			<input type="text" id="email" value="" />
		</span>
	</div>
	<div class="row">
		<span class="submit">
			<input type="button" id="submit" value="Register" onclick="submitReg()" />
		</span>
	</div>
	</form>
</div>
<?php
}?>