<?php
/**
 * Shows player's research queue and allows add/deletes
 */
?>
<h1>Research Queue</h1>

