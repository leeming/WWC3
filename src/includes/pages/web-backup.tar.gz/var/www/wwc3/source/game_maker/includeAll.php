<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once("../classes/Database.class.php");
require_once("../classes/Settings.class.php");
require_once("../classes/Country.class.php");
require_once("../classes/Region.class.php");
require_once("../classes/Unit.class.php");
require_once("../classes/Team.class.php");
require_once("../classes/Research.class.php");
require_once("../classes/Facility.class.php");
require_once("../classes/Resource.class.php");
require_once("../classes/UnitType.class.php");
require_once("../classes/Game.class.php");
?>
