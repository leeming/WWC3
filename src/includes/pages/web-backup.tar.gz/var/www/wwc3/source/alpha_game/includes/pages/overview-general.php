<?php
require_once("../classes/Player.class.php");
require_once("../classes/FacilityCollection.class.php");
require_once("../classes/Country.class.php");
require_once("../classes/Battalion.class.php");
require_once("../classes/ResearchQueue.class.php");

?>
<table>
	<tr>
		<th>Game</th>
	</tr>
	<tr>
		<td><?=$player->game->name?></td>
	</tr>
	<tr>
		<td>Cycle #<?=$player->game->cycleNumber()?></td>
	</tr>
	<tr>
		<td><?=$player->team->getName()?></td>
	</tr>
	
	
	<tr>
		<th>Resources</th>
	</tr>
	<?php
	foreach($player->getResources('obj',$true) AS $res)
	{
		?>
		<tr>
			<td><?=$res->qty?> <?=$res->name?></td>
		</tr>
		<?php
	}
	?>
	
	<tr>
		<th>Battalion(s)</th>
	</tr>
	<?php
	$sel = $player->getSelectedBattalion();
	foreach($player->getBattalions() AS $bat)
	{
		?>
		<tr>
			<td>
		<?php
		if($bat->equals($sel))
			print "<b>*</b>";
		
		print $bat->name." lvl".$bat->getLevel()." (".Country::name($bat->location).")";
		print "</td></tr>";
	}
	?>
	<tr>
		<th>Research</th>
	</tr>
	<?php
	
	$queue = new ResearchQueue(&$player);
	$activeResearch = $queue->get(0);
	
	//no research?
	if(empty($activeResearch))
	{
		?>
		<tr>
			<td>No research</td>
		</tr>
		<?php
	}
	else
	{
		$res = new Research($activeResearch['research']);
		?>
		<tr>
			<td><?=$res->name?> - <?=$res->getPercentDone($activeResearch['ticksDone'])?>%</td>
		</tr>
		<tr>
			<td> [Percent bar here]</td>
		</tr>
		<?php
	}
	?>
</table>