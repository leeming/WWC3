<?php
session_start();

//Check to see session data is set, if not divert to index
if(!key_exists('user', $_SESSION))
{
	header("Location: index.php");
}

//get config file & connection
require_once("../tiggerConfig.php");
require_once("../classes/Database.class.php");
require_once("../classes/Validate.class.php");
require_once("../classes/User.class.php");


$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

$user = unserialize($_SESSION['user']);

?>