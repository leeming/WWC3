<?php
print"====Testing DB connect====\n";
require("tiggerConfig.php");
require("classes/Database.class.php");
$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();
print"DB seems fine...\n\n";


/*
print"====Testing Base====\n";
require_once("classes/Unit.class.php");
print"Should fail: ";
$base = new Base();
print"\n";
*/

define('GAMEID', 1);
print"====Testing Country====\n";
require_once("classes/Country.class.php");
$country = new Country(1);

print_r($country->getBonus());


print"====Testing MapArea====\n";
require_once("classes/MapArea.class.php");

print"====Testing Profile====\n";
require_once("classes/Profile.class.php");

print"====Testing Region====\n";
require_once("classes/Region.class.php");

print"====Testing Resource====\n";
require_once("classes/Resource.class.php");

$r = new Resource(1);
print"".$r->getGameId()."\n";

print"====Testing User====\n";
require_once("classes/User.class.php");

print"====Testing Unit====\n";
require_once("classes/Unit.class.php");
$u = new Unit(1);
print"".$u->getGameId()."\n";

//print"Making...\n";
//$unit = new Unit(1);
//var_dump($unit);

?>