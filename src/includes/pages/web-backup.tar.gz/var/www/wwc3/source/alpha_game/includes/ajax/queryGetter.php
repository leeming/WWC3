<?php
switch($args['get'])
{
	case 'userInfo':
		include("userInfo.php");
		break;
	case 'userGames':
		include("menuGamelist.php");
		break;
	case 'loadFacilityMenu':
		include("makeFacilityMenu.php");
		break;
	case 'checkLogin':
		print isset($_SESSION['user'])?"1":"0";
		break;
	case 'whatGame':
		if(isset($player))
			print $player->game->id;
		else
			print 0;
		break;
	case 'lastPage':
		//$last = array_pop($_SESSION['track']);
		for($i=count($_SESSION['track'])-1; $i>=0; $i--)
		{ print $i.":";
			if($_SESSION['track'][$i]['page'] != "get")
			{
				$last = $_SESSION['track'][$i];
				break;
			}
		}
		
		print $last['request']['page']." ";
		foreach($last['request'] AS $index => $value)
		{
			//dont redo 'page' and dont allow resubmit of forms
			if($index != "page" && $index != "submit")
				print $index."=".$value."&";
		}
		
		break;
	default:
		print "Unknown get";
		break;
}
?>