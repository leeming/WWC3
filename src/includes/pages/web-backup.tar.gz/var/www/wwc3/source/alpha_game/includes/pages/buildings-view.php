<?php
require_once("../classes/FacilityCollection.class.php");
require_once("../classes/Country.class.php");
$fac = new Facility($args['view']);

?>
<div>
	<div class="row">
		<span class="label">Building</span>
		<span class="data"><?=$fac->name?></span>
	</div>
	<div class="row">
		<span class="label">Description</span>
		<span class="data"><?=$fac->desc?></span>
	</div>
</div>
	

<div class="form">
	<form onsubmit="return false;">
		<div class="row">
			<span class="label">How Many</span>
			<span class="data">
				<input type="text" id="buildAmount" size="4" />
			</span>
		</div>
		<div class="row">
			<span class="label">Where</span>
			<span class="data">
				<select id="buildLoc">
					<?php
					
					?>
				</select>
			</span>
		</div>
		<div class="row">
			<span>
				<input type="submit" value="Build" onclick="submitForm(['buildLoc','buildAmount'], {page: 'build', view:<?=$args['view']?>});" />
			</span>
		</div>
	</form>
</div>

<div>
	<div class="row">
		<span><?=$fac->name?> you own...</span>
	</div>
	
	<?php
	$collection = new FacilityCollection();
	$collection->player = $player->id;
	$collection->id = $args['view'];
	
	$playerFacs = $collection->get();
	foreach($playerFacs AS $countryId => $owned)
	{
		$country = new Country($countryId);
		?>
		<div class="row">
			<span><?=$country->name?></span>
			<span><?=$owned->qty?></span>
			<span><?=
			
	}
?>