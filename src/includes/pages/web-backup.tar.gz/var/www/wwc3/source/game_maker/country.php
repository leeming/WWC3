<?php
require("../tiggerConfig.php");
require("includeAll.php");
require_once("functions.php");


$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

if(!empty($_POST))
{
	print"<b>POSTED</b><br>";
	print"<pre>"; print_r($_POST); print"</pre>";

	
	//post is add border
	if($_POST['addBorder'])
	{
		$country = new Country($_POST['id']);
		$country->addBorder(new Country($_POST['addBorder']), isset($_POST['twoway']));

	}
	//post is add resource
	elseif($_POST['addResource'])
	{
		$resource = new Resource($_POST['addResource'], $_POST['qty']);
		
		$country = new Country($_POST['id']);
		$country->addBonus($resource);
		
	}
	//post is add region
	elseif($_POST['addRegion'])
	{
		$region = new Region($_POST['addRegion']);
		
		$country = new Country($_POST['id']);
		$region->addCountry($country);
		
	}
	//post is add coordinates
	elseif($_POST['addCoords'])
	{
		
		$country = new Country($_POST['id']);
		$country->addCoords($_POST['addCoords']);
	}
	else
	{
		//new or update?
		if($_POST['id'] == "") //new
		{
			$insert = array('name' => $_POST['name'],
							'default_milita'=> $_POST['milita']);
	
			$id = Country::add($insert);
	
			if($id == -1)
				print"<br><br>Failed";
	
			$_GET['country'] = $id;
		}
		else //update
		{}
	}
}

if(Validate::isInt($_REQUEST['country']))
{
	$country = new Country($_GET['country']);
	
	$id = $country->id;
	$name = $country->name;
	$milita = $country->getMilita();
}
else
{
	$id = "";
	$name = "";
	$milita = "100";
}


?>
<a href="index.php">Back</a>

<p style="color:red;">
	<b>Notice:</b> This is a basic data entry form, it does <b>not</b> do anything fancy.
	Please check entries for validation rules before adding, the code only does this at
	minimal level!
</p>

<form method="post">
<table>
	<tr>
		<th>Country Details</th>
	</tr>
	<tr>
		<td>
			
			<table>
				<tr>
					<td>ID: [leave blank]</td>
					<td><input type="text" name="id" value="<?=$id?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Name: [char:15]</td>
					<td><input type="text" name="name" value="<?=$name?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Default Milita: [int]</td>
					<td><input type="text" name="milita" value="<?=$milita?>" maxlength="15" /></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<input type="submit" value="Add/Update" />
		</td>
	</tr>
</table>
</form>



<?php
//show only if current country
if(Validate::isInt($id))
{
	?>
	<!--Production-->
	<form method="post">
	<table>
		<tr>
			<th>Country Resources</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $country->getBonus();
					foreach($list AS $bonus)
					{
						?>
						<tr>
							<td><?=$bonus->qty?></td>
							<td><?=$bonus->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="3"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="text" name="qty" />
						</td>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addResource">
								<?php
								foreach(getResources() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	<!--Borders-->
	<form method="post">
	<table>
		<tr>
			<th>Borders</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $country->getBorders('object',true);
					foreach($list AS $border)
					{
						?>
						<tr>
							<td><?=$border->name?></td>
							<td colspan="2">Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="3"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addBorder">
								<?php
								foreach(getCountries() AS $re)
								{
									if($re->equals($country))
										continue;
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="checkbox" title="2 way border?" name="twoway" checked="checked" value="true" />
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	<!--Regions-->
	<form method="post">
	<table>
		<tr>
			<th>Regions</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $country->regionsIn(true);
					foreach($list AS $region)
					{
						?>
						<tr>
							<td><?=$region->name?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<select name="addRegion">
								<?php
								foreach(getRegions() AS $re)
								{
									?>
									<option value="<?=$re->id?>"><?=$re->name?></option>
									<?php
								}
								?>
							</select>
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	
	
	<!--Country physical border coordinates-->
	<form method="post">
	<table>
		<tr>
			<th>Coordinates</th>
		</tr>
		<tr>
			<td>
				<table>
					<?php
					$list = $country->getCoords(true);
					foreach($list AS $coord)
					{
						?>
						<tr>
							<td><?=$coord?></td>
							<td>Remove</td>
						</tr>
						<?php
					}
					if(empty($list))
					{
						?>
						<tr>
							<td colspan="2"><i>None</i></td>
						</tr>
						<?php
					}
					?>

					<tr>
						<td>
							<input type="hidden" name="id" value="<?=$id?>" />
							<input type="text" name="addCoords" />
						</td>
						<td>
							<input type="submit" value="Add" />
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	</form>
	<?php
}
?>