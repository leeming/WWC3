<?php
require("../tiggerConfig.php");
require("includeAll.php");


$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$db->connect();

if(!empty($_POST))
{
	print"<b>POSTED</b><br>";
	print"<pre>"; print_r($_POST); print"</pre>";

	//new or update?
	if($_POST['id'] == "") //new
	{
		$insert = array('name' => $_POST['name']);

		$id = UnitType::add($insert);

		if($id == -1)
			print"<br><br>Failed";

		$_GET['unitType'] = $id;
	}
	else //update
	{}

}

if(Validate::isInt($_GET['unitType']))
{
	$unit = new UnitType($_GET['unitType']);
	
	$id = $unit->id;
	$name = $unit->name;
}
else
{
	$id = "";
	$name = "";
}


?>
<a href="index.php">Back</a>

<p style="color:red;">
	<b>Notice:</b> This is a basic data entry form, it does <b>not</b> do anything fancy.
	Please check entries for validation rules before adding, the code only does this at
	minimal level!
</p>

<form method="post">
<table>
	<tr>
		<th>UnitType Details</th>
	</tr>
	<tr>
		<td>
			
			<table>
				<tr>
					<td>ID: [leave blank]</td>
					<td><input type="text" name="id" value="<?=$id?>" maxlength="15" /></td>
				</tr>
				<tr>
					<td>Name: [char:15]</td>
					<td><input type="text" name="name" value="<?=$name?>" maxlength="15" /></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<input type="submit" value="Add/Update" />
		</td>
	</tr>
</table>
</form>