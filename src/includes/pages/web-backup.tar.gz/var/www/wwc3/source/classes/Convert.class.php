<?php
/**
 * List of classes used by this class
 */
require_once("Validate.class.php");

/**
 * Class for simple conversions using static methods
 */
class Convert
{
	/**
	 * Convert bool values to "Yes" and "No" values
	 *
	 * @param bool $bool
	 * @return string
	 */
	static function boolToYesNo($bool)
	{ return ($bool?"Yes":"No"); }
	
	/**
	 * Convert number of seconds into number of
	 * days/ hours/ min/ secs ago
	 *
	 * @param int $time Time in seconds to string
	 * @return string
	 */
	static function secondsToReadable($time)
	{
		$secInDay = 86400;
		$secInHour = 60*60;
		$secInMin = 60;
		
		$str = "";
		if($time >= $secInDay)
		{
			$days = floor($time/$secInDay);
			$time = $time%$secInDay;
			$str .= $days." Days ";
		}
		
		if($time >= $secInHour)
		{
			$hours = floor($time/$secInHour);
			$time = $time%$secInHour;
			$str .= $hours." Hours ";
		}
		
		if($time >= $secInMin)
		{
			$mins = floor($time/$secInMin);
			$time = $time%$secInMin;
			$str .= $mins." Mins ";
		}
		
		if($time >= 1)
		{
			$str .= $time." secs";
		}
		
		return $str;
	}
}

?>