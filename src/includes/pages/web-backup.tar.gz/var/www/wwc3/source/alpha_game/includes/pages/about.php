<p>
	WWC3 is a RTS (Real Time Strategy) table top kind of game where players accumilate turns
	over a set time (depending on the game but normally a couple of minutes). This turns can
	then be used to build up an army to take over the world!<br>
	The game can also be compared to a C&amp;C Red Alert meets Risc type of game as many ideas
	have been inspired by both games and changed to allow them to work together.
</p>

<p>
	WWC3 stands for <i>"World War Combat 3"</i> where the 3 stands for the version
	number of the game, this is not strictly true as I have done a few attempts at
	redesigning the game but many fell through thus I never increased the version number.<br>
	I should also like to point out versions 1 and 2 were not created by me (Leeming)
	but instead by Fed. During the life cycle of version 2 I was invited to help out with
	the coding, where I noticed a lot of improvements to the UI and backend code - thus WWC3
</p>